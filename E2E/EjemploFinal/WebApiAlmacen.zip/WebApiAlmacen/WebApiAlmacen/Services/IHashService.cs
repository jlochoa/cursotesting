﻿using WebApiAlmacen.Classes;

namespace WebApiAlmacen.Services
{
    public interface IHashService
    {
        ResultadoHash Hash(string textoPlano);
        ResultadoHash Hash(string textoPlano, byte[] salt);
    }
}
