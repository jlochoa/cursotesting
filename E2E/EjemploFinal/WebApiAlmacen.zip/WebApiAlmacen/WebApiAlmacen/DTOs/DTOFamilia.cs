﻿namespace WebApiAlmacen.DTOs
{
    public class DTOFamilia
    {
        public int IdFamilia { get; set; }
        public string NombreFamilia { get; set; }
        public int TotalProductos { get; set; }
    }

    public class DTOAgregarFamilia
    {
        public string NombreFamilia { get; set; }
    }

}
