﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiAlmacen.DTOs;
using WebApiAlmacen.Models;

namespace WebApiAlmacen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FamiliasController : ControllerBase
    {
        private readonly MiAlmacenContext context;

        public FamiliasController(MiAlmacenContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<ActionResult> GetFamilias()
        {
            var familias = await (from x in context.Familias
                                  select new DTOFamilia
                                  {
                                      IdFamilia = x.Id,
                                      NombreFamilia = x.Nombre,
                                      TotalProductos = x.Productos.Count()
                                  }).ToListAsync();
            return Ok(familias);
        }

        [HttpPost]
        public async Task<ActionResult> PostFamilia(DTOAgregarFamilia familia)
        {
            var newFamilia = new Familia()
            {
                Nombre = familia.NombreFamilia
            };

            await context.AddAsync(newFamilia);
            await context.SaveChangesAsync();

            return Created("familia", new { familia = newFamilia });
        }

        [HttpPut]
        public async Task<ActionResult> PutFamilia([FromBody] DTOFamilia familia)
        {
            var familiaUpdate = await context.Familias.AsTracking()
                .FirstOrDefaultAsync(x => x.Id == familia.IdFamilia);
            if (familiaUpdate == null)
            {
                return NotFound();
            }
            familiaUpdate.Nombre = familia.NombreFamilia;
            // context.Update(familiaUpdate);

            await context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult> Delete(int id)
        {
            var hayProductos = await context.Productos.AnyAsync(x => x.FamiliaId == id);
            if (hayProductos)
            {
                return BadRequest("Hay productos relacionados");
            }
            var familia = await context.Familias.FirstOrDefaultAsync(x => x.Id == id);

            if (familia is null)
            {
                return NotFound();
            }

            context.Remove(familia);
            await context.SaveChangesAsync();

            return Ok();
        }
    }
}
