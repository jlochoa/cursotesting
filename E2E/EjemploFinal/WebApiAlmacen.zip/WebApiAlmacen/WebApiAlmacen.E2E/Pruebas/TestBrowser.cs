﻿using OpenQA.Selenium.Edge;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;
using WebDriverManager;
using OpenQA.Selenium.Chrome;

namespace WebApiAlmacen.E2E.Pruebas
{
    [TestFixture]
    public class TestBrowser
    {
        IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            // Selenium se comunica con el driver de Chrome mediante el driver
            // ChromeDriver chromeDriver = new ChromeDriver();
            // Mediante WebDriverManager, Selenium emplea "al vuelo" el driver del navegador según su versión y configuración
            // new DriverManager().SetUpDriver(new ChromeConfig());
            // new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
            new DriverManager().SetUpDriver(new ChromeConfig());
            // driver = new FirefoxDriver();
            // driver = new ChromeDriver();
            driver = new ChromeDriver();

            driver.Manage().Window.Maximize();
        }

        [Test]
        public void Test1()
        {
            driver.Url = "https://elpais.com/";
            TestContext.Progress.WriteLine(driver.Title);
            TestContext.Progress.WriteLine(driver.Url);
            Assert.IsTrue(driver.Title.Contains("EL PAÍS"), "El título de la página no es correcto");
            driver.Close();
        }

        [TearDown]
        public void TearDown()
        {
            driver.Dispose();
        }
    }

}
