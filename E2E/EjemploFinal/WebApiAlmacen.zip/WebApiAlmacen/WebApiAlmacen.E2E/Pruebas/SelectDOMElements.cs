﻿using OpenQA.Selenium.Edge;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;
using NUnit.Framework;

namespace WebApiAlmacen.E2E.Pruebas
{
    [TestFixture]
    public class SelectDOMElements
    {
        IWebDriver driver;

        [SetUp]

        public void Setup()
        {
            new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
            driver = new EdgeDriver();

            // La espera implícita en Selenium se usa para decirle al controlador web que espere una cierta cantidad de 				tiempo antes de que arroje una
            // excepción sin un elemento no está. También se pueden configurar tiempos de espera explícitos
            // que pausen la prueba y se reanude cuando un elemente cumpla una condición
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);

            driver.Manage().Window.Maximize();
            driver.Url = "http://localhost:4200/login";
        }

        [Test]
        public void Test()
        {
            driver.FindElement(By.Name("email")).Clear();
            driver.FindElement(By.Name("email")).SendKeys("jl@gmail.com");
            driver.FindElement(By.Name("password")).Clear();
            driver.FindElement(By.Name("password")).SendKeys("123456");
            // driver.FindElement(By.ClassName("btn-lg")).Click();
            IWebElement button = driver.FindElement(By.TagName("button"));
            button.Click();
        }

        [TearDown]
        public void TearDown()
        {
            driver.Dispose();
        }
    }


}
