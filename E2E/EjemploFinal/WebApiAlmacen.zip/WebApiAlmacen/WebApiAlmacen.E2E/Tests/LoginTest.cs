﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiAlmacen.E2E.PageSpecs;
using WebApiAlmacen.E2E.Utils;

namespace WebApiAlmacen.E2E.Tests
{
    public class LoginTest : Base
    {
        [Test]
        public void Test()
        {
            LoginPage loginPage = new LoginPage(driver);
            // loginPage.getEmail().Clear();
            // loginPage.getPassword().Clear();
            //loginPage.getUsuario().SendKeys("jl@gmail.com");
            //loginPage.getPassword().SendKeys("123456");
            loginPage.clearInputs();
            //loginPage.validLogin("jl@gmail.com", "123456");
           
            FamiliasPage familiasPage = loginPage.validLogin("jl@gmail.com", "12346");
            familiasPage.waitForPageDisplay();
        }

        [TearDown]
        public void AfterTest()
        {
            driver.Quit();
        }
    }
}
