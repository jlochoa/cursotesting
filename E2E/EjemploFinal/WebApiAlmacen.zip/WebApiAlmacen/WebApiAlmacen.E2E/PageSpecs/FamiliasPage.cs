﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiAlmacen.E2E.PageSpecs
{
    public class FamiliasPage
    {
        private IWebDriver driver;

        public FamiliasPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        // Elementos de la página

        [FindsBy(How = How.Name, Using = "nombre")]
        private IWebElement inputNombre;

        public IWebElement getInputNombre()
        {
            return inputNombre;
        }

        public void waitForPageDisplay()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Name("nombre")));
        }
    }
}
