export const environment = {
  urlAPI: 'https://localhost:44329/api/'
};
