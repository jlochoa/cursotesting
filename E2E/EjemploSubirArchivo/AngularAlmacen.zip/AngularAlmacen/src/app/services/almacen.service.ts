import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IFamilia, IProducto } from '../interfaces/almacen.interfaces';

@Injectable({
  providedIn: 'root'
})
export class AlmacenService {
  urlAPI = environment.urlAPI;
  constructor(private http: HttpClient) {}

  getFamilias(): Observable<IFamilia[]> {
    return this.http.get<IFamilia[]>(`${this.urlAPI}familias`);
  }

  getProductos(): Observable<IProducto[]> {
    return this.http.get<IProducto[]>(`${this.urlAPI}productos`);
  }

  addProducto(producto: IProducto): Observable<IProducto> {
    const formData = new FormData();
    formData.append('nombre', producto.nombre);
    formData.append('precio', producto.precio.toString());
    formData.append('familiaId', producto.familiaId?.toString()!);
    formData.append('descatalogado', producto.descatalogado ? 'true' : 'false');
    formData.append('foto', producto.foto!);

    return this.http.post<IProducto>(`${this.urlAPI}productos`, formData);
  }

  deleteProducto(id: number): Observable<IProducto> {
    return this.http.delete<IProducto>(`${this.urlAPI}productos/${id}`);
  }
}
