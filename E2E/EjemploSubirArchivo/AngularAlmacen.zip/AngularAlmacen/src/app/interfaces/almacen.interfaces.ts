export interface IFamilia{
    idFamilia?: number;
    nombreFamilia: string;
    totalProductos?: number
}

export interface IProducto {
    id: number;
    nombre: string;
    precio: number;
    descatalogado: boolean;
    foto?: File | null;
    fotoUrl?: string|null;
    familiaId: number | null;
    familia?: string;
  }