﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiAlmacen.DTOs;
using WebApiAlmacen.Models;

namespace WebApiAlmacen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FamiliasController : ControllerBase
    {
        private readonly MiAlmacenContext context;

        public FamiliasController(MiAlmacenContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<ActionResult> GetFamilias()
        {
            var familias = await (from x in context.Familias
                                  select new DTOFamilia
                                  {
                                      IdFamilia = x.Id,
                                      NombreFamilia = x.Nombre,
                                      TotalProductos = x.Productos.Count()
                                  }).ToListAsync();
            return Ok(familias);
        }
    }
}
