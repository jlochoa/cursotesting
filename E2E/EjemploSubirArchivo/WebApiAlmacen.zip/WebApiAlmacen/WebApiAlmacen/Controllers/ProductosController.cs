﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiAlmacen.DTOs;
using WebApiAlmacen.Models;
using WebApiAlmacen.Services;

namespace WebApiAlmacen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly MiAlmacenContext context;
        private readonly IGestorArchivos gestorArchivos;

        public ProductosController(MiAlmacenContext context, IGestorArchivos gestorArchivos)
        {
            this.context = context;
            this.gestorArchivos = gestorArchivos;
        }

        // Esta es la get que va a utilizar Angular para ver los productos
        [HttpGet]
        public async Task<ActionResult> GetProductos()
        {
            var productos = await context.Productos.Select(x => new DTOProducto
            {
                Id = x.Id,
                Nombre = x.Nombre,
                Precio = x.Precio,
                Descatalogado = x.Descatalogado,
                FotoUrl = x.FotoUrl,
                FamiliaId = x.FamiliaId,
                Familia = x.Familia.Nombre
            }).ToListAsync();

            return Ok(productos);
        }

        // Esta es la post que va a utilizar Angular para agregar un producto
        [HttpPost]
        public async Task<ActionResult> PostProductos([FromForm] DTOProductoAgregar producto)
        {
            Producto newProducto = new Producto
            {
                Nombre = producto.Nombre,
                Precio = producto.Precio,
                Descatalogado = false,
                FechaAlta = DateOnly.FromDateTime(DateTime.Now),
                FamiliaId = producto.FamiliaId,
                FotoUrl = ""
            };

            if (producto.Foto != null)
            {
                using (var memoryStream = new MemoryStream())
                {
                    // Extraemos la imagen de la petición
                    await producto.Foto.CopyToAsync(memoryStream);
                    // La convertimos a un array de bytes que es lo que necesita el método de guardar
                    var contenido = memoryStream.ToArray();
                    // La extensión la necesitamos para guardar el archivo
                    var extension = Path.GetExtension(producto.Foto.FileName);
                    // Recibimos el nombre del archivo
                    // El servicio Transient GestorArchivos instancia el servicio y cuando se deja de usar se destruye
                    newProducto.FotoUrl = await gestorArchivos.GuardarArchivo(contenido, extension, "imagenes",
                        producto.Foto.ContentType);
                }
            }

            await context.AddAsync(newProducto);
            await context.SaveChangesAsync();
            return Ok(newProducto);
        }


        // Esta es la delete que va a utilizar Angular para borrar productos
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteProductos([FromRoute] int id)
        {
            var producto = await context.Productos.FindAsync(id);
            if (producto == null)
            {
                return NotFound();
            }

            await gestorArchivos.BorrarArchivo(producto.FotoUrl, "imagenes");
            context.Remove(producto);
            await context.SaveChangesAsync();
            return Ok();
        }

    }
}
