﻿namespace WebApiAlmacen.Validators
{
    public enum GrupoTipoArchivo
    {
        Imagen,
        Pdf
    }
}
