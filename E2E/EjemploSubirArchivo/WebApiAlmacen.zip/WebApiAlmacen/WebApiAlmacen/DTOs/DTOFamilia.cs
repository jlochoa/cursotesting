﻿using WebApiAlmacen.Validators;

namespace WebApiAlmacen.DTOs
{
    public class DTOFamilia
    {
        public int IdFamilia { get; set; }
        public string NombreFamilia { get; set; }
        public int TotalProductos { get; set; }
    }

    public class DTOAgregarFamilia
    {
        //[PrimeraMayusculaAttribute]
        public string NombreFamilia { get; set; }
    }

}
