﻿using WebApiAlmacen.Validators;

namespace WebApiAlmacen.DTOs
{
    public class DTOProductoAgregar
    {
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public bool Descatalogado { get; set; }
        [PesoArchivoValidacion(PesoMaximoEnMegaBytes: 4)]
        [TipoArchivoValidacion(grupoTipoArchivo: GrupoTipoArchivo.Imagen)]
        public IFormFile? Foto { get; set; }

        //[PesoArchivoValidacion(PesoMaximoEnMegaBytes: 3)]
        //[TipoArchivoValidacion(grupoTipoArchivo: GrupoTipoArchivo.Pdf)]
        //public IFormFile ManualInstrucciones { get; set; }

        public int FamiliaId { get; set; }

    }
}
