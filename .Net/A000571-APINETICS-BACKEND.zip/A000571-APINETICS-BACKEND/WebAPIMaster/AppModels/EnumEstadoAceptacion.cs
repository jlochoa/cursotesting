﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.AppModels
{
    public enum EnumEstadoAceptacion
    {
        Aprobado = 171,
        Pendiente_Aceptacion = 172,
        Rechazado = 173
    }
}
