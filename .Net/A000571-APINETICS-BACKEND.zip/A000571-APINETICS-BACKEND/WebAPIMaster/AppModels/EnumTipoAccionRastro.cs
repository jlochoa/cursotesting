﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.AppModels
{
    public enum EnumTipoAccionRastro
    {
        Iniciar_sesion,
        Cerrar_sesion,
        Cambiar_password,
        Agregar,
        Modificar,
        Eliminar,
        Consultar,
        Cambiar_imagen,
        Ver_imagen,
        Acceso_Password_Incorrecto,
        DesbloquearUsuario,
        Actualizar,
        Descargar,
        Cambiar_Excel_Lista
    }
}
