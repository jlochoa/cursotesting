﻿namespace WebAPIMaster.AppModels
{
    public enum EnumTipoProcesoRastro
    {
        Usuarios,
        Inicio,
        Acceso,
        Empresa,
        Maestros,
        Permisos,
        Informe_BI,
        Dominios,
        Palabras_Clave,
        Competidores,
        Contactos,
        Lista_Contactos,
        Campañas,
        Parametros,
        ParametrosRRSS,
        Publicaciones,
        Roles,
        Versiones,

        // AÑADIDO DESDE HERAKLITO
        TiposEntidades,
        EntidadesDocumentos,
        Localidades,
        Paises,
        Provincias,
        LocalidadesES,
        Trabajadores,
        TrabajadoresDocumentos,
        Entidades,
    }
}
