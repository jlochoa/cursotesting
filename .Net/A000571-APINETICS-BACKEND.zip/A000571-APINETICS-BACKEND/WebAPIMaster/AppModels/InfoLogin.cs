﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.AppModels
{
    public class InfoLogin
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string reCaptchaToken {  get; set; }
    }

    public class TokenModel
    {
        public string UserName { get; set; }
        public string Token { get; set; }
        public string RefreshToken { get; set; }
    }

    public class RefreshTokenModel
    {
        public string Token { get; set; }
    }
}
