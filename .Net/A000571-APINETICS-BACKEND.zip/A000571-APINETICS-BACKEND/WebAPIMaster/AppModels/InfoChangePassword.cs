﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.AppModels
{
    public class InfoChangePassword
    {
        public string OldPass { get; set; }
        public string NewPass { get; set; }
        public string EmailLogin { get; set; }
    }
}
