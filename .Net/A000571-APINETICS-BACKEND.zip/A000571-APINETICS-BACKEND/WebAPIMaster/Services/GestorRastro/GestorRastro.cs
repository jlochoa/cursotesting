﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.Services.GestorRastro
{
    public class GestorRastro : IGestorRastro
    {
        private readonly ApineticsContext _context;
        private readonly IHttpContextAccessor _accessor;
        private readonly IHostEnvironment _hostEnvironment;

        public GestorRastro(ApineticsContext context, IHttpContextAccessor accessor, IHostEnvironment hostEnvironment)
        {
            _context = context;
            _accessor = accessor;
            _hostEnvironment = hostEnvironment;
        }

        public async Task<int> AddRastro(string usuario, Guid? Empresas_Id, EnumTipoProcesoRastro proceso, EnumTipoAccionRastro operacion, string observaciones, string tipo)
        {
                var Usuarios_Id = (from x in _context.Usuarios
                                 where x.Email == usuario
                                 select x.Id).SingleOrDefault();

                Rastro rastro = new Rastro()
                {
                    Empresas_Id = Empresas_Id,
                    FechaAccion = DateTime.Now,
                    Observaciones = observaciones,
                    Proceso = Enum.GetName(typeof(EnumTipoProcesoRastro), proceso),
                    Operacion = Enum.GetName(typeof(EnumTipoAccionRastro), operacion),
                    Usuarios_Id = Usuarios_Id,
                    Ip = _accessor.HttpContext.Connection.RemoteIpAddress.ToString(),
                    TipoLogout = tipo
                };

                if (rastro.TipoLogout != null && rastro.TipoLogout == "F")
                {
                    rastro.Ip = "Forzado";
                }

                await _context.Rastro.AddAsync(rastro);
                await _context.SaveChangesAsync();
            //}

            return await Task.FromResult(0);
        }
    }
}
