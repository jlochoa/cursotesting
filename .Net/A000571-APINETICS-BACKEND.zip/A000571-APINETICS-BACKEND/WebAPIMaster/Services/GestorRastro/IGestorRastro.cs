﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.Services.GestorRastro
{
    public interface IGestorRastro
    {
        Task<int> AddRastro(string usuario, Guid? Empresas_Id, EnumTipoProcesoRastro proceso, EnumTipoAccionRastro operacion, string observaciones, string tipo);
    }
}
