﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebAPIMaster.DataModelsBI;

public partial class EvolucionaContext : DbContext
{
    public EvolucionaContext()
    {
    }

    public EvolucionaContext(DbContextOptions<EvolucionaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AccesoBI> AccesoBI { get; set; }

    public virtual DbSet<Empresas> Empresas { get; set; }

    public virtual DbSet<Informes> Informes { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AccesoBI>(entity =>
        {
            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Password).HasMaxLength(1000);
            entity.Property(e => e.Usuario).HasMaxLength(1000);
        });

        modelBuilder.Entity<Empresas>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Empresas__3214EC07E1B57753");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CIF).HasMaxLength(16);
            entity.Property(e => e.Carpeta).HasMaxLength(100);
            entity.Property(e => e.Direccion).HasMaxLength(100);
            entity.Property(e => e.EmailEnvio).HasMaxLength(100);
            entity.Property(e => e.Fax).HasMaxLength(20);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Logo).HasMaxLength(400);
            entity.Property(e => e.Nombre).HasMaxLength(200);
            entity.Property(e => e.OpcionBotones)
                .HasMaxLength(1)
                .IsFixedLength();
            entity.Property(e => e.PasswordEnvio).HasMaxLength(50);
            entity.Property(e => e.ServidorEnvio).HasMaxLength(250);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
            entity.Property(e => e.Web).HasMaxLength(200);

            entity.HasOne(d => d.AccesoBI).WithMany(p => p.Empresas)
                .HasForeignKey(d => d.AccesoBI_Id)
                .HasConstraintName("FK_Empresas_AccesoBi");
        });

        modelBuilder.Entity<Informes>(entity =>
        {
            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.DatasetId).HasMaxLength(200);
            entity.Property(e => e.GroupId)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.ReportId)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.Titulo)
                .IsRequired()
                .HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Informes)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK__Informes__Empres__628FA481");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
