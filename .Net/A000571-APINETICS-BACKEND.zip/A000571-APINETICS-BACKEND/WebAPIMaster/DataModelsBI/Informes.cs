﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModelsBI;

public partial class Informes
{
    public Guid Id { get; set; }

    public string ReportId { get; set; }

    public string Titulo { get; set; }

    public string GroupId { get; set; }

    public string DatasetId { get; set; }

    public bool Multi { get; set; }

    public Guid? Empresas_Id { get; set; }

    public int? idAnt { get; set; }

    public virtual Empresas Empresas { get; set; }
}
