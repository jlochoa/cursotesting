﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModelsBI;

public partial class Empresas
{
    public Guid Id { get; set; }

    public string Nombre { get; set; }

    public string Logo { get; set; }

    public string CIF { get; set; }

    public string Direccion { get; set; }

    public int? CodigoPostal { get; set; }

    public string Fax { get; set; }

    public string Web { get; set; }

    public string EmailEnvio { get; set; }

    public string ServidorEnvio { get; set; }

    public int? PuertoEnvio { get; set; }

    public string PasswordEnvio { get; set; }

    public string OpcionBotones { get; set; }

    public int? TiempoEspera { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public string Carpeta { get; set; }

    public Guid? AccesoBI_Id { get; set; }

    public virtual AccesoBI AccesoBI { get; set; }

    public virtual ICollection<Informes> Informes { get; set; } = new List<Informes>();
}
