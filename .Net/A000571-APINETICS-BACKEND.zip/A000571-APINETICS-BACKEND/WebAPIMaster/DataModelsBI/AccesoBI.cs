﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModelsBI;

public partial class AccesoBI
{
    public string Usuario { get; set; }

    public string Password { get; set; }

    public Guid Id { get; set; }

    public int? idAnt { get; set; }

    public virtual ICollection<Empresas> Empresas { get; set; } = new List<Empresas>();
}
