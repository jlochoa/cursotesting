﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;
using WebAPIMaster.Middleware;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;
using WebAPIMaster.DataModelsBI;
using System;

namespace WebAPIMaster
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigins", builder =>
                {
                    //builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod().AllowCredentials().WithExposedHeaders("Token-Expired").Build();
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod().WithExposedHeaders("Token-Expired").Build();
                });
            });

            services.AddControllers();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IGestorRastro, GestorRastro>();
            services.AddTransient<IPasswords, Passwords>();

            var connection = Configuration.GetSection("ApineticsConnection").Value;
            services.AddDbContext<ApineticsContext>(options => options.UseSqlServer(connection));
            var connectionEvoluciona = Configuration.GetSection("EvolucionaNewConnection").Value;
            services.AddDbContext<EvolucionaContext>(options => options.UseSqlServer(connectionEvoluciona));

            var secret = Configuration.GetSection("AnSecret").Value;

            //importante para los errores que me daban de : Self referencing loop detected 
            //pero hacia todo bien
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            }).AddXmlSerializerFormatters();

            // Agregar funcionalidad tiempo real (SignalR. Ver middleware app.UseEndpoints)
            services.AddSignalR();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
              .AddJwtBearer(options =>
              {
                  options.TokenValidationParameters = new TokenValidationParameters
                  {
                      ValidateIssuer = true,
                      ValidateAudience = true,
                      ValidateLifetime = true,
                      ValidateIssuerSigningKey = true,

                      ValidIssuer = "http://pruebasissuer.com",
                      ValidAudience = "http://pruebasaudience.com",
                      IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret))
                  };

                  options.Events = new JwtBearerEvents
                  {
                      OnAuthenticationFailed = context =>
                      {
                          if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                          {
                              context.Response.Headers.Add("Token-Expired", "true");
                          }
                          return Task.CompletedTask;

                      }
                  };
              });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseAuthentication();
            app.UseFileServer();
            app.UseMiddleware<ExceptionMiddleware>();

            if (env.EnvironmentName != "Testing")
            {
                app.UseHttpsRedirection();
            }

            app.UseCors("AllowAllOrigins");

            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
