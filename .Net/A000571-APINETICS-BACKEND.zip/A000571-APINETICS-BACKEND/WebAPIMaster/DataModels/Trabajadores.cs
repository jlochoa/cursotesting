﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Trabajadores
{
    public Guid Id { get; set; }

    public Guid? Entidades_Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public Guid? Usuarios_Id { get; set; }

    public string Nombre { get; set; }

    public string Abreviatura { get; set; }

    public bool? Responsable { get; set; }

    public Guid? Maestros_IdDepartamento { get; set; }

    public DateTime? FechaAlta { get; set; }

    public DateTime? FechaBaja { get; set; }

    public bool? Activo { get; set; }

    public string Operario { get; set; }

    public int? CosteHora { get; set; }

    public int? TotalHoras { get; set; }

    public int? HorasDiarias { get; set; }

    public string Apellidos { get; set; }

    public int? Orden { get; set; }

    public int? IdFichaje { get; set; }

    public Guid? Horarios_Id { get; set; }

    public int? Horarios_IdAnt { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual Entidades Entidades { get; set; }

    public virtual Horarios Horarios { get; set; }

    public virtual Maestros Maestros { get; set; }

    public virtual Usuarios Usuarios { get; set; }

    public virtual ICollection<Calendario> Calendario { get; set; } = new List<Calendario>();
}
