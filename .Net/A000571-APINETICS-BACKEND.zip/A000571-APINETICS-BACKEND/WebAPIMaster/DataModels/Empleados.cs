﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Empleados
{
    public Guid Id { get; set; }

    public string Nombre { get; set; }

    public Guid? TiposEmpleado_Id { get; set; }

    public string Direccion { get; set; }

    public int? CodigoPostal { get; set; }

    public string TelefonoFijo { get; set; }

    public string TelefonoMovil { get; set; }

    public string Email { get; set; }

    public string UrlImagen { get; set; }

    public bool? Administrador { get; set; }

    public string Observaciones { get; set; }

    public string Usuarios_UserName { get; set; }

    public bool? Activo { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual Empresas Empresas { get; set; }
}
