﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class TiposMaestros
{
    public Guid Id { get; set; }

    public string Nombre { get; set; }

    public bool? Cliente { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public virtual ICollection<Maestros> Maestros { get; set; } = new List<Maestros>();
}
