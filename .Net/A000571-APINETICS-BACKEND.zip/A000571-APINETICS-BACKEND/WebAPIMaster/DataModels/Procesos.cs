﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Procesos
{
    public Guid Id { get; set; }

    public string Orden { get; set; }

    public string Descripcion { get; set; }

    public string Url { get; set; }

    public string Icono { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public virtual ICollection<Permisos> Permisos { get; set; } = new List<Permisos>();
}
