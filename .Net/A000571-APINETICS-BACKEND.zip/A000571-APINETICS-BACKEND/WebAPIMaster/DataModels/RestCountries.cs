﻿// Root myDeserializedClass = JsonConvert.DeserializeObject<List<Root>>(myJsonResponse);
using System.Collections.Generic;
using WebAPIMaster.DataModels;

public class Currencies
{
    public EUR EUR { get; set; }
}


public class EUR
{
    public string name { get; set; }
    public string symbol { get; set; }
}


public class Idd
{
    public string root { get; set; }
    public List<string> suffixes { get; set; }
}

public class RestCountries
{
    public Currencies currencies { get; set; }
    public Idd idd { get; set; }
    public Translations translations { get; set; }
    public string ccn3 { get; set; }
    public string cca3 { get; set; }
}

public class InfoPais
{
    public string Nombre { get; set; }
    public string CodigoNum { get; set; }
    public string CodigoAlfa3 { get; set; }
    public int? IdDivisa { get; set; }
}

public class Spa
{
    public string official { get; set; }
    public string common { get; set; }
}

public class Translations
{
    public Spa spa { get; set; }
}