﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class ParametrosRRSS
{
    public Guid Id { get; set; }

    public int? NumImgPermitidasLinkedin { get; set; }

    public int? NumImgPermitidasFacebook { get; set; }

    public int? NumImgPermitidasPinterest { get; set; }

    public int? NumImgPermitidasTiktok { get; set; }

    public int? NumImgPermitidasX { get; set; }

    public int? NumImgPermitidasInstagram { get; set; }

    public string FormatoVideoLinkedin { get; set; }

    public decimal? MaxSizeVideoLinkedin { get; set; }

    public decimal? MinSizeVideoLinkedin { get; set; }

    public decimal? MaxDuracionVideoLinkedin { get; set; }

    public decimal? MinDuracionVideoLinkedin { get; set; }

    public string FormatoImagenX { get; set; }

    public decimal? MaxSizeGifX { get; set; }

    public decimal? MaxSizeVideoX { get; set; }

    public decimal? MaxDuracionVideoX { get; set; }

    public decimal? MaxSizeImagenX { get; set; }

    public string MaxSizeImagenInstagram { get; set; }

    public string MinSizeImagenInstagram { get; set; }

    public string MaxSizeVideoInstagram { get; set; }

    public string MinSizeVideoInstagram { get; set; }

    public decimal? MaxDuracionVideoInstagram { get; set; }

    public decimal? MinDuracionVideoInstagram { get; set; }

    public string TodasValidacionesX { get; set; }

    public string TodasValidacionesInstagram { get; set; }

    public string TodasValidacionesLinkedin { get; set; }

    public string TodasValidacionesFacebook { get; set; }

    public string TodasValidacionesPinterest { get; set; }

    public string TodasValidacionesTiktok { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }
}
