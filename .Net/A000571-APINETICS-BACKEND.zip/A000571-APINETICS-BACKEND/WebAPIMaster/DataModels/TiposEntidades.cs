﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class TiposEntidades
{
    public Guid Id { get; set; }

    public string Descripcion { get; set; }

    public string DescCorta { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual ICollection<EntidadesTipos> EntidadesTipos { get; set; } = new List<EntidadesTipos>();
}
