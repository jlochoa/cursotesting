﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Maestros
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public Guid TiposMaestros_Id { get; set; }

    public string Descripcion { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public virtual ICollection<Calendario> Calendario { get; set; } = new List<Calendario>();

    public virtual Empresas Empresas { get; set; }

    public virtual TiposMaestros TiposMaestros { get; set; }

    public virtual ICollection<Trabajadores> Trabajadores { get; set; } = new List<Trabajadores>();
}
