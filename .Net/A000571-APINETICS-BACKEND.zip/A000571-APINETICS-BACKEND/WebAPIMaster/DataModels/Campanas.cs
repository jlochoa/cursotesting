﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Campanas
{
    public Guid Id { get; set; }

    public Guid Dominios_Id { get; set; }

    public Guid? ListasContactos_Id { get; set; }

    public string Codigo { get; set; }

    public string Nombre { get; set; }

    public string Asunto { get; set; }

    public string DeEmail { get; set; }

    public string DeNombre { get; set; }

    public string Contenido { get; set; }

    public DateTime? FechaHoraEnvio { get; set; }

    public bool? EnvioProgramado { get; set; }

    public bool? Enviado { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public string IdPlantilla { get; set; }

    public string IdCorreoEnvio { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string ContenidoHTML { get; set; }

    public virtual Dominios Dominios { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual ListasContactos ListasContactos { get; set; }
}
