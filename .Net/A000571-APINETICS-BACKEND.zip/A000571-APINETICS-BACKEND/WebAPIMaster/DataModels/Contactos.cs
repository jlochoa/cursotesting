﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Contactos
{
    public Guid Id { get; set; }

    public Guid Entidades_Id { get; set; }

    public string Nombre { get; set; }

    public string Apellido1 { get; set; }

    public string Apellido2 { get; set; }

    public int? Linea { get; set; }

    public string Cargo { get; set; }

    public string Direccion { get; set; }

    public Guid? Localidades_Id { get; set; }

    public int? CodigoPostal { get; set; }

    public Guid? Provincias_Id { get; set; }

    public Guid? Paises_Id { get; set; }

    public string Telefono { get; set; }

    public string Movil { get; set; }

    public string Fax { get; set; }

    public string Email { get; set; }

    public string Departamento { get; set; }

    public string UrlImagen { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual ICollection<ContactosCorreos> ContactosCorreos { get; set; } = new List<ContactosCorreos>();

    public virtual ICollection<ContactosTelefonos> ContactosTelefonos { get; set; } = new List<ContactosTelefonos>();

    public virtual Empresas Empresas { get; set; }

    public virtual Entidades Entidades { get; set; }

    public virtual Localidades Localidades { get; set; }

    public virtual Paises Paises { get; set; }

    public virtual Provincias Provincias { get; set; }
}
