﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Usuarios
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string Email { get; set; }

    public string Password { get; set; }

    public string Nombre { get; set; }

    public string Direccion { get; set; }

    public int? CodigoPostal { get; set; }

    public string TelefonoFijo { get; set; }

    public string TelefonoMovil { get; set; }

    public string UrlImagen { get; set; }

    public string IdMetricool { get; set; }

    public string Observaciones { get; set; }

    public bool? Activo { get; set; }

    public int? IntentosErroneos { get; set; }

    public bool? CierreSesionAlCerrarPagina { get; set; }

    public bool? SuperAdministrador { get; set; }

    public bool? Distribuidor { get; set; }

    public string RefreshToken { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public bool? Deshabilitado { get; set; }

    public Guid? Roles_Id { get; set; }

    public Guid? Entidades_Id { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual Entidades Entidades { get; set; }

    public virtual ICollection<Rastro> Rastro { get; set; } = new List<Rastro>();

    public virtual Roles Roles { get; set; }

    public virtual ICollection<Trabajadores> Trabajadores { get; set; } = new List<Trabajadores>();

    public virtual ICollection<UsuariosDistribuidores> UsuariosDistribuidores { get; set; } = new List<UsuariosDistribuidores>();
}
