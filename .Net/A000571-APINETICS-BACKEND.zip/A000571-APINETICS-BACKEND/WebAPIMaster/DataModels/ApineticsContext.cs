﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebAPIMaster.DataModels;

public partial class ApineticsContext : DbContext
{
    public ApineticsContext(DbContextOptions<ApineticsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Calendario> Calendario { get; set; }

    public virtual DbSet<Campanas> Campanas { get; set; }

    public virtual DbSet<Competidores> Competidores { get; set; }

    public virtual DbSet<Contactos> Contactos { get; set; }

    public virtual DbSet<ContactosCorreos> ContactosCorreos { get; set; }

    public virtual DbSet<ContactosTelefonos> ContactosTelefonos { get; set; }

    public virtual DbSet<Dominios> Dominios { get; set; }

    public virtual DbSet<Empresas> Empresas { get; set; }

    public virtual DbSet<EmpresasCorreos> EmpresasCorreos { get; set; }

    public virtual DbSet<EmpresasTelefonos> EmpresasTelefonos { get; set; }

    public virtual DbSet<Entidades> Entidades { get; set; }

    public virtual DbSet<EntidadesCorreos> EntidadesCorreos { get; set; }

    public virtual DbSet<EntidadesDocumentos> EntidadesDocumentos { get; set; }

    public virtual DbSet<EntidadesTelefonos> EntidadesTelefonos { get; set; }

    public virtual DbSet<EntidadesTipos> EntidadesTipos { get; set; }

    public virtual DbSet<Horarios> Horarios { get; set; }

    public virtual DbSet<ListasContactos> ListasContactos { get; set; }

    public virtual DbSet<Localidades> Localidades { get; set; }

    public virtual DbSet<Maestros> Maestros { get; set; }

    public virtual DbSet<Paises> Paises { get; set; }

    public virtual DbSet<PalabrasClave> PalabrasClave { get; set; }

    public virtual DbSet<Parametros> Parametros { get; set; }

    public virtual DbSet<ParametrosRRSS> ParametrosRRSS { get; set; }

    public virtual DbSet<Permisos> Permisos { get; set; }

    public virtual DbSet<Procesos> Procesos { get; set; }

    public virtual DbSet<Provincias> Provincias { get; set; }

    public virtual DbSet<Publicaciones> Publicaciones { get; set; }

    public virtual DbSet<Rastro> Rastro { get; set; }

    public virtual DbSet<Roles> Roles { get; set; }

    public virtual DbSet<TiposEntidades> TiposEntidades { get; set; }

    public virtual DbSet<TiposMaestros> TiposMaestros { get; set; }

    public virtual DbSet<Trabajadores> Trabajadores { get; set; }

    public virtual DbSet<Usuarios> Usuarios { get; set; }

    public virtual DbSet<UsuariosDistribuidores> UsuariosDistribuidores { get; set; }

    public virtual DbSet<Versiones> Versiones { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("bbdd_apinetics");

        modelBuilder.Entity<Calendario>(entity =>
        {
            entity.ToTable("Calendario", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

            entity.HasOne(d => d.Empresas).WithMany(p => p.Calendario)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Calendario_Empresas");

            entity.HasOne(d => d.Trabajadores).WithMany(p => p.Calendario)
                .HasForeignKey(d => d.Trabajadores_Id)
                .HasConstraintName("FK_Calendario_trabajadores");
        });

        modelBuilder.Entity<Campanas>(entity =>
        {
            entity.ToTable("Campanas", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Asunto).HasMaxLength(400);
            entity.Property(e => e.Codigo).HasMaxLength(200);
            entity.Property(e => e.Contenido).HasMaxLength(4000);
            entity.Property(e => e.ContenidoHTML).HasMaxLength(4000);
            entity.Property(e => e.DeEmail).HasMaxLength(100);
            entity.Property(e => e.DeNombre).HasMaxLength(200);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaHoraEnvio).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.IdPlantilla).HasMaxLength(50);
            entity.Property(e => e.Nombre).HasMaxLength(400);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Dominios).WithMany(p => p.Campanas)
                .HasForeignKey(d => d.Dominios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Campanas_Dominios");

            entity.HasOne(d => d.Empresas).WithMany(p => p.Campanas)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Campanas_Empresas");

            entity.HasOne(d => d.ListasContactos).WithMany(p => p.Campanas)
                .HasForeignKey(d => d.ListasContactos_Id)
                .HasConstraintName("FK_Campanas_ListasContactos");
        });

        modelBuilder.Entity<Competidores>(entity =>
        {
            entity.ToTable("Competidores", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion).HasMaxLength(200);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Dominios).WithMany(p => p.Competidores)
                .HasForeignKey(d => d.Dominios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Competidores_Dominios");
        });

        modelBuilder.Entity<Contactos>(entity =>
        {
            entity.ToTable("Contactos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Apellido1).HasMaxLength(100);
            entity.Property(e => e.Apellido2).HasMaxLength(100);
            entity.Property(e => e.Cargo).HasMaxLength(50);
            entity.Property(e => e.Departamento).HasMaxLength(50);
            entity.Property(e => e.Direccion).HasMaxLength(100);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Fax).HasMaxLength(20);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Movil).HasMaxLength(20);
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.Telefono).HasMaxLength(30);
            entity.Property(e => e.UrlImagen).HasMaxLength(250);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Contactos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Contactos_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.Contactos)
                .HasForeignKey(d => d.Entidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Contactos_Entidades");

            entity.HasOne(d => d.Localidades).WithMany(p => p.Contactos)
                .HasForeignKey(d => d.Localidades_Id)
                .HasConstraintName("FK_Contactos_Localidades");

            entity.HasOne(d => d.Paises).WithMany(p => p.Contactos)
                .HasForeignKey(d => d.Paises_Id)
                .HasConstraintName("FK_Contactos_Paises");

            entity.HasOne(d => d.Provincias).WithMany(p => p.Contactos)
                .HasForeignKey(d => d.Provincias_Id)
                .HasConstraintName("FK_Contactos_Provincias");
        });

        modelBuilder.Entity<ContactosCorreos>(entity =>
        {
            entity.ToTable("ContactosCorreos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Contactos).WithMany(p => p.ContactosCorreos)
                .HasForeignKey(d => d.Contactos_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ContactosCorreos_Contactos");

            entity.HasOne(d => d.Empresas).WithMany(p => p.ContactosCorreos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_ContactosCorreos_Empresas");
        });

        modelBuilder.Entity<ContactosTelefonos>(entity =>
        {
            entity.ToTable("ContactosTelefonos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Telefono).HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Contactos).WithMany(p => p.ContactosTelefonos)
                .HasForeignKey(d => d.Contactos_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ContactosTelefonos_Contactos");

            entity.HasOne(d => d.Empresas).WithMany(p => p.ContactosTelefonos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_ContactosTelefonos_Empresas");
        });

        modelBuilder.Entity<Dominios>(entity =>
        {
            entity.ToTable("Dominios", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.ApiKey).HasMaxLength(200);
            entity.Property(e => e.ApiSecret).HasMaxLength(200);
            entity.Property(e => e.Dominio).HasMaxLength(200);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Logo).HasMaxLength(400);
            entity.Property(e => e.Nombre).HasMaxLength(200);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Dominios)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Dominios_Empresas");
        });

        modelBuilder.Entity<Empresas>(entity =>
        {
            entity.ToTable("Empresas", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CIF).HasMaxLength(16);
            entity.Property(e => e.Direccion).HasMaxLength(100);
            entity.Property(e => e.EmailEnvio).HasMaxLength(100);
            entity.Property(e => e.Fax).HasMaxLength(20);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Logo).HasMaxLength(400);
            entity.Property(e => e.Nombre).HasMaxLength(200);
            entity.Property(e => e.OpcionBotones)
                .HasMaxLength(1)
                .IsFixedLength();
            entity.Property(e => e.PasswordEnvio).HasMaxLength(50);
            entity.Property(e => e.ServidorEnvio).HasMaxLength(250);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
            entity.Property(e => e.Web).HasMaxLength(200);

            entity.HasOne(d => d.Localidades).WithMany(p => p.Empresas)
                .HasForeignKey(d => d.Localidades_Id)
                .HasConstraintName("FK_Empresas_Localidades");
        });

        modelBuilder.Entity<EmpresasCorreos>(entity =>
        {
            entity.ToTable("EmpresasCorreos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Correo)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EmpresasCorreos)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EmpresasCorreos_Empresas");
        });

        modelBuilder.Entity<EmpresasTelefonos>(entity =>
        {
            entity.ToTable("EmpresasTelefonos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Telefono)
                .IsRequired()
                .HasMaxLength(20);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EmpresasTelefonos)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EmpresasTelefonos_Empresas");
        });

        modelBuilder.Entity<Entidades>(entity =>
        {
            entity.ToTable("Entidades", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Apellido1Conyuge).HasMaxLength(100);
            entity.Property(e => e.Apellido1Fisico).HasMaxLength(100);
            entity.Property(e => e.Apellido2Conyuge).HasMaxLength(100);
            entity.Property(e => e.Apellido2Fisico).HasMaxLength(100);
            entity.Property(e => e.Codigo)
                .HasMaxLength(20)
                .HasDefaultValueSql("(NULL)");
            entity.Property(e => e.CodigoPostal).HasDefaultValueSql("(NULL)");
            entity.Property(e => e.Contacto)
                .HasMaxLength(100)
                .IsFixedLength();
            entity.Property(e => e.Correl).HasMaxLength(50);
            entity.Property(e => e.DescCorta).HasMaxLength(100);
            entity.Property(e => e.Descripcion)
                .IsRequired()
                .HasMaxLength(200);
            entity.Property(e => e.Direccion)
                .HasMaxLength(100)
                .HasDefaultValueSql("(NULL)");
            entity.Property(e => e.EstadoTemp).HasMaxLength(50);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Localidades_Id).HasDefaultValueSql("(NULL)");
            entity.Property(e => e.NIFCIF).HasMaxLength(20);
            entity.Property(e => e.NIFConyuge).HasMaxLength(16);
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.NombreConyuge).HasMaxLength(100);
            entity.Property(e => e.NombreFisico).HasMaxLength(100);
            entity.Property(e => e.Observaciones)
                .HasMaxLength(200)
                .HasDefaultValueSql("(NULL)");
            entity.Property(e => e.Paises_Id).HasDefaultValueSql("(NULL)");
            entity.Property(e => e.Poblacion).HasMaxLength(100);
            entity.Property(e => e.Provincias_Id).HasDefaultValueSql("(NULL)");
            entity.Property(e => e.RazonSocial).HasMaxLength(100);
            entity.Property(e => e.Telefono).HasMaxLength(50);
            entity.Property(e => e.Tipo).HasMaxLength(2);
            entity.Property(e => e.UrlImagen)
                .HasMaxLength(250)
                .IsFixedLength();
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Entidades)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Entidades_Empresas");

            entity.HasOne(d => d.Localidades).WithMany(p => p.Entidades)
                .HasForeignKey(d => d.Localidades_Id)
                .HasConstraintName("FK_Entidades_Localidades");

            entity.HasOne(d => d.Paises).WithMany(p => p.Entidades)
                .HasForeignKey(d => d.Paises_Id)
                .HasConstraintName("FK_Entidades_Paises");

            entity.HasOne(d => d.Provincias).WithMany(p => p.Entidades)
                .HasForeignKey(d => d.Provincias_Id)
                .HasConstraintName("FK_Entidades_Provincias");
        });

        modelBuilder.Entity<EntidadesCorreos>(entity =>
        {
            entity.ToTable("EntidadesCorreos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EntidadesCorreos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_EntidadesCorreos_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.EntidadesCorreos)
                .HasForeignKey(d => d.Entidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EntidadesCorreos_Entidades");
        });

        modelBuilder.Entity<EntidadesDocumentos>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.ToTable("EntidadesDocumentos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion).HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.URL)
                .IsRequired()
                .HasMaxLength(200);
            entity.Property(e => e.UsuarioCreacion)
                .IsRequired()
                .HasMaxLength(50);
            entity.Property(e => e.UsuarioModificacion)
                .IsRequired()
                .HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EntidadesDocumentos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_EntidadesDocumentos_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.EntidadesDocumentos)
                .HasForeignKey(d => d.Entidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EntidadesDocumentos_Entidades");
        });

        modelBuilder.Entity<EntidadesTelefonos>(entity =>
        {
            entity.ToTable("EntidadesTelefonos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Telefono).HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EntidadesTelefonos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_EntidadesTelefonos_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.EntidadesTelefonos)
                .HasForeignKey(d => d.Entidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EntidadesTelefonos_Entidades");
        });

        modelBuilder.Entity<EntidadesTipos>(entity =>
        {
            entity.ToTable("EntidadesTipos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.EntidadesTipos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_EntidadesTipos_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.EntidadesTipos)
                .HasForeignKey(d => d.Entidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EntidadesTipos_Entidades");

            entity.HasOne(d => d.TiposEntidades).WithMany(p => p.EntidadesTipos)
                .HasForeignKey(d => d.TiposEntidades_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EntidadesTipos_TiposEntidades");
        });

        modelBuilder.Entity<Horarios>(entity =>
        {
            entity.ToTable("Horarios", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre)
                .IsRequired()
                .HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion)
                .IsRequired()
                .HasMaxLength(50);
            entity.Property(e => e.UsuarioModificacion)
                .IsRequired()
                .HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Horarios)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Horarios_Empresas");
        });

        modelBuilder.Entity<ListasContactos>(entity =>
        {
            entity.ToTable("ListasContactos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Address).HasMaxLength(100);
            entity.Property(e => e.Excel).HasMaxLength(2000);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(150);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Dominios).WithMany(p => p.ListasContactos)
                .HasForeignKey(d => d.Dominios_Id)
                .HasConstraintName("FK_ListasContactos_Dominios");

            entity.HasOne(d => d.Empresas).WithMany(p => p.ListasContactos)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ListasContactos_Empresas");
        });

        modelBuilder.Entity<Localidades>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Localida__3214EC0753D2ABDE");

            entity.ToTable("Localidades", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.EmpresasNavigation).WithMany(p => p.LocalidadesNavigation)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Localidades_Empresas");

            entity.HasOne(d => d.Provincias).WithMany(p => p.Localidades)
                .HasForeignKey(d => d.Provincias_Id)
                .HasConstraintName("FK_Localidades_Provincias");
        });

        modelBuilder.Entity<Maestros>(entity =>
        {
            entity.ToTable("Maestros", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion).HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Maestros)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Maestros_Empresas");

            entity.HasOne(d => d.TiposMaestros).WithMany(p => p.Maestros)
                .HasForeignKey(d => d.TiposMaestros_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Maestros_TiposMaestros");
        });

        modelBuilder.Entity<Paises>(entity =>
        {
            entity.ToTable("Paises", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CodAlfa3).HasMaxLength(3);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Paises)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Paises_Empresas");
        });

        modelBuilder.Entity<PalabrasClave>(entity =>
        {
            entity.ToTable("PalabrasClave", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion).HasMaxLength(200);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Dominios).WithMany(p => p.PalabrasClave)
                .HasForeignKey(d => d.Dominios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PalabrasClave_Dominios");
        });

        modelBuilder.Entity<Parametros>(entity =>
        {
            entity.ToTable("Parametros", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
        });

        modelBuilder.Entity<ParametrosRRSS>(entity =>
        {
            entity.ToTable("ParametrosRRSS", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.FormatoImagenX).HasMaxLength(500);
            entity.Property(e => e.FormatoVideoLinkedin).HasMaxLength(500);
            entity.Property(e => e.MaxDuracionVideoInstagram).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxDuracionVideoLinkedin).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxDuracionVideoX).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxSizeGifX).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxSizeImagenInstagram).HasMaxLength(500);
            entity.Property(e => e.MaxSizeImagenX).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxSizeVideoInstagram).HasMaxLength(500);
            entity.Property(e => e.MaxSizeVideoLinkedin).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MaxSizeVideoX).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MinDuracionVideoInstagram).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MinDuracionVideoLinkedin).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.MinSizeImagenInstagram).HasMaxLength(500);
            entity.Property(e => e.MinSizeVideoInstagram).HasMaxLength(500);
            entity.Property(e => e.MinSizeVideoLinkedin).HasColumnType("decimal(7, 3)");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
        });

        modelBuilder.Entity<Permisos>(entity =>
        {
            entity.ToTable("Permisos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(50);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Permisos)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Permisos_Empresas");

            entity.HasOne(d => d.Procesos).WithMany(p => p.Permisos)
                .HasForeignKey(d => d.Procesos_Id)
                .HasConstraintName("FK_Permisos_Procesos");

            entity.HasOne(d => d.Roles).WithMany(p => p.Permisos)
                .HasForeignKey(d => d.Roles_Id)
                .HasConstraintName("FK_Permisos_Roles");
        });

        modelBuilder.Entity<Procesos>(entity =>
        {
            entity.ToTable("Procesos", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion).HasMaxLength(60);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Icono).HasMaxLength(400);
            entity.Property(e => e.Orden).HasMaxLength(40);
            entity.Property(e => e.Url).HasMaxLength(400);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
        });

        modelBuilder.Entity<Provincias>(entity =>
        {
            entity.ToTable("Provincias", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Autonomia).HasMaxLength(50);
            entity.Property(e => e.Codigo).HasMaxLength(2);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Provincias)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Provincias_Empresas");

            entity.HasOne(d => d.Paises).WithMany(p => p.Provincias)
                .HasForeignKey(d => d.Paises_Id)
                .HasConstraintName("FK_Provincias_Paises");
        });

        modelBuilder.Entity<Publicaciones>(entity =>
        {
            entity.ToTable("Publicaciones", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.FechaPublicacion).HasColumnType("datetime");
            entity.Property(e => e.IdPublicacionMetricool).HasMaxLength(50);
            entity.Property(e => e.Redes).HasMaxLength(500);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Dominios).WithMany(p => p.Publicaciones)
                .HasForeignKey(d => d.Dominios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Publicaciones_Dominios");

            entity.HasOne(d => d.Empresas).WithMany(p => p.Publicaciones)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Publicaciones_Empresas");
        });

        modelBuilder.Entity<Rastro>(entity =>
        {
            entity.ToTable("Rastro", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaAccion).HasColumnType("datetime");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Ip).HasMaxLength(50);
            entity.Property(e => e.Observaciones).HasMaxLength(2000);
            entity.Property(e => e.Operacion).HasMaxLength(50);
            entity.Property(e => e.Proceso).HasMaxLength(50);
            entity.Property(e => e.TipoLogout)
                .HasMaxLength(1)
                .IsFixedLength();
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Rastro)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("PK_Rastro_Empresas");

            entity.HasOne(d => d.Usuarios).WithMany(p => p.Rastro)
                .HasForeignKey(d => d.Usuarios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("PK_Rastro_Usuarios");
        });

        modelBuilder.Entity<Roles>(entity =>
        {
            entity.ToTable("Roles", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Descripcion)
                .IsRequired()
                .HasMaxLength(50);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(50);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Roles)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Roles_Empresas");
        });

        modelBuilder.Entity<TiposEntidades>(entity =>
        {
            entity.ToTable("TiposEntidades", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.DescCorta).HasMaxLength(5);
            entity.Property(e => e.Descripcion).HasMaxLength(200);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.TiposEntidades)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_TiposEntidades_Empresas");
        });

        modelBuilder.Entity<TiposMaestros>(entity =>
        {
            entity.ToTable("TiposMaestros", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
        });

        modelBuilder.Entity<Trabajadores>(entity =>
        {
            entity.ToTable("Trabajadores", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Abreviatura).HasMaxLength(20);
            entity.Property(e => e.Apellidos).HasMaxLength(50);
            entity.Property(e => e.FechaAlta).HasColumnType("datetime");
            entity.Property(e => e.FechaBaja).HasColumnType("datetime");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.Operario).HasMaxLength(10);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(50);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(50);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Trabajadores)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Trabajadores_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.Trabajadores)
                .HasForeignKey(d => d.Entidades_Id)
                .HasConstraintName("FK_Trabajadores_Entidades");

            entity.HasOne(d => d.Horarios).WithMany(p => p.Trabajadores)
                .HasForeignKey(d => d.Horarios_Id)
                .HasConstraintName("FK_Trabajadores_Horarios");

            entity.HasOne(d => d.Maestros).WithMany(p => p.Trabajadores)
                .HasForeignKey(d => d.Maestros_IdDepartamento)
                .HasConstraintName("FK_Trabajadores_Maestros");

            entity.HasOne(d => d.Usuarios).WithMany(p => p.Trabajadores)
                .HasForeignKey(d => d.Usuarios_Id)
                .HasConstraintName("FK_Trabajadores_Usuarios");
        });

        modelBuilder.Entity<Usuarios>(entity =>
        {
            entity.ToTable("Usuarios", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Direccion).HasMaxLength(200);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.IdMetricool).HasMaxLength(100);
            entity.Property(e => e.Nombre).HasMaxLength(200);
            entity.Property(e => e.Observaciones).HasMaxLength(2000);
            entity.Property(e => e.Password).HasMaxLength(50);
            entity.Property(e => e.TelefonoFijo).HasMaxLength(20);
            entity.Property(e => e.TelefonoMovil).HasMaxLength(20);
            entity.Property(e => e.UrlImagen).HasMaxLength(250);
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.Empresas_Id)
                .HasConstraintName("FK_Usuarios_Empresas");

            entity.HasOne(d => d.Entidades).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.Entidades_Id)
                .HasConstraintName("FK_Usuarios_Entidades");

            entity.HasOne(d => d.Roles).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.Roles_Id)
                .HasConstraintName("FK_Usuarios_Roles");
        });

        modelBuilder.Entity<UsuariosDistribuidores>(entity =>
        {
            entity.ToTable("UsuariosDistribuidores", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);

            entity.HasOne(d => d.Empresas).WithMany(p => p.UsuariosDistribuidores)
                .HasForeignKey(d => d.Empresas_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UsuariosDistribuidores_Empresas");

            entity.HasOne(d => d.Usuarios).WithMany(p => p.UsuariosDistribuidores)
                .HasForeignKey(d => d.Usuarios_Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UsuariosDistribuidores_Usuarios");
        });

        modelBuilder.Entity<Versiones>(entity =>
        {
            entity.ToTable("Versiones", "dbo");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.FechaCreacion).HasColumnType("datetime");
            entity.Property(e => e.FechaModificacion).HasColumnType("datetime");
            entity.Property(e => e.UsuarioCreacion).HasMaxLength(100);
            entity.Property(e => e.UsuarioModificacion).HasMaxLength(100);
            entity.Property(e => e.Version)
                .IsRequired()
                .HasMaxLength(20);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
