﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Entidades
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string Codigo { get; set; }

    public string Tipo { get; set; }

    public string Nombre { get; set; }

    public string RazonSocial { get; set; }

    public string NombreFisico { get; set; }

    public string Apellido1Fisico { get; set; }

    public string Apellido2Fisico { get; set; }

    public string NombreConyuge { get; set; }

    public string Apellido1Conyuge { get; set; }

    public string Apellido2Conyuge { get; set; }

    public string NIFCIF { get; set; }

    public string NIFConyuge { get; set; }

    public string Descripcion { get; set; }

    public string DescCorta { get; set; }

    public string Direccion { get; set; }

    public Guid? Localidades_Id { get; set; }

    public int? CodigoPostal { get; set; }

    public Guid? Provincias_Id { get; set; }

    public Guid? Paises_Id { get; set; }

    public string Observaciones { get; set; }

    public string UrlImagen { get; set; }

    public string Poblacion { get; set; }

    public string Telefono { get; set; }

    public string Contacto { get; set; }

    public string Correl { get; set; }

    public bool? Estado { get; set; }

    public string EstadoTemp { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual ICollection<Contactos> Contactos { get; set; } = new List<Contactos>();

    public virtual Empresas Empresas { get; set; }

    public virtual ICollection<EntidadesCorreos> EntidadesCorreos { get; set; } = new List<EntidadesCorreos>();

    public virtual ICollection<EntidadesDocumentos> EntidadesDocumentos { get; set; } = new List<EntidadesDocumentos>();

    public virtual ICollection<EntidadesTelefonos> EntidadesTelefonos { get; set; } = new List<EntidadesTelefonos>();

    public virtual ICollection<EntidadesTipos> EntidadesTipos { get; set; } = new List<EntidadesTipos>();

    public virtual Localidades Localidades { get; set; }

    public virtual Paises Paises { get; set; }

    public virtual Provincias Provincias { get; set; }

    public virtual ICollection<Trabajadores> Trabajadores { get; set; } = new List<Trabajadores>();

    public virtual ICollection<Usuarios> Usuarios { get; set; } = new List<Usuarios>();
}
