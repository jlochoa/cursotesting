﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Localidades
{
    public Guid Id { get; set; }

    public Guid? Provincias_Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string Nombre { get; set; }

    public int? CodigoPostal { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual ICollection<Contactos> Contactos { get; set; } = new List<Contactos>();

    public virtual ICollection<Empresas> Empresas { get; set; } = new List<Empresas>();

    public virtual Empresas EmpresasNavigation { get; set; }

    public virtual ICollection<Entidades> Entidades { get; set; } = new List<Entidades>();

    public virtual Provincias Provincias { get; set; }
}
