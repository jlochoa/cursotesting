﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Empresas
{
    public Guid Id { get; set; }

    public string Nombre { get; set; }

    public string Logo { get; set; }

    public string CIF { get; set; }

    public string Direccion { get; set; }

    public int? CodigoPostal { get; set; }

    public string Fax { get; set; }

    public string Web { get; set; }

    public string EmailEnvio { get; set; }

    public string ServidorEnvio { get; set; }

    public int? PuertoEnvio { get; set; }

    public string PasswordEnvio { get; set; }

    public string OpcionBotones { get; set; }

    public int? TiempoEspera { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public bool? Activo { get; set; }

    public Guid? Localidades_Id { get; set; }

    public virtual ICollection<Calendario> Calendario { get; set; } = new List<Calendario>();

    public virtual ICollection<Campanas> Campanas { get; set; } = new List<Campanas>();

    public virtual ICollection<Contactos> Contactos { get; set; } = new List<Contactos>();

    public virtual ICollection<ContactosCorreos> ContactosCorreos { get; set; } = new List<ContactosCorreos>();

    public virtual ICollection<ContactosTelefonos> ContactosTelefonos { get; set; } = new List<ContactosTelefonos>();

    public virtual ICollection<Dominios> Dominios { get; set; } = new List<Dominios>();

    public virtual ICollection<EmpresasCorreos> EmpresasCorreos { get; set; } = new List<EmpresasCorreos>();

    public virtual ICollection<EmpresasTelefonos> EmpresasTelefonos { get; set; } = new List<EmpresasTelefonos>();

    public virtual ICollection<Entidades> Entidades { get; set; } = new List<Entidades>();

    public virtual ICollection<EntidadesCorreos> EntidadesCorreos { get; set; } = new List<EntidadesCorreos>();

    public virtual ICollection<EntidadesDocumentos> EntidadesDocumentos { get; set; } = new List<EntidadesDocumentos>();

    public virtual ICollection<EntidadesTelefonos> EntidadesTelefonos { get; set; } = new List<EntidadesTelefonos>();

    public virtual ICollection<EntidadesTipos> EntidadesTipos { get; set; } = new List<EntidadesTipos>();

    public virtual ICollection<Horarios> Horarios { get; set; } = new List<Horarios>();

    public virtual ICollection<ListasContactos> ListasContactos { get; set; } = new List<ListasContactos>();

    public virtual Localidades Localidades { get; set; }

    public virtual ICollection<Localidades> LocalidadesNavigation { get; set; } = new List<Localidades>();

    public virtual ICollection<Maestros> Maestros { get; set; } = new List<Maestros>();

    public virtual ICollection<Paises> Paises { get; set; } = new List<Paises>();

    public virtual ICollection<Permisos> Permisos { get; set; } = new List<Permisos>();

    public virtual ICollection<Provincias> Provincias { get; set; } = new List<Provincias>();

    public virtual ICollection<Publicaciones> Publicaciones { get; set; } = new List<Publicaciones>();

    public virtual ICollection<Rastro> Rastro { get; set; } = new List<Rastro>();

    public virtual ICollection<Roles> Roles { get; set; } = new List<Roles>();

    public virtual ICollection<TiposEntidades> TiposEntidades { get; set; } = new List<TiposEntidades>();

    public virtual ICollection<Trabajadores> Trabajadores { get; set; } = new List<Trabajadores>();

    public virtual ICollection<Usuarios> Usuarios { get; set; } = new List<Usuarios>();

    public virtual ICollection<UsuariosDistribuidores> UsuariosDistribuidores { get; set; } = new List<UsuariosDistribuidores>();
}
