﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Provincias
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string Codigo { get; set; }

    public string Nombre { get; set; }

    public string Autonomia { get; set; }

    public Guid? Paises_Id { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual ICollection<Contactos> Contactos { get; set; } = new List<Contactos>();

    public virtual Empresas Empresas { get; set; }

    public virtual ICollection<Entidades> Entidades { get; set; } = new List<Entidades>();

    public virtual ICollection<Localidades> Localidades { get; set; } = new List<Localidades>();

    public virtual Paises Paises { get; set; }
}
