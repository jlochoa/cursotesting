﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Dominios
{
    public Guid Id { get; set; }

    public Guid Empresas_Id { get; set; }

    public string Nombre { get; set; }

    public string Dominio { get; set; }

    public string Logo { get; set; }

    public int? IdGoogleA { get; set; }

    public int? IdSeRanking { get; set; }

    public int? IdMetricool { get; set; }

    public int? IdDominioGA { get; set; }

    public int? IdMailJet { get; set; }

    public bool? Facebook { get; set; }

    public bool? Instagram { get; set; }

    public bool? MyBusiness { get; set; }

    public bool? X { get; set; }

    public bool? LinkedIn { get; set; }

    public bool? Pinterest { get; set; }

    public bool? TikTok { get; set; }

    public bool? YouTube { get; set; }

    public bool? Twitch { get; set; }

    public bool? GoogleAds { get; set; }

    public bool? FacebookAds { get; set; }

    public bool? TikTokAds { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public string ApiKey { get; set; }

    public string ApiSecret { get; set; }

    public virtual ICollection<Campanas> Campanas { get; set; } = new List<Campanas>();

    public virtual ICollection<Competidores> Competidores { get; set; } = new List<Competidores>();

    public virtual Empresas Empresas { get; set; }

    public virtual ICollection<ListasContactos> ListasContactos { get; set; } = new List<ListasContactos>();

    public virtual ICollection<PalabrasClave> PalabrasClave { get; set; } = new List<PalabrasClave>();

    public virtual ICollection<Publicaciones> Publicaciones { get; set; } = new List<Publicaciones>();
}
