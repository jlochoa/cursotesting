﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Permisos
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public Guid? Procesos_Id { get; set; }

    public Guid? Roles_Id { get; set; }

    public bool? Visible { get; set; }

    public bool? Modificable { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual Procesos Procesos { get; set; }

    public virtual Roles Roles { get; set; }
}
