﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Parametros
{
    public Guid Id { get; set; }

    public int? IdAccesoBi { get; set; }

    public bool? SuperUsuario { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }
}
