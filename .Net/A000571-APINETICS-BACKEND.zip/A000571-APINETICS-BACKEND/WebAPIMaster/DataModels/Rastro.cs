﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Rastro
{
    public Guid Id { get; set; }

    public Guid? Empresas_Id { get; set; }

    public Guid Usuarios_Id { get; set; }

    public DateTime? FechaAccion { get; set; }

    public string Observaciones { get; set; }

    public string Proceso { get; set; }

    public string Operacion { get; set; }

    public string Ip { get; set; }

    public string TipoLogout { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public int? IdAnt { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual Usuarios Usuarios { get; set; }
}
