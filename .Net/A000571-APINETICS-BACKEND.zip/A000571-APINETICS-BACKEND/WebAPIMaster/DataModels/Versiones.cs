﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class Versiones
{
    public Guid Id { get; set; }

    public string Version { get; set; }

    public DateTime Fecha { get; set; }

    public string Notas { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime? FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }
}
