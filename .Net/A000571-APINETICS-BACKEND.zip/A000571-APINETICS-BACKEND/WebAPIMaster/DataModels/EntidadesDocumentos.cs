﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class EntidadesDocumentos
{
    public Guid Id { get; set; }

    public Guid Entidades_Id { get; set; }

    public Guid? Maestros_IdTipoDocumento { get; set; }

    public string URL { get; set; }

    public Guid? Empresas_Id { get; set; }

    public string UsuarioCreacion { get; set; }

    public DateTime FechaCreacion { get; set; }

    public string UsuarioModificacion { get; set; }

    public DateTime? FechaModificacion { get; set; }

    public string Descripcion { get; set; }

    public virtual Empresas Empresas { get; set; }

    public virtual Entidades Entidades { get; set; }
}
