﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOEmpresas
    {
        public Guid? Id { get; set; }
        public string Nombre { get; set; }
        public string Logo { get; set; }
        public string CIF { get; set; }
        public string Direccion { get; set; }
        public int? CodigoPostal { get; set; }
        public string Fax { get; set; }
        public string Web { get; set; }
        public string EmailEnvio { get; set; }
        public string ServidorEnvio { get; set; }
        public int? PuertoEnvio { get; set; }
        public string PasswordEnvio { get; set; }
        public string OpcionBotones { get; set; }
        public string UsuarioCreacion { get; set; }
        public DateTime? FechaCreacion { get; set; }
        public string UsuarioModificacion { get; set; }
        public DateTime? FechaModificacion { get; set; }

        public List<DTOEmpresasTelefonos> Telefonos { get; set; }
        public List<DTOEmpresasCorreos> Correos { get; set; }
    }
    public partial class DTOEmpresasTelefonos
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string Telefono { get; set; }
    }

    public partial class DTOEmpresasCorreos
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string Correo { get; set; }
    }

}
