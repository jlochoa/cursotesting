﻿using System;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOTrabajadoresDocumentos
    {
        public Guid? Id { get; set; }
        public Guid? Trabajadores_Id { get; set; }
        public string UrlDocumento { get; set; }
        public string Descripcion { get; set; }
        public Guid? Empresas_Id { get; set; }

        public string NombreTrabajadores { get; set; }
        public string NombreArchivo { get; set; }
    }

    public class IRutaTrabajadores
    {
        public string Url { get; set; }
    }
}
