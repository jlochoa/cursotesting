﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOProvincias
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string Codigo { get; set; }

        public string Nombre { get; set; }

        public string Autonomia { get; set; }

        public Guid? Paises_Id { get; set; }

        public string NombrePais { get; set; }
    }
}
