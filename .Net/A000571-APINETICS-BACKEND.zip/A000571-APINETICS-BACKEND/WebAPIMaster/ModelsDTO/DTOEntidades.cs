﻿using System;
using System.Collections.Generic;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOEntidades
    {
        public Guid? Id { get; set; }

        public string Codigo { get; set; }

        public string Tipo { get; set; }

        public string Nombre { get; set; }

        public string RazonSocial { get; set; }

        public string NombreFisico { get; set; }

        public string Apellido1Fisico { get; set; }

        public string Apellido2Fisico { get; set; }

        public string NIFCIF { get; set; }

        public string NombreConyuge { get; set; }

        public string Apellido1Conyuge { get; set; }

        public string Apellido2Conyuge { get; set; }

        public string NIFConyuge { get; set; }

        public string Descripcion { get; set; }

        public string DescCorta { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string Direccion { get; set; }

        public Guid? Localidades_Id { get; set; }

        public int? CodigoPostal { get; set; }

        public Guid? Provincias_Id { get; set; }

        public Guid? Paises_Id  { get; set; }

        public Guid? TiposEntidades_Id { get; set; }

        public string Observaciones { get; set; }

        public string Localidad { get; set; }

        public bool? Activa { get; set; }



        public List<DTOEntidadesTelefonos> Telefonos { get; set; }
        public List<DTOEntidadesCorreos> Correos { get; set; }
        public List<DTOEntidadesTipos> TiposEntidad { get; set; }


        public class DTOEntidadesTelefonos
        {
            public Guid? Id { get; set; }

            public Guid? Entidades_Id { get; set; }

            public string Telefono { get; set; }

            public Guid? Empresas_Id { get; set; }

        }

        public class DTOEntidadesCorreos
        {
            public Guid? Id { get; set; }

            public Guid? Entidades_Id { get; set; }

            public string Email { get; set; }

            public Guid? Empresas_Id { get; set; }
        }

        public class DTOEntidadesTipos
        {
            public Guid? Id { get; set; }

            public Guid? Entidades_Id { get; set; }

            public Guid? TiposEntidades_Id { get; set; }

            public Guid? Empresas_Id { get; set; }

            public string Descripcion { get; set; }
        }

    }
}
