﻿using System;

namespace WebAPIMaster.ModelsDTO
{
    public class DTODominios
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string Nombre { get; set; }

        public string Dominio { get; set; }

        public string Logo { get; set; }

        public int? IdGoogleA { get; set; }

        public int? IdSeRanking { get; set; }

        public int? IdMetricool { get; set; }

        public int? IdDominioGA { get; set; }

        public int? IdMailJet { get; set; }

        public bool? Facebook { get; set; }

        public bool? Instagram { get; set; }

        public bool? MyBusiness { get; set; }

        public bool? X { get; set; }

        public bool? LinkedIn { get; set; }

        public bool? Pinterest { get; set; }

        public bool? TikTok { get; set; }

        public bool? YouTube { get; set; }

        public bool? Twitch { get; set; }

        public bool? GoogleAds { get; set; }

        public bool? FacebookAds { get; set; }

        public bool? TikTokAds { get; set; }

        public string ApiKey { get; set; }

        public string ApiSecret { get; set; }

        public bool? TieneApiKey { get; set; }

        public bool? TieneSecretKey { get; set; }
    }
    public class DTOCompPalabrasClave
    {
        public Guid? Id { get; set; }
        public Guid? Dominios_Id { get; set; }
        public string Descripcion { get; set; }
        public int? IdSeRanking { get; set; }

    }
}
