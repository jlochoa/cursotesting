﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.DataModels;

public partial class DTOPublicaciones
{
    public Guid? Id { get; set; }

    public Guid Empresas_Id { get; set; }

    public Guid Dominios_Id { get; set; }

    public string Texto { get; set; }

    public DateTime? FechaPublicacion { get; set; }

    public bool Borrador { get; set; }

    public bool Publicado { get; set; }

    public string Redes { get; set; }

    public string IdPublicacionMetricool { get; set; }

    public string IdPublicacionAnt { get; set; }

}
