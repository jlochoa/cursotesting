﻿using System.Collections.Generic;
using System;
using WebAPIMaster.DataModels;
using static WebAPIMaster.ModelsDTO.DTOEntidades;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOTrabajadores
    {
        public Guid? Id { get; set; }
        public Guid? Empresas_Id { get; set; }
        public string Nombre { get; set; }
        public string Abreviatura { get; set; }
        public Guid? Maestros_IdDepartamento { get; set; }
        public Guid? Usuarios_Id { get; set; }
        public string Usuario { get; set; }
        public string Departamento { get; set; }
        public bool Responsable { get; set; }
        public DateTime? FechaAlta { get; set; }
        public DateTime? FechaBaja { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public bool Activo { get; set; }

        //AÑADIDO PARA TAREA

        public DTOEntidades Entidad { get; set; }
        public List<DTOEntidadesTelefonos> Telefonos { get; set; }
        public List<DTOEntidadesCorreos> Correos { get; set; }
        public Guid? Entidades_Id { get; set; }
        public string RazonSocial { get; set; }
        public string NIFCIF { get; set; }
        public string Direccion { get; set; }
        public int? CodigoPostal { get; set; }

        public Guid? Localidades_Id { get; set; }
        public string NombreConyuge { get; set; }
        public string ApellidosConyuge { get; set; }
        public string NIFConyuge { get; set; }
        public string Tipo { get; set; }
    }
}