﻿using System;
using System.Security.Policy;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOListasContactos
    {
        public Guid? Id { get; set; }

        public int? IdListaMailjet { get; set; }

        public Guid Empresas_Id { get; set; }

        public Guid? Dominios_Id { get; set; }

        public string Nombre { get; set; }

        public int? TotalContactos { get; set; }

        public string Excel { get; set; }

    }

    public class DTOContactosMJ
    {
        public string Email { get; set; }
        public string Nombre { get; set; }
        public Guid IdDominio { get; set; }
        public int IdListaContactos { get; set; }

    }
}
