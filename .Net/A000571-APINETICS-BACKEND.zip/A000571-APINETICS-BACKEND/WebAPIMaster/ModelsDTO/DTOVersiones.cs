﻿using System;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOVersiones
    {
        public Guid? Id { get; set; }

        public string Version { get; set; }

        public string Fecha { get; set; }

        public string Notas { get; set; }
    }
}
