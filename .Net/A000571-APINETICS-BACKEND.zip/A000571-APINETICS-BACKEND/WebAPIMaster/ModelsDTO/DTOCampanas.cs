﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOCampanas
    {
        public Guid? Id { get; set; }
        public Guid? Empresas_Id { get; set; }
        public Guid Dominios_Id { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Asunto { get; set; }
        public string DeEmail { get; set; }
        public string DeNombre { get; set; }
        public string Contenido { get; set; }
        public string ContenidoHTML { get; set; }
        public string IdPlantilla { get; set; }
        public string IdCorreoEnvio { get; set; }
        public Guid? ListasContactos_Id { get; set; }
        public DateTime? FechaHoraEnvio { get; set; }
        public bool? EnvioProgramado { get; set; }
        public bool? Enviado { get; set; }

        public string DescripcionDominio { get; set; }
        public string DescripcionListaContactos { get; set; }
    }

    public class DTOUploadPlantilla
    {
        public Guid IdDominio { get; set; }
        public string IdPlantilla { get; set; }
        public string NombrePlantilla { get; set; }
        public string ContenidoHTML { get; set; }
        public string DeNombre { get; set; }
        public string DeEmail { get; set; }
        public string Asunto { get; set; }
    }

    public class DTOPlantilla
    {
        public string Asunto { get; set; }
        public string DeNombre { get; set; }
        public string DeEmail { get; set; }
        public string IdCorreoEnvio { get; set; }
        public string Contenido { get; set; }
        public string ContenidoHTML { get; set; }

    }
}
