﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTODataCombo
    {
        public Guid Value { get; set; }
        public string Label { get; set; }
    }

    public class DTODataComboMC
    {
        public Guid Value { get; set; }
        public string Label { get; set; }
        public int? IdMetricool { get; set; }
    }
    public class DTODataComboP
    {
        public string Value { get; set; }
        public string Label { get; set; }
    }

    // AÑADIDO DESDE HERAKLITO
    public class DTODataComboLocalidad
    {
        public int Value { get; set; }
        public string Label { get; set; }
        public int? CP { get; set; }

    }

    public class DTODataComboLocalidadId
    {
        public Guid? Value { get; set; }
        public string Label { get; set; }
        public int? CP { get; set; }

    }
    public class DTODataComboTrabajadoresId
    {
        public Guid? Value { get; set; }
        public string Label { get; set; }
        public string Corto { get; set; }
    }


}
