﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTORastro
    {
        public Guid? Id { get; set; }
        public DateTime? FechaAccion { get; set; }
        public string Observaciones { get; set; }
        public string Proceso { get; set; }
        public string Operacion { get; set; }
        public Guid? Usuarios_Id { get; set; }
        public string Ip { get; set; }
        public Guid? Empesas_Id { get; set; }

        public string Nombre { get; set; }
        public string NombreUsuario { get; set; }
    }
}
