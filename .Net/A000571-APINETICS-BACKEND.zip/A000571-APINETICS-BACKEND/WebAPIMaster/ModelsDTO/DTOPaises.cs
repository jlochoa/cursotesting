﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOPaises
    {
        public Guid? Id { get; set; }
        public string Nombre { get; set; }
        public bool? Spain { get; set; }
        public Guid? Divisas_Id { get; set; }
        public bool? Cee { get; set; }
        public Guid? Empresas_Id { get; set; }
        public int? CodPais { get; set; }

        public string NombreDivisa { get; set; }
    }
}

