﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOLocalidades
    {
        public Guid? Id { get; set; }

        public string Nombre { get; set; }

        public Guid? Provincias_Id { get; set; }

        public int? CodigoPostal { get; set; }

        public Guid? Empresas_Id { get; set; }

        public string NombreProvincia { get; set; }
    }
}
