﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTORoles
    {
        public Guid? Id { get; set; }

        public string Descripcion { get; set; }

        public int? Nivel { get; set; }

        public Guid? Empresas_Id { get; set; }
    }
}
