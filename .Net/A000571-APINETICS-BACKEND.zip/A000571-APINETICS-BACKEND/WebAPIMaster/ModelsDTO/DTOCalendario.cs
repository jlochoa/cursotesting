﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOCalendario
    {
        public List<DTODiaCalendario> calendario { get; set; }
    }

    public class DTODiaCalendario
    {
        public Guid? Id { get; set; }
        public DateTime Fecha { get; set; }
        public Guid? Trabajadores_Id { get; set; }
        public Guid? Empresas_Id { get; set; }
        public string Abreviatura { get; set; }
    }
}
