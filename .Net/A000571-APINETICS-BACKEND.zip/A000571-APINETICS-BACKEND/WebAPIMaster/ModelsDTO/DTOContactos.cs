﻿using System;
using System.Collections.Generic;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOContactos
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public Guid? Entidades_Id { get; set; }

        public string Entidad { get; set; }

        public string Nombre { get; set; }

        public string Apellido1 { get; set; }

        public string Apellido2 { get; set; }

        public string Direccion { get; set; }

        public Guid? Localidades_Id { get; set; }

        public int? CodigoPostal { get; set; }

        public Guid? Provincias_Id { get; set; }

        public Guid? Paises_Id { get; set; }

        public string Telefono { get; set; }

        public string Movil { get; set; }

        public string Fax { get; set; }

        public string Email { get; set; }

        public string UrlImagen { get; set; }

        public string Maestros_IdDepartamento { get; set; }

        public string Cargo { get; set; }

        public Guid? Maestros_IdClasif1 { get; set; }
        public Guid? Maestros_IdClasif2 { get; set; }

        public string Clasif1 { get; set; }

        public string Clasif2 { get; set; }


        public List<DTOContactosTelefonos> Telefonos { get; set; }
        public List<DTOContactosCorreos> Correos { get; set; }
    }

    public class DTOContactosTelefonos
    {
        public Guid? Id { get; set; }

        public Guid? Contactos_Id { get; set; }

        public string Telefono { get; set; }

        public Guid? Empresas_Id { get; set; }

    }

    public class DTOContactosCorreos
    {
        public Guid? Id { get; set; }

        public Guid? Contactos_Id { get; set; }

        public string Email { get; set; }

        public Guid? Empresas_Id { get; set; }
    }
}
