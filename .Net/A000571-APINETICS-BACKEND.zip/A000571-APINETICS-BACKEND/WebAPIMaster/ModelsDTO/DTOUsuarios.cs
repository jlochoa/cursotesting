﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static WebAPIMaster.ModelsDTO.DTOEntidades;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOUsuarios
    {
        public Guid? Id { get; set; }
        public Guid? Entidades_Id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public int? CodigoPostal { get; set; }
        public string Telefono { get; set; }
        public string TelefonoFijo { get; set; }
        public string TelefonoMovil { get; set; }
        public string Email { get; set; }
        public string UrlImagen { get; set; }
        public bool? SuperAdministrador { get; set; }
        public string Observaciones { get; set; }
        public bool? Activo { get; set; }
        public Guid? Empresas_Id { get; set; }
        public bool? Distribuidor { get; set; }
        public string Password { get; set; }
        public string IdMetricool { get; set; }
        public Guid? Roles_Id { get; set; }
        public string RefreshToken { get; set; }
        public int? IntentosErroneos { get; set; }
        public bool? SesionActiva { get; set; }

        public string NombreRol { get; set; }
        public List<Guid> Empresas { get; set; }
        public string RazonSocial { get; set; }
        public string NIFCIF { get; set; }
        public Guid? Localidades_Id { get; set; }
        public DTOEntidades Entidad { get; set; }
        public string Tipo { get; set; }
        public string NombreConyuge { get; set; }
        public string ApellidosConyuge { get; set; }
        public string NIFConyuge { get; set; }
        public string CuentaContable { get; set; }
        public string Telefononue { get; set; }


        public List<DTOEntidadesTelefonos> Telefonos { get; set; }
        public List<DTOEntidadesCorreos> Correos { get; set; }
    }
}

