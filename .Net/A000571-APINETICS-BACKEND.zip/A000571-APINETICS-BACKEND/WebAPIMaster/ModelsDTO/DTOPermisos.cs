﻿using System;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOPermisos
    {
        public Guid? Id { get; set; }

        public Guid? Empresas_Id { get; set; }

        public Guid Procesos_Id { get; set; }

        public Guid? Roles_Id { get; set; }

        public bool? Visible { get; set; }

        public bool? Modificable { get; set; }

        public string Orden { get; set; }
    }
}
