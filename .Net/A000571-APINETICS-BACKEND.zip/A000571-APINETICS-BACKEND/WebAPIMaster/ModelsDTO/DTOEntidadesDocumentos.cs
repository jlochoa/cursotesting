﻿using System;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOEntidadesDocumentos
    {
        public Guid? Id { get; set; }
        public Guid? Entidad_Id { get; set; }
        public string UrlDocumento { get; set; }
        public string Descripcion { get; set; }
        public Guid? Empresas_Id { get; set; }

        public string NombreEntidad { get; set; }
        public string NombreArchivo { get; set; }
    }

    public class IRutaEntidades
    {
        public string Url { get; set; }
    }
}
