﻿using System;

namespace WebAPIMaster.ModelsDTO
{
    public class DTOTiposEntidades
    {
        public Guid? Id { get; set; }

        public string Descripcion { get; set; }

        public string DescCorta { get; set; }

        public Guid? Empresas_Id { get; set; }
    }
}
