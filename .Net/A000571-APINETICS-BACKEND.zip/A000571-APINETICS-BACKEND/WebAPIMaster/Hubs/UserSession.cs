﻿namespace WebAPIMaster.Hubs
{
    public class UserSession
    {
        public string Id { get; set; }
        public string User { get; set; }
    }
}
