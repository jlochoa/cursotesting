﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebAPIMaster.Hubs
{
    public interface ISession
    {
        Task CloseSession();
    }
}
