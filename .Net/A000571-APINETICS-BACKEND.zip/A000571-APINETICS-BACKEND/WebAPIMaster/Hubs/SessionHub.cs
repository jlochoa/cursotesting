﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Hubs
{
    public class SessionHub : Hub<ISession>
    {
        private readonly ApineticsContext _context;

        public SessionHub(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
        }


        // UsersOnLine es una lista de usuarios autenticados
        // Cada login se agrega el usuario. Cada logout o desconexión fortuita es controlada
        // borrando el usuario conectado de la lista
        public static List<UserSession> UsersOnLine { get; set; } = new List<UserSession>();
        // Evento LoginUser. Aquí llegamos cuando hay un login. Recibimos el usuario
        public async Task LoginUser(string user)
        {
            var usuario = await (from x in _context.Usuarios
                                 where x.Email == user
                                 select x).FirstOrDefaultAsync();
            // Revisamos si hay otras sesiones abiertas con el mismo email
            var pasar = (usuario.SuperAdministrador ?? false);
            if (!pasar)
            {
                var oldUsers = UsersOnLine.Where(x => x.User == user).ToList();
                foreach (var oldUser in oldUsers)
                {
                    // A todos les ordenamos cerrar sesión
                    await Clients.Client(oldUser.Id).CloseSession();
                }
                // A los usuarios que les hemos cerrado sesión los eliminamos de la lista UsersOnLine
                foreach (var oldUser in oldUsers)
                {
                    UsersOnLine.Remove(oldUser);
                }
                // Agregamos el nuevo usuario (el que se ha autenticado)
                // Context.ConnectionId es el id autogenerado por signalr
                UsersOnLine.Add(new UserSession { Id = Context.ConnectionId, User = user });

            }
        }

        // Evento LogoutUser. Aquí llegamos cuando hay un logout. Recibimos el usuario
        public async Task LogoutUser(string user)
        {
            var usuario = await (from x in _context.Usuarios
                                 where x.Email == user
                                 select x).FirstOrDefaultAsync();
            // Revisamos si hay otras sesiones abiertas con el mismo email
            var pasar = (usuario.SuperAdministrador ?? false);
            if (!pasar)
            {
                // Eliminamos el usuario de la lista
                var userLogout = UsersOnLine.FirstOrDefault(x => x.Id == Context.ConnectionId);
                if (userLogout != null)
                {
                    UsersOnLine.Remove(userLogout);
                }
                // Al igual que en Login, cerramos sesión a otras sesiones abiertas con el mismo usuario
                var oldUsers = UsersOnLine.Where(x => x.User == user).ToList();
                foreach (var oldUser in oldUsers)
                {
                    await Clients.Client(oldUser.Id).CloseSession();
                }
                foreach (var oldUser in oldUsers)
                {
                   UsersOnLine.Remove(oldUser);
                }
            }
        }

        // Aquí llegaremos cuando un usuario recargue la página o cierre el navegador
        // y lo vuelva a abrir en una url que no sea el login
        // Debemos comprobar si ya hay una sesión abierta en otro sitio
        // Si ya hay una sesión abierta, le enviamos a login
        public async Task ReloadUser(string user)
        {
            var usuario = await (from x in _context.Usuarios
                                 where x.Email == user
                                 select x).FirstOrDefaultAsync();
            // Revisamos si hay otras sesiones abiertas con el mismo email
            var pasar = (usuario.SuperAdministrador ?? false);
            if (!pasar)
            {
                // Miramos si hay un usuario en la lista de UsersOnLine
                var userReload = UsersOnLine.FirstOrDefault(x => x.User == user);
                if (userReload != null)
                {
                    // Si lo hay ordenamos cerrar sesión al usuario
                    await Clients.Client(Context.ConnectionId).CloseSession();
                }
                else
                {
                    // Si el usuario no existe en UsersOnLine, será porque no hay otra sesión
                    // abierta con ese usuario, luego lo agregamos a la lista
                    UsersOnLine.Add(new UserSession { Id = Context.ConnectionId, User = user });
                }
            }
        }

        // OnDisconnectedAsync se ejecuta automáticamente cuando un usuario se desconecta
        // Se ha utilizado para controlar la actualización de la web.
        // Al actualizarse se produce una desconexión/conexión
        public override async Task OnDisconnectedAsync(Exception exception)
        {
            // Eliminamos el usuario de la lista
            var oldUser = UsersOnLine.Where(x => x.Id == Context.ConnectionId).FirstOrDefault();
            var usuario = await (from x in _context.Usuarios
                                 where x.Email == oldUser.User
                                 select x).FirstOrDefaultAsync();
            // Revisamos si hay otras sesiones abiertas con el mismo email
            var pasar = (usuario.SuperAdministrador ?? false);
            if (!pasar)
            {
                UsersOnLine.Remove(oldUser);
                await base.OnDisconnectedAsync(exception);
            }
        }
    }
}
