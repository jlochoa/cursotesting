﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TiposMaestrosController : ControllerBase
    {
        private readonly ApineticsContext _context;

        public TiposMaestrosController(ApineticsContext context)
        {
            _context = context;
        }

        // GET: api/TipoMaestros
        [HttpGet("combo")]
        public async Task<IActionResult> GetTiposMaestrosCombo()
        {
            var tiposMaestros = await (from x in _context.TiposMaestros
                                       where x.Cliente == true
                                       select new DTODataCombo
                                       {
                                           Value = x.Id,
                                           Label = x.Nombre,
                                       }).ToListAsync();

            return Ok(tiposMaestros);
        }

    }
}