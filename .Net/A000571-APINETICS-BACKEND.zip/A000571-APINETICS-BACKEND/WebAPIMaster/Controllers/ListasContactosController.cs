﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Mailjet.Client.Resources;
using Mailjet.Client;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using System.Drawing.Printing;
using WebAPIMaster.Services.Passwords;
using Microsoft.Extensions.Configuration;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Net;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using System.Globalization;
using CsvHelper.Configuration;
using Azure;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ListasContactosController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IWebHostEnvironment _server;
        private readonly IConfiguration _configuration;
        private readonly IGestorRastro _gestorRastro;
        private readonly IPasswords _passwords;

        public ListasContactosController(ApineticsContext context, IWebHostEnvironment env, IConfiguration configuration, IGestorRastro gestorRastro, IPasswords passwords)
        {
            _context = context;
            _server = env;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
            _passwords = passwords;
        }

        // GET: api/ListasContactos
        [HttpGet("combo/{idDominio}")]
        public async Task<IActionResult> GetListasContactosCombo([FromRoute] Guid idDominio)
        {
            var listaContactos = await (from x in _context.ListasContactos
                                        where x.Dominios_Id == idDominio
                                        orderby x.Nombre
                                        select new DTODataCombo
                                        {
                                            Value = x.Id,
                                            Label = x.Nombre,
                                        }).ToListAsync();

            return Ok(listaContactos);
        }

        // GET: api/ListasContactos
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetListasContactosByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var listaContactosC = await (from x in _context.ListasContactos
                                         where x.Empresas_Id == idEmpresa
                                         select new DTOListasContactos
                                         {
                                             Id = x.Id,
                                             Nombre = x.Nombre,
                                             Empresas_Id = x.Empresas_Id,
                                             Dominios_Id = x.Dominios_Id,
                                             IdListaMailjet = x.IdListaMailjet,
                                             TotalContactos = x.TotalContactos,
                                             Excel = x.Excel
                                         }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(listaContactosC);
        }

        // GET: api/ListasContactos
        [HttpGet("mailjet/{idDominio}")]
        public async Task<IActionResult> GetListaContactos(Guid idDominio)
        {
            try
            {
                var dominio = await _context.Dominios.FindAsync(idDominio);

                if (dominio.ApiKey == null || dominio.ApiSecret == null)
                {
                    return Conflict("No se pueden obtener las listas de contactos porque el superadministrador aún no ha configurado el emailing para este dominio. Por favor, inténtalo más tarde o contacta con el administrador para obtener asistencia.");
                }

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);
                var listaContactos = new List<DTOListasContactos>();

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contactslist.Resource,
                    Filters = new Dictionary<string, string> { { "Limit", "1000" } }
                };

                MailjetResponse response = await client.GetAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var data = response.GetData();

                    foreach (var contactList in data)
                    {
                        listaContactos.Add(new DTOListasContactos
                        {
                            Id = null,
                            IdListaMailjet = Int32.Parse(contactList["ID"].ToString()),
                            Nombre = contactList["Name"].ToString(),
                            TotalContactos = Int32.Parse(contactList["SubscriberCount"].ToString()),
                            Dominios_Id = dominio.Id,
                            Empresas_Id = dominio.Empresas_Id
                        });
                    }

                    listaContactos = listaContactos.OrderBy(contact => contact.Nombre).ToList();

                    return Ok(listaContactos);
                }
                else
                {
                    return StatusCode((int)response.StatusCode, "Error al obtener las listas de contactos de Mailjet");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        [HttpGet("mailjet/bulk/{idDominio}")]
        public async Task<IActionResult> PostTodasListasContactos([FromRoute] Guid idDominio)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                // Obtener los dominios con API Key y Secret válidos
                var dominios = await _context.Dominios.Where(x => x.ApiKey != null && x.ApiSecret != null).ToListAsync();

                var listaContactosC = new List<DTOListasContactos>();
                var idsActualizados = new HashSet<int>();

                foreach (var dominio in dominios)
                {
                    string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                    string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                    MailjetClient client = new MailjetClient(apiKey, apiSecret);

                    MailjetRequest request = new MailjetRequest
                    {
                        Resource = Contactslist.Resource,
                        Filters = new Dictionary<string, string> { { "Limit", "1000" } }
                    };

                    MailjetResponse response = await client.GetAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var data = response.GetData();

                        foreach (var contactList in data)
                        {
                            int idListaMailjet = (int)contactList["ID"];
                            idsActualizados.Add(idListaMailjet); // Rastrear los IDs actualizados

                            // Verificar si el registro ya existe
                            var listaContactoExistente = await _context.ListasContactos
                                .FirstOrDefaultAsync(x => x.IdListaMailjet == idListaMailjet);

                            if (listaContactoExistente != null)
                            {
                                // Actualizar el registro existente
                                listaContactoExistente.Nombre = contactList["Name"].ToString();
                                listaContactoExistente.Address = contactList["Address"].ToString();
                                listaContactoExistente.TotalContactos = (int)contactList["SubscriberCount"];
                                listaContactoExistente.Excel = contactList["ID"] + "_Contactos.csv";
                                listaContactoExistente.UsuarioModificacion = User.Identity.Name;
                                listaContactoExistente.FechaModificacion = DateTime.Now;
                            }
                            else
                            {
                                // Insertar un nuevo registro
                                var nuevoContacto = new ListasContactos
                                {
                                    Nombre = contactList["Name"].ToString(),
                                    Address = contactList["Address"].ToString(),
                                    IdListaMailjet = idListaMailjet,
                                    TotalContactos = (int)contactList["SubscriberCount"],
                                    Excel = contactList["ID"] + "_Contactos.csv",
                                    UsuarioCreacion = User.Identity.Name,
                                    FechaCreacion = DateTime.Parse(contactList["CreatedAt"].ToString()),
                                    UsuarioModificacion = User.Identity.Name,
                                    FechaModificacion = DateTime.Now,
                                    Dominios_Id = dominio.Id,
                                    Empresas_Id = dominio.Empresas_Id
                                };
                                await _context.ListasContactos.AddAsync(nuevoContacto);
                            }
                        }
                    }
                    else
                    {
                        return StatusCode((int)response.StatusCode, "Error al obtener las listas de contactos de Mailjet");
                    }
                }

                // Guardar cambios de las actualizaciones e inserciones
                await _context.SaveChangesAsync();

                // Eliminar registros que ya no están presentes en los datos de Mailjet
                var idsExistentes = await _context.ListasContactos
                    .Where(x => x.Dominios_Id == idDominio)
                    .Select(x => (int)x.IdListaMailjet)
                    .ToListAsync();

                var idsAEliminar = idsExistentes.Except(idsActualizados.ToList()).ToList();
                var registrosAEliminar = await _context.ListasContactos
                    .Where(x => idsAEliminar.Contains((int)x.IdListaMailjet))
                    .ToListAsync();

                _context.ListasContactos.RemoveRange(registrosAEliminar);
                await _context.SaveChangesAsync();

                // Generar respuesta con los registros actualizados
                listaContactosC = await (from x in _context.ListasContactos
                                         where x.Dominios_Id == idDominio
                                         orderby x.Nombre
                                         select new DTOListasContactos
                                         {
                                             Id = x.Id,
                                             Nombre = x.Nombre,
                                             Empresas_Id = x.Empresas_Id,
                                             Dominios_Id = x.Dominios_Id,
                                             IdListaMailjet = x.IdListaMailjet,
                                             TotalContactos = x.TotalContactos,
                                             Excel = x.Excel
                                         }).ToListAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, dominios.First().Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Agregar, "Bulk import Mailjet", null);

                transaction.Commit();
                return Ok(listaContactosC);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // GET: api/ListasContactos
        [HttpGet("contactos/{idDominio}/{idListaContactos}")]
        public async Task<IActionResult> GetListaContactos(Guid idDominio, int idListaContactos)
        {
            try
            {
                var dominio = await _context.Dominios.FindAsync(idDominio);
                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);
                var contactos = new List<DTOContactosMJ>();

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contact.Resource,
                    Filters = new Dictionary<string, string> {
                        { "Limit", "1000" },
                        { "ContactsList", idListaContactos.ToString() }
                    }
                };

                MailjetResponse response = await client.GetAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var data = response.GetData();

                    foreach (var contact in data)
                    {
                        contactos.Add(new DTOContactosMJ
                        {
                            Nombre = contact["Name"].ToString(),
                            Email = contact["Email"].ToString(),
                            IdDominio = idDominio,
                            IdListaContactos = idListaContactos
                        });
                    }

                    contactos = contactos.OrderBy(contact => contact.Nombre).ToList();

                    return Ok(contactos);
                }
                else
                {
                    return StatusCode((int)response.StatusCode, "Error al obtener los contactos de esta lista de Mailjet");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        [HttpGet, Route("downloadExcel/{idListaContactos}")]
        public async Task<IActionResult> DownloadExcel([FromRoute] Guid idListaContactos)
        {
            var listaContactos = await _context.ListasContactos.FindAsync(idListaContactos);
            if (listaContactos == null)
            {
                return Conflict("Error al acceder a los datos de la lista");
            }

            try
            {
                var dominio = await _context.Dominios.FindAsync(listaContactos.Dominios_Id);

                if (dominio == null)
                {
                    return Conflict("Esta lista no está asignada a ningún dominio");
                }

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contact.Resource,
                }
                .Filter(Contact.ContactsList, listaContactos.IdListaMailjet.ToString())
                .Filter(Contact.Limit, 1000);

                MailjetResponse response = await client.GetAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var contactos = new List<DTOContactosMJ>();
                    foreach (var item in response.GetData())
                    {
                        contactos.Add(new DTOContactosMJ
                        {
                            Email = item["Email"].ToString(),
                            Nombre = item["Name"].ToString()
                        });
                    }

                    // Genera el archivo CSV
                    var fileName = $"{listaContactos.IdListaMailjet}_Contactos.csv";
                    var filePath = Path.Combine(Path.GetTempPath(), fileName);

                    var config = new CsvHelper.Configuration.CsvConfiguration(CultureInfo.InvariantCulture)
                    {
                        Delimiter = ";" // Establece el delimitador a ";"
                    };

                    using (var writer = new StreamWriter(filePath))
                    using (var csv = new CsvHelper.CsvWriter(writer, config))
                    {
                        csv.Context.Configuration.Delimiter = ";";
                        csv.WriteRecords(contactos);
                    }

                    // Devuelve el archivo al cliente
                    var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
                    return File(fileBytes, "text/csv", fileName);
                }
                else
                {
                    return StatusCode((int)response.StatusCode, "Error al obtener las listas de contactos de Mailjet");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // POST: api/ListasContactos
        [HttpPut("mailjet")]
        public async Task<IActionResult> PutListaContactoMailjet([FromBody] DTOListasContactos listaContacto)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var dominio = await _context.Dominios.FindAsync(listaContacto.Dominios_Id);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contactslist.Resource,
                    ResourceId = ResourceId.Numeric((int)listaContacto.IdListaMailjet)
                }.Property(Contactslist.Name, listaContacto.Nombre);

                MailjetResponse response = await client.PutAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var data = response.GetData();
                    var listaContactoEdit = await _context.ListasContactos.Where(x => x.IdListaMailjet == listaContacto.IdListaMailjet).FirstOrDefaultAsync();

                    if (listaContactoEdit != null)
                    {
                        listaContactoEdit.Nombre = data[0]["Name"].ToString();
                        listaContactoEdit.Address = data[0]["Address"].ToString();
                        listaContactoEdit.IdListaMailjet = (int)data[0]["ID"];
                        listaContactoEdit.TotalContactos = (int)data[0]["SubscriberCount"];
                        listaContactoEdit.Dominios_Id = listaContacto.Dominios_Id;
                        listaContactoEdit.UsuarioModificacion = User.Identity.Name;
                        listaContactoEdit.FechaModificacion = DateTime.Now;

                        _context.Entry(listaContactoEdit).State = EntityState.Modified;
                    }
                    else
                    {
                        throw new Exception("Esta lista de contactos ya no existe");
                    }

                    await _context.SaveChangesAsync();

                    await _gestorRastro.AddRastro(User.Identity.Name, listaContacto.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Modificar, listaContacto.Nombre, null);
                }
                else
                {
                    var data = response.GetData();
                    return StatusCode(400, $"Error interno del servidor: {data[0]["ErrorMessage"].ToString()}");
                    //throw new Exception("Error al crear la lista de mailjet");
                }

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // PUT: api/ListasContactos
        [HttpPut]
        public async Task<IActionResult> PutListasContactos([FromBody] DTOListasContactos listaContacto)
        {
            var listaContactoEdit = await _context.ListasContactos.FindAsync(listaContacto.Id);

            if (listaContactoEdit != null)
            {
                listaContactoEdit.Nombre = listaContacto.Nombre;
                listaContactoEdit.Dominios_Id = listaContacto.Dominios_Id;
                listaContactoEdit.UsuarioModificacion = User.Identity.Name;
                listaContactoEdit.FechaModificacion = DateTime.Now;

                _context.Entry(listaContactoEdit).State = EntityState.Modified;
            }
            else
            {
                throw new Exception("Esta lista de contactos ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, listaContacto.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Modificar, listaContacto.Nombre, null);

            return Ok();
        }

        [HttpPost, Route("uploadCsvToMailjet/{idListaContacto}")]
        public async Task<IActionResult> UploadCsvToMailjet([FromRoute] Guid idListaContacto)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                // Obtener la lista de contactos desde el contexto
                var listaContactos = await _context.ListasContactos.FindAsync(idListaContacto);

                if (listaContactos == null || listaContactos.IdListaMailjet == 0)
                {
                    return NotFound("La lista de contactos no existe o no tiene un ID válido en Mailjet.");
                }

                string newName = "";
                string filePath = "";

                // Configurar la ruta para guardar el archivo
                var uploadPath = Path.Combine(_server.WebRootPath, "ListasContactos", listaContactos.IdListaMailjet.ToString());
                if (!Directory.Exists(uploadPath))
                {
                    Directory.CreateDirectory(uploadPath);
                }

                // Guardar el archivo subido
                foreach (var file in Request.Form.Files)
                {
                    if (file.Length > 0)
                    {
                        FileInfo currentFile = new FileInfo(file.FileName);
                        newName = listaContactos.IdListaMailjet + "_Contactos.csv";
                        filePath = Path.Combine(uploadPath, newName);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(fileStream);
                        }
                    }
                }

                if (string.IsNullOrEmpty(filePath))
                {
                    return BadRequest("No se encontró un archivo válido para cargar.");
                }

                // Leer los contactos desde el CSV
                var contactos = new List<Dictionary<string, string>>();
                try
                {
                    using (var reader = new StreamReader(filePath))
                    {
                        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                        {
                            Delimiter = ";",
                            MissingFieldFound = null,
                            HasHeaderRecord = true
                        };

                        try
                        {
                            using (var csv = new CsvHelper.CsvReader(reader, config))
                            {
                                csv.Read();
                                csv.ReadHeader();

                                while (csv.Read())
                                {
                                    var contacto = new Dictionary<string, string>
                                    {
                                        { "Email", csv.GetField("Email") },
                                        { "Nombre", csv.GetField("Nombre") }
                                    };
                                    contactos.Add(contacto);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            // Manejar errores durante la lectura del archivo
                            Console.WriteLine($"Formato incorrecto.");

                            // Eliminar el archivo si ocurre un error
                            if (System.IO.File.Exists(filePath))
                            {
                                System.IO.File.Delete(filePath);
                            }

                            throw new Exception("Formato incorrecto.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Manejar cualquier error adicional
                    Console.WriteLine($"Formato incorrecto.");
                    throw;
                }

                // Obtener credenciales de Mailjet
                var dominio = await _context.Dominios.FindAsync(listaContactos.Dominios_Id);
                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                // Obtener contactos existentes en Mailjet
                var existingEmails = new HashSet<string>();
                var contactIdMap = new Dictionary<string, string>();

                MailjetRequest getRequest = new MailjetRequest
                {
                    Resource = Contact.Resource
                }.Property(Contact.Limit, 1000); // Ajusta el límite según sea necesario

                MailjetResponse getResponse = await client.GetAsync(getRequest);

                if (getResponse.IsSuccessStatusCode)
                {
                    var data = getResponse.GetData();
                    foreach (var item in data)
                    {
                        var email = item["Email"].ToString();
                        var contactId = item["ID"].ToString();

                        existingEmails.Add(email);
                        contactIdMap[email] = contactId;
                    }
                }

                // Procesar contactos
                foreach (var contacto in contactos)
                {
                    string email = contacto["Email"];
                    string nombre = contacto["Nombre"];

                    if (existingEmails.Contains(email))
                    {
                        // Si el contacto existe, asegurarse de que esté en la lista
                        MailjetRequest listRecipientRequest = new MailjetRequest
                        {
                            Resource = Listrecipient.Resource
                        }
                        .Property(Listrecipient.ListID, listaContactos.IdListaMailjet)
                        .Property(Listrecipient.ContactID, contactIdMap[email])
                        .Property(Listrecipient.IsUnsubscribed, false);

                        MailjetResponse listRecipientResponse = await client.PostAsync(listRecipientRequest);

                        if (!listRecipientResponse.IsSuccessStatusCode)
                        {
                            throw new Exception($"Error al suscribir contacto existente: {listRecipientResponse.GetErrorMessage()}");
                        }
                    }
                    else
                    {
                        // Crear contacto nuevo y agregarlo a la lista
                        MailjetRequest request = new MailjetRequest
                        {
                            Resource = Contact.Resource
                        }
                        .Property(Contact.Email, email)
                        .Property(Contact.Name, nombre);

                        MailjetResponse response = await client.PostAsync(request);
                        if (response.IsSuccessStatusCode)
                        {
                            var newContactId = response.GetData()[0]["ID"].ToString();

                            // Suscribir contacto a la lista
                            MailjetRequest listRecipientRequest = new MailjetRequest
                            {
                                Resource = Listrecipient.Resource
                            }
                            .Property(Listrecipient.ListID, listaContactos.IdListaMailjet)
                            .Property(Listrecipient.ContactID, newContactId)
                            .Property(Listrecipient.IsUnsubscribed, false);

                            MailjetResponse listRecipientResponse = await client.PostAsync(listRecipientRequest);

                            if (!listRecipientResponse.IsSuccessStatusCode)
                            {
                                throw new Exception($"Error al suscribir contacto nuevo: {listRecipientResponse.GetErrorMessage()}");
                            }
                        }
                        else
                        {
                            throw new Exception($"Error al crear contacto: {response.GetErrorMessage()}");
                        }
                    }
                }

                await _gestorRastro.AddRastro(User.Identity.Name, listaContactos.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Cambiar_Excel_Lista, newName, null);

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Formato incorrecto");
            }
        }

        // POST: api/ListasContactos
        [HttpPost]
        public async Task<IActionResult> PostListaContacto([FromBody] DTOListasContactos listaContacto)
        {
            ListasContactos nuevo = new ListasContactos
            {
                Nombre = listaContacto.Nombre,
                Empresas_Id = listaContacto.Empresas_Id,
                Dominios_Id = listaContacto.Dominios_Id,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now
            };

            await _context.ListasContactos.AddAsync(nuevo);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, listaContacto.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Agregar, listaContacto.Nombre, null);

            return Ok();
        }

        // POST: api/ListasContactos
        [HttpPost("mailjet")]
        public async Task<IActionResult> PostListaContactoMailjet([FromBody] DTOListasContactos listaContacto)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var dominio = await _context.Dominios.FindAsync(listaContacto.Dominios_Id);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contactslist.Resource,
                }.Property(Contactslist.Name, listaContacto.Nombre);

                MailjetResponse response = await client.PostAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var data = response.GetData();

                    ListasContactos nuevo = new ListasContactos
                    {
                        Nombre = data[0]["Name"].ToString(),
                        Empresas_Id = listaContacto.Empresas_Id,
                        Dominios_Id = listaContacto.Dominios_Id,
                        Address = data[0]["Address"].ToString(),
                        IdListaMailjet = (int)data[0]["ID"],
                        TotalContactos = (int)data[0]["SubscriberCount"],
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Parse(data[0]["CreatedAt"].ToString()),
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };
                    
                    await _context.ListasContactos.AddRangeAsync(nuevo);
                    await _context.SaveChangesAsync();

                    await _gestorRastro.AddRastro(User.Identity.Name, nuevo.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Agregar, "Bulk import Mailjet", null);
                }
                else
                {
                    var data = response.GetData();
                    return StatusCode(400, $"Error interno del servidor: {data[0]["ErrorMessage"].ToString()}");
                    //throw new Exception("Error al crear la lista de mailjet");
                }

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // POST: api/ListasContactos
        [HttpPost("contacto")]
        public async Task<IActionResult> PostContactoMailjet([FromBody] DTOContactosMJ contacto)
        {
            try
            {
                var dominio = await _context.Dominios.FindAsync(contacto.IdDominio);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = ContactslistManagecontact.Resource,
                    ResourceId = ResourceId.Numeric(contacto.IdListaContactos)
                }
                .Property(ContactslistManagecontact.Name, contacto.Nombre)
                .Property(ContactslistManagecontact.Email, contacto.Email)
                .Property(ContactslistManagecontact.Action, "addnoforce");

                MailjetResponse response = await client.PostAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    var data = response.GetData();
                    return StatusCode(400, $"Error interno del servidor: {data[0]["ErrorMessage"].ToString()}");
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // DELETE: api/ListasContactos
        [HttpDelete("{idListaContacto}")]
        public async Task<IActionResult> DeleteListaContacto([FromRoute] Guid idListaContacto)
        {
            var campanas = await _context.Campanas.AnyAsync(x => x.ListasContactos_Id == idListaContacto);
            if (campanas)
            {
                return Conflict("Hay campañas con envio a esta lista de contactos. No se puede eliminar.");
            }

            var listaContacto = await _context.ListasContactos.FindAsync(idListaContacto);
            if (listaContacto == null)
            {
                return NotFound();
            }

            _context.ListasContactos.Remove(listaContacto);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, listaContacto.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Eliminar, listaContacto.Nombre, null);

            return Ok(listaContacto);
        }

        // DELETE: api/ListasContactos
        [HttpDelete("mailjet/{idListaMailjet}")]
        public async Task<IActionResult> DeleteListaContactoMailjet([FromRoute] int idListaMailjet)
        {
            var listaContacto = await _context.ListasContactos.Where(x => x.IdListaMailjet == idListaMailjet).FirstOrDefaultAsync();

            if (listaContacto == null)
            {
                return NotFound();
            }

            var campanas = await _context.Campanas.AnyAsync(x => x.ListasContactos_Id == listaContacto.Id);
            if (campanas)
            {
                return Conflict("Hay campañas con envio a esta lista de contactos. No se puede eliminar.");
            }

            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var dominio = await _context.Dominios.FindAsync(listaContacto.Dominios_Id);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Contactslist.Resource,
                    ResourceId = ResourceId.Numeric(idListaMailjet)
                };

                MailjetResponse response = await client.DeleteAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    _context.ListasContactos.Remove(listaContacto);
                    await _context.SaveChangesAsync();

                    await _gestorRastro.AddRastro(User.Identity.Name, listaContacto.Empresas_Id, EnumTipoProcesoRastro.Lista_Contactos, EnumTipoAccionRastro.Eliminar, listaContacto.Nombre, null);
                }
                else
                {
                    var data = response.GetData();
                    return StatusCode(400, $"Error interno del servidor: {data[0]["ErrorMessage"].ToString()}");
                }

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }
    }
}
