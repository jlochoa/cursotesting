﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;
using static WebAPIMaster.ModelsDTO.DTOEntidades;
using Microsoft.AspNetCore.Hosting.Server;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.CodeAnalysis;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EntidadesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IWebHostEnvironment _server;
        private readonly IGestorRastro _gestorRastro;

        public EntidadesController(ApineticsContext context, IGestorRastro gestorRastro, IWebHostEnvironment env)
        {
            _context = context;
            _gestorRastro = gestorRastro;
            _server = env;
        }

        // GET: api/Entidades
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetEntidadesCombo([FromRoute] Guid idEmpresa)
        {
            List<DTODataComboMC> tiposEntidades;


            tiposEntidades = await (from x in _context.TiposEntidades
                                    where x.Empresas_Id == idEmpresa
                                    orderby x.Descripcion
                                    select new DTODataComboMC
                                    {
                                        Value = x.Id,
                                        Label = x.Descripcion
                                    }).ToListAsync();


            return Ok(tiposEntidades);
        }

        // GET: api/Entidades
        [HttpGet("combo2/{idEmpresa}/{tipo}")]
        public async Task<IActionResult> GetEntidadesComboTipo([FromRoute] Guid idEmpresa, string tipo)
        {
            var user = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();

            List<DTODataCombo> entidades;

            entidades = await (from e in _context.Entidades
                               join et in _context.EntidadesTipos on e.Id equals et.Entidades_Id
                               join te in _context.TiposEntidades on et.TiposEntidades_Id equals te.Id
                               where (e.Empresas_Id == idEmpresa || ((bool)user.SuperAdministrador && e.Empresas_Id == null))
                               && te.Descripcion == tipo && e.Estado == true
                               orderby e.Descripcion
                               select new DTODataCombo
                               {
                                   Value = e.Id,
                                   Label = e.RazonSocial + (!e.NIFCIF.IsNullOrEmpty() ? " - " + e.NIFCIF : "") + 
                                   (!e.Codigo.IsNullOrEmpty() && (e.Codigo != e.NIFCIF && e.Codigo != e.RazonSocial) ? " - " + e.Codigo : ""),
                               }).ToListAsync();

            var mostrarSinFiltrar = idEmpresa == Guid.Parse("6FEFD0B9-7064-445F-BD10-04556650F71B");

            if (!mostrarSinFiltrar)
            {
                switch (tipo)
                {
                    case "usuarios":

                        var usuarios = await _context.Usuarios
                                                     .Where(u => entidades.Select(e => e.Value).Contains((Guid)u.Entidades_Id))
                                                     .ToListAsync();
                        entidades = entidades.Where(e => !usuarios.Select(u => u.Entidades_Id).Contains(e.Value)).ToList();
                        break;
                    case "Trabajadores":
                        var trabajadores = await _context.Trabajadores
                                                         .Where(t => entidades.Select(e => e.Value).Contains((Guid)t.Entidades_Id))
                                                         .ToListAsync();
                        entidades = entidades.Where(e => !trabajadores.Select(t => t.Entidades_Id).Contains(e.Value)).ToList();
                        break;
                    default:
                        break;
                }
            }

            return Ok(entidades);
        }

        // GET: api/Entidades
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetEntidadesById([FromRoute] Guid idEmpresa)
        {
            var entidades = await (from x in _context.Entidades
                                   where x.Empresas_Id == idEmpresa
                                   orderby x.Descripcion
                                   select new DTOEntidades
                                   {
                                       Id = x.Id,
                                       Codigo = x.Codigo,
                                       Tipo = x.Tipo,
                                       Nombre = x.Tipo == "J" ? x.Nombre : x.NombreFisico != null ? x.NombreFisico : x.Nombre,
                                       RazonSocial = x.Tipo == "J" ? x.RazonSocial : x.Apellido1Fisico != null ? x.Apellido1Fisico : x.RazonSocial,
                                       NombreFisico = x.Tipo == "F" || x.Tipo == "FC" ? x.NombreFisico : null,
                                       Apellido1Fisico = x.Tipo == "F" || x.Tipo == "FC" ? x.Apellido1Fisico : null,
                                       Apellido2Fisico = x.Tipo == "F" || x.Tipo == "FC" ? x.Apellido2Fisico : null,
                                       NIFCIF = x.NIFCIF,
                                       NombreConyuge = x.Tipo == "FC" ? x.NombreConyuge : null,
                                       Apellido1Conyuge = x.Tipo == "FC" ? x.Apellido1Conyuge : null,
                                       Apellido2Conyuge = x.Tipo == "FC" ? x.Apellido2Conyuge : null,
                                       NIFConyuge = x.Tipo == "FC" ? x.NIFConyuge : null,
                                       Descripcion = x.Descripcion,
                                       DescCorta = x.DescCorta,
                                       Empresas_Id = x.Empresas_Id,
                                       Localidades_Id = x.Localidades_Id,
                                       CodigoPostal = x.CodigoPostal,
                                       Provincias_Id = x.Provincias_Id,
                                       Paises_Id = x.Paises_Id,
                                       Direccion = x.Direccion,
                                       Observaciones = x.Observaciones,
                                       Activa = x.Estado,
                                       Localidad = x.Localidades.Nombre,
                                       Telefonos = (from y in _context.EntidadesTelefonos
                                                    where y.Entidades_Id == x.Id
                                                    orderby y.Telefono
                                                    select new DTOEntidadesTelefonos
                                                    {
                                                        Id = y.Id,
                                                        Entidades_Id = y.Entidades_Id,
                                                        Telefono = y.Telefono,
                                                        Empresas_Id = x.Empresas_Id
                                                    }).ToList(),
                                       Correos = (from y in _context.EntidadesCorreos
                                                  where y.Entidades_Id == x.Id
                                                  orderby y.Email
                                                  select new DTOEntidadesCorreos
                                                  {
                                                      Id = y.Id,
                                                      Entidades_Id = y.Entidades_Id,
                                                      Email = y.Email,
                                                      Empresas_Id = x.Empresas_Id
                                                  }).ToList(),

                                       TiposEntidad = (from y in _context.EntidadesTipos
                                                       where y.Entidades_Id == x.Id
                                                       orderby y.TiposEntidades.Descripcion
                                                       select new DTOEntidadesTipos
                                                       {
                                                           Id = y.Id,
                                                           Entidades_Id = y.Entidades_Id,
                                                           TiposEntidades_Id = y.TiposEntidades_Id,
                                                           Empresas_Id = x.Empresas_Id,
                                                           Descripcion = y.TiposEntidades.Descripcion
                                                       }).ToList(),


                                   }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(entidades);
        }

        // GET: api/Entidades/entidad
        [HttpGet("entidad/{idEntidad}")]
        public async Task<IActionResult> GetEntidadById([FromRoute] Guid idEntidad)
        {
            var entidad = await (from x in _context.Entidades
                                   where x.Id == idEntidad
                                   select new DTOEntidades
                                   {
                                       Id = x.Id,
                                       Codigo = x.Codigo,
                                       Tipo = x.Tipo,
                                       Nombre = x.Tipo == "J" ? x.Nombre : x.NombreFisico != null ? x.NombreFisico : x.Nombre,
                                       RazonSocial = x.Tipo == "J" ? x.RazonSocial : x.Apellido1Fisico != null ? x.Apellido1Fisico : x.RazonSocial,
                                       NombreFisico = x.Tipo == "F" || x.Tipo == "FC" ? x.NombreFisico : null,
                                       Apellido1Fisico = x.Tipo == "F" || x.Tipo == "FC" ? x.Apellido1Fisico : null,
                                       Apellido2Fisico = x.Tipo == "F" || x.Tipo == "FC" ? x.Apellido2Fisico : null,
                                       NIFCIF = x.NIFCIF,
                                       NombreConyuge = x.Tipo == "FC" ? x.NombreConyuge : null,
                                       Apellido1Conyuge = x.Tipo == "FC" ? x.Apellido1Conyuge : null,
                                       Apellido2Conyuge = x.Tipo == "FC" ? x.Apellido2Conyuge : null,
                                       NIFConyuge = x.Tipo == "FC" ? x.NIFConyuge : null,
                                       Descripcion = x.Descripcion,
                                       DescCorta = x.DescCorta,
                                       Empresas_Id = x.Empresas_Id,
                                       Localidades_Id = x.Localidades_Id,
                                       CodigoPostal = x.CodigoPostal,
                                       Provincias_Id = x.Provincias_Id,
                                       Paises_Id = x.Paises_Id,
                                       Direccion = x.Direccion,
                                       Observaciones = x.Observaciones,
                                       Activa = x.Estado,
                                       Localidad = x.Localidades.Nombre,
                                       Telefonos = (from y in _context.EntidadesTelefonos
                                                    where y.Entidades_Id == x.Id
                                                    select new DTOEntidadesTelefonos
                                                    {
                                                        Id = y.Id,
                                                        Entidades_Id = y.Entidades_Id,
                                                        Telefono = y.Telefono,
                                                        Empresas_Id = x.Empresas_Id
                                                    }).ToList(),
                                       Correos = (from y in _context.EntidadesCorreos
                                                  where y.Entidades_Id == x.Id
                                                  select new DTOEntidadesCorreos
                                                  {
                                                      Id = y.Id,
                                                      Entidades_Id = y.Entidades_Id,
                                                      Email = y.Email,
                                                      Empresas_Id = x.Empresas_Id
                                                  }).ToList(),

                                       TiposEntidad = (from y in _context.EntidadesTipos
                                                       where y.Entidades_Id == x.Id
                                                       select new DTOEntidadesTipos
                                                       {
                                                           Id = y.Id,
                                                           Entidades_Id = y.Entidades_Id,
                                                           TiposEntidades_Id = y.TiposEntidades_Id,
                                                           Empresas_Id = x.Empresas_Id,
                                                           Descripcion = y.TiposEntidades.Descripcion
                                                       }).ToList(),


                                   }).FirstOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, entidad.Empresas_Id, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(entidad);
        }

        [HttpGet("info/{idEntidad}")]
        public async Task<IActionResult> GetDatosCli([FromRoute] Guid idEntidad)
        {
            var ent = await _context.Entidades
                            .Include(e => e.Localidades)
                            .Include(e => e.Provincias)
                            .Include(e => e.Paises)
                            .FirstOrDefaultAsync(e => e.Id == idEntidad);

            if (ent == null)
            {
                Conflict("La entidad no existe.");
            }

            //var info = "Tipo: " + ent.Tipo + (!ent.NIFCIF.IsNullOrEmpty() ? " | CIF: " + ent.NIFCIF : "") +
            //           (!ent.DescCorta.IsNullOrEmpty() ? " | Abreviatura: " + ent.DescCorta : "") +
            //           (!ent.Direccion.IsNullOrEmpty() ? " | Dirección: " + ent.Direccion : "") +
            //           (ent.Localidades_Id != null ? " | Localidad: " + ent.Localidades.Nombre : "") +
            //           (ent.Provincias_Id != null ? " | Provincia: " + ent.Provincias.Nombre : "") +
            //           (ent.Paises_Id != null ? " | País: " + ent.Paises.Nombre : "");
            var info = ent.RazonSocial + (!ent.NIFCIF.IsNullOrEmpty() ? " - " + ent.NIFCIF : "") +
                                   (!ent.Codigo.IsNullOrEmpty() && (ent.Codigo != ent.NIFCIF && ent.Codigo != ent.RazonSocial) ? " - " + ent.Codigo : "");


            //MODIFICACIÓN

            return Ok(new
            {
                info = info,
                tipo = ent.Tipo,
                codigo = ent.Codigo,
                nombre = ent.Nombre, 
                razonSocial = ent.RazonSocial, 
                nifcif = ent.NIFCIF, 
                direccion = ent.Direccion, 
                codigoPostal = ent.CodigoPostal, 
                localidades_Id = ent.Localidades_Id, 
                provincias_Id = ent.Provincias_Id, 
                paises_Id = ent.Paises_Id, 
                observaciones = ent.Observaciones, 
                activa = ent.Estado
            });  ;
        }

        // PUT: api/Entidades
        [HttpPut]
        public async Task<IActionResult> PutEntidades([FromBody] DTOEntidades entidad)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                var entidadEdit = await _context.Entidades.FindAsync(entidad.Id);

                if (entidadEdit != null)
                {
                    entidadEdit.Codigo = entidad.Codigo;
                    entidadEdit.Tipo = entidad.Tipo;

                    string apellidoFisicoCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(entidad.Apellido1Fisico))
                    {
                        apellidoFisicoCompleto = entidad.Apellido1Fisico;
                        if (!string.IsNullOrEmpty(entidad.Apellido2Fisico))
                        {
                            apellidoFisicoCompleto += " " + entidad.Apellido2Fisico;
                        }
                    }

                    string apellidoConyugeCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(entidad.Apellido1Conyuge))
                    {
                        apellidoConyugeCompleto = entidad.Apellido1Conyuge;
                        if (!string.IsNullOrEmpty(entidad.Apellido2Conyuge))
                        {
                            apellidoConyugeCompleto += " " + entidad.Apellido2Conyuge;
                        }
                    }

                    entidadEdit.Nombre = entidad.Tipo == "J" ? entidad.Nombre :
                             (entidad.Tipo == "F" || entidad.Tipo == "FC") ?
                             (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + entidad.NombreFisico +
                             (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + entidad.NombreConyuge :
                             !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "";

                    entidadEdit.RazonSocial = entidad.Tipo == "J" ? entidad.RazonSocial :
                             (entidad.Tipo == "F" || entidad.Tipo == "FC") ?
                             (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + entidad.NombreFisico +
                             (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + entidad.NombreConyuge :
                             !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "";

                    //entidadEdit.Nombre = entidad.Tipo == "J" ? entidad.Nombre :
                    //         (entidad.Tipo == "F" || entidad.Tipo == "FC") ? entidad.Apellido1Fisico + ", " + entidad.NombreFisico +
                    //         (!string.IsNullOrEmpty(entidad.Apellido1Conyuge) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.Apellido1Conyuge + ", " + entidad.NombreConyuge :
                    //         !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "";
                    //entidadEdit.RazonSocial = entidad.Tipo == "J" ? entidad.RazonSocial :
                    //         (entidad.Tipo == "F" || entidad.Tipo == "FC") ? entidad.Apellido1Fisico + ", " + entidad.NombreFisico +
                    //         (!string.IsNullOrEmpty(entidad.Apellido1Conyuge) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.Apellido1Conyuge + ", " + entidad.NombreConyuge :
                    //         !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "";
                    entidadEdit.NombreFisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.NombreFisico : null;
                    entidadEdit.Apellido1Fisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.Apellido1Fisico : null;
                    entidadEdit.Apellido2Fisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.Apellido2Fisico : null;
                    entidadEdit.NombreConyuge = entidad.Tipo == "FC" ? entidad.NombreConyuge : null;
                    entidadEdit.Apellido1Conyuge = entidad.Tipo == "FC" ? entidad.Apellido1Conyuge : null;
                    entidadEdit.Apellido2Conyuge = entidad.Tipo == "FC" ? entidad.Apellido2Conyuge : null;
                    entidadEdit.NIFCIF = entidad.NIFCIF;
                    entidadEdit.NIFConyuge = entidad.Tipo == "FC" ? entidad.NIFConyuge : null;
                    entidadEdit.Descripcion = entidad.Descripcion;
                    entidadEdit.Direccion = entidad.Direccion;
                    entidadEdit.DescCorta = entidad.DescCorta;
                    entidadEdit.Empresas_Id = entidad.Empresas_Id;
                    entidadEdit.UsuarioModificacion = User.Identity.Name;
                    entidadEdit.CodigoPostal = entidad.CodigoPostal;
                    entidadEdit.Localidades_Id = entidad.Localidades_Id;
                    entidadEdit.Observaciones = entidad.Observaciones;
                    entidadEdit.Paises_Id = entidad.Paises_Id;
                    entidadEdit.Provincias_Id = entidad.Provincias_Id;
                    //entidadEdit.CIF = entidad.Cif;
                    entidadEdit.Estado = entidad.Activa;

                    _context.Entry(entidadEdit).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                }
                else
                {
                    return Conflict("Este tipo de entidad ya no existe");
                }


                //TELEFONOS//
                var telefonosEliminar = await (from x in _context.EntidadesTelefonos
                                               where x.Entidades_Id == entidad.Id
                                               select x).ToListAsync();

                _context.EntidadesTelefonos.RemoveRange(telefonosEliminar);

                foreach (var i in entidad.Telefonos)
                {

                    EntidadesTelefonos nuevo = new EntidadesTelefonos
                    {
                        Entidades_Id = entidadEdit.Id,
                        Telefono = i.Telefono,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesTelefonos.AddAsync(nuevo);

                }

                //CORREOS//
                var correosEliminar = await (from x in _context.EntidadesCorreos
                                             where x.Entidades_Id == entidad.Id
                                             select x).ToListAsync();

                _context.EntidadesCorreos.RemoveRange(correosEliminar);

                foreach (var i in entidad.Correos)
                {

                    EntidadesCorreos nuevo = new EntidadesCorreos
                    {
                        Entidades_Id = entidadEdit.Id,
                        Email = i.Email,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesCorreos.AddAsync(nuevo);

                }


                //TIPOS ENTIDADES//
                var entidadesEliminar = await (from x in _context.EntidadesTipos
                                               where x.Entidades_Id == entidad.Id
                                               select x).ToListAsync();

                _context.EntidadesTipos.RemoveRange(entidadesEliminar);

                foreach (var i in entidad.TiposEntidad)
                {

                    EntidadesTipos nuevo = new EntidadesTipos
                    {
                        Entidades_Id = entidadEdit.Id,
                        TiposEntidades_Id = (Guid)i.TiposEntidades_Id,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesTipos.AddAsync(nuevo);

                }

                await _gestorRastro.AddRastro(User.Identity.Name, entidadEdit.Empresas_Id, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Modificar, entidadEdit.Descripcion, null);

                transaction.Commit();
                return Ok();
            }
            catch (Exception)
            {
                transaction.Rollback();
                return Conflict("Se produjo un error");
            }
        }

        // POST: api/Entidades
        [HttpPost]
        public async Task<IActionResult> PostEntidades([FromBody] DTOEntidades entidad)
        {
            //HE COPIADO DESDE AQUÍ
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                string apellidoFisicoCompleto = string.Empty;
                if (!string.IsNullOrEmpty(entidad.Apellido1Fisico))
                {
                    apellidoFisicoCompleto = entidad.Apellido1Fisico;
                    if (!string.IsNullOrEmpty(entidad.Apellido2Fisico))
                    {
                        apellidoFisicoCompleto += " " + entidad.Apellido2Fisico;
                    }
                }

                string apellidoConyugeCompleto = string.Empty;
                if (!string.IsNullOrEmpty(entidad.Apellido1Conyuge))
                {
                    apellidoConyugeCompleto = entidad.Apellido1Conyuge;
                    if (!string.IsNullOrEmpty(entidad.Apellido2Conyuge))
                    {
                        apellidoConyugeCompleto += " " + entidad.Apellido2Conyuge;
                    }
                }

                Entidades nuevoEntidad = new Entidades
                {
                    Codigo = entidad.Codigo,
                    Tipo = entidad.Tipo,
                    Nombre = entidad.Tipo == "J" ? entidad.Nombre :
                         (entidad.Tipo == "F" || entidad.Tipo == "FC") ?
                         (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + entidad.NombreFisico +
                         (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + entidad.NombreConyuge :
                         !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "",
                    RazonSocial = entidad.Tipo == "J" ? entidad.RazonSocial :
                         (entidad.Tipo == "F" || entidad.Tipo == "FC") ?
                         (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + entidad.NombreFisico +
                         (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + entidad.NombreConyuge :
                         !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "",
                    NombreFisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.NombreFisico : null,
                    Apellido1Fisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.Apellido1Fisico : null,
                    Apellido2Fisico = entidad.Tipo == "F" || entidad.Tipo == "FC" ? entidad.Apellido2Fisico : null,
                    NombreConyuge = entidad.Tipo == "FC" ? entidad.NombreConyuge : null,
                    Apellido1Conyuge = entidad.Tipo == "FC" ? entidad.Apellido1Conyuge : null,
                    Apellido2Conyuge = entidad.Tipo == "FC" ? entidad.Apellido2Conyuge : null,
                    NIFCIF = entidad.NIFCIF,
                    Descripcion = entidad.Tipo == "J" ? entidad.RazonSocial :
                         (entidad.Tipo == "F" || entidad.Tipo == "FC") ?
                         (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + entidad.NombreFisico +
                         (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + entidad.NombreConyuge :
                         !string.IsNullOrEmpty(entidad.NombreConyuge) ? " Y " + entidad.NombreConyuge : "") : "",
                    Empresas_Id = entidad.Empresas_Id,
                    DescCorta = entidad.DescCorta,
                    CodigoPostal = entidad.CodigoPostal,
                    Localidades_Id = entidad.Localidades_Id,
                    Observaciones = entidad.Observaciones,
                    //CIF = entidad.Cif,
                    Estado = entidad.Activa,
                    Paises_Id = entidad.Paises_Id,
                    Provincias_Id = entidad.Provincias_Id,
                    Direccion = entidad.Direccion,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now

                };

                await _context.Entidades.AddAsync(nuevoEntidad);

                await _context.SaveChangesAsync();

                //TELEFONOS//

                foreach (var i in entidad.Telefonos)
                {

                    EntidadesTelefonos nuevo = new EntidadesTelefonos
                    {
                        Entidades_Id = nuevoEntidad.Id,
                        Telefono = i.Telefono,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesTelefonos.AddAsync(nuevo);

                }

                //CORREOS//

                foreach (var i in entidad.Correos)
                {

                    EntidadesCorreos nuevo = new EntidadesCorreos
                    {
                        Entidades_Id = nuevoEntidad.Id,
                        Email = i.Email,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesCorreos.AddAsync(nuevo);

                }

                // ENTIDADES TIPOS//

                foreach (var i in entidad.TiposEntidad)
                {

                    EntidadesTipos nuevo = new EntidadesTipos
                    {
                        Entidades_Id = nuevoEntidad.Id,
                        TiposEntidades_Id = (Guid)i.TiposEntidades_Id,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.EntidadesTipos.AddAsync(nuevo);
                }

                await _context.SaveChangesAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, entidad.Empresas_Id, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Agregar, entidad.Descripcion, null);
            
                transaction.Commit();
                return Ok(nuevoEntidad);
            }
            catch (Exception)
            {
                transaction.Rollback();
                return Conflict("Se produjo un error");
            }
        }
        //COPIAR HASTA AQUÍ


        // DELETE: api/Entidades/5
        [HttpDelete("{IdEntidad}")]
        public async Task<IActionResult> DeleteTipoEntidad([FromRoute] Guid IdEntidad)
        {
            var entidadesEntidadesContactos1 = await _context.Contactos.AnyAsync(x => x.Entidades_Id == IdEntidad);
            if (entidadesEntidadesContactos1)
            {
                return Conflict("Esta entidad está asignada a algún contacto. No se puede eliminar");
            }

            var entidadesEntidadesDocumentos = await _context.EntidadesDocumentos.AnyAsync(x => x.Entidades_Id == IdEntidad);
            if (entidadesEntidadesDocumentos)
            {
                return Conflict("Esta entidad está asignada a algún documento. No se puede eliminar");
            }

            var trabajadores = await _context.Trabajadores.AnyAsync(x => x.Entidades_Id == IdEntidad);
            if (trabajadores)
            {
                return Conflict("Esta entidad está asignada a algún trabajador. No se puede eliminar");
            }

            var usuarios = await _context.Usuarios.AnyAsync(x => x.Entidades_Id == IdEntidad);
            if (usuarios)
            {
                return Conflict("Esta entidad está asignada a algún usuario. No se puede eliminar");
            }

            var entidadesEntidadesTipos = await (from y in _context.EntidadesTipos
                                                 where y.Entidades_Id == IdEntidad
                                                 select y).ToListAsync();

            _context.EntidadesTipos.RemoveRange(entidadesEntidadesTipos);



            var entidadesCorreos = await (from y in _context.EntidadesCorreos
                                          where y.Entidades_Id == IdEntidad
                                          select y).ToListAsync();

            _context.EntidadesCorreos.RemoveRange(entidadesCorreos);


            var entidadesTelefonos = await (from y in _context.EntidadesTelefonos
                                            where y.Entidades_Id == IdEntidad
                                            select y).ToListAsync();

            _context.EntidadesTelefonos.RemoveRange(entidadesTelefonos);

            var entidades = await _context.Entidades.FindAsync(IdEntidad);
            if (entidades == null)
            {
                return NotFound();
            }

            _context.Entidades.Remove(entidades);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, entidades.Empresas_Id, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Eliminar, entidades.Descripcion, null);

            return Ok(entidades);
        }

        //GET documentos de entidad
        [HttpGet("documentos/{idEntidad}")]
        public async Task<IActionResult> GetDocumentos([FromRoute] Guid idEntidad)
        {
            var idEmpresa = await (from x in _context.Entidades where x.Id == idEntidad select x.Empresas_Id).FirstOrDefaultAsync();
            var documentos = await (from x in _context.EntidadesDocumentos
                                    where x.Entidades_Id == idEntidad
                                    select new DTOEntidadesDocumentos
                                    {
                                        Id = x.Id,
                                        Entidad_Id = x.Entidades_Id,
                                        UrlDocumento = x.URL,
                                        Descripcion = x.Descripcion,
                                        Empresas_Id = x.Empresas_Id,
                                        //NombreEntidad = x.Entidades_IdNavigation.Descripcion,
                                        NombreArchivo = x.URL
                                    }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.EntidadesDocumentos, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(documentos);
        }

        [HttpPost("documentos")]
        public async Task<IActionResult> PostEntidadesDocumento(DTOEntidadesDocumentos documento)
        {
            var nombre = documento.NombreArchivo.Replace(" ", "_").Replace("%", "pct").Replace("/", "-");
            var documentoExiste = await _context.EntidadesDocumentos.AnyAsync(x => x.Entidades_Id == documento.Entidad_Id && x.URL == nombre);
            if (documentoExiste)
            {
                return Conflict("Esta entidad ya ha subido este documento u otro con el mismo nombre.");
            }

            EntidadesDocumentos nuevoDocumento = new EntidadesDocumentos
            {
                Entidades_Id = (Guid)documento.Entidad_Id,
                URL = nombre,
                Descripcion = documento.Descripcion,
                Empresas_Id = documento.Empresas_Id,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now,
            };

            await _context.EntidadesDocumentos.AddAsync(nuevoDocumento);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, documento.Empresas_Id, EnumTipoProcesoRastro.EntidadesDocumentos, EnumTipoAccionRastro.Agregar, documento.Descripcion, null);

            return Ok();
        }

        [HttpPost, Route("uploadDocumento/{id}/{tipo}")]
        public async Task<IActionResult> UploadFile([FromRoute] Guid id, string tipo)
        {
            object tipoEntidad = null;
            Guid idEntidad = new Guid();

            switch (tipo)
            {
            case "Trabajadores":
                var trabajador = await _context.Trabajadores.FindAsync(id);
                tipoEntidad = trabajador;
                idEntidad = (Guid)trabajador.Entidades_Id;
                break;
            case "Entidades":
                var entidades = await _context.Entidades.FindAsync(id);
                tipoEntidad = entidades;
                idEntidad = (Guid)entidades.Id;
                break;
            }

            if (tipoEntidad == null)
            {
                return NotFound($"No se encontró ninguna entidad de '{tipo}'.");
            }

            var entidad = await _context.Entidades.FindAsync(idEntidad);
            var empresa = await _context.Empresas.FindAsync(entidad.Empresas_Id);
            var email = await (from x in _context.EntidadesCorreos
                               where x.Entidades_Id == entidad.Id
                               select x.Email).FirstOrDefaultAsync();

            var uploadPath = Path.Combine(_server.WebRootPath, "Documentos", "Entidades", tipo, idEntidad.ToString());

            //var uploadPath = Path.Combine(_server.WebRootPath, "Documentos", "Entidades", tipo, id.ToString());

            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);
            }

            foreach (var file in Request.Form.Files)
            {
                if (file.Length > 0)
                {
                    var nombre = file.FileName.Replace(" ", "_").Replace("%", "pct").Replace("/", "-");
                    var existeArchivo = await _context.EntidadesDocumentos.Where(x => x.Entidades_Id == idEntidad && x.URL == nombre).AnyAsync();
                    if (existeArchivo)
                    {
                        return Conflict("Esta entidad ya tiene un documento con el mismo nombre de fichero.");
                    }
                    FileInfo currentFile = new FileInfo(nombre);
                    //newName = id + "_logo" + currentFile.Extension;
                    var filePath = Path.Combine(uploadPath, nombre);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }

                    EntidadesDocumentos nuevoDocumento = new EntidadesDocumentos
                    {
                        Entidades_Id = entidad.Id,
                        URL = nombre,
                        Descripcion = nombre,
                        Empresas_Id = entidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now,
                    };

                    await _context.EntidadesDocumentos.AddAsync(nuevoDocumento);

                    await _gestorRastro.AddRastro(User.Identity.Name, entidad.Empresas_Id, EnumTipoProcesoRastro.EntidadesDocumentos, EnumTipoAccionRastro.Agregar, null, null);

                    await _context.SaveChangesAsync();
                }
            }

            return Ok();
        }

        [HttpPut("documentos")]
        public async Task<IActionResult> PutDocumento([FromBody] DTOEntidadesDocumentos documento)
        {
            var nombre = documento.NombreArchivo.Replace(" ", "_").Replace("%", "pct").Replace("/", "-");

            var documentoExistente = await _context.EntidadesDocumentos.AnyAsync(x => x.URL == nombre && x.Entidades_Id == documento.Entidad_Id && x.Id != documento.Id);
            if (documentoExistente)
            {
                return Conflict("Ya has subido este archivo.");
            }

            var documentoEdit = await _context.EntidadesDocumentos.FindAsync(documento.Id);

            if (documentoEdit != null)
            {
                documentoEdit.URL = nombre;
                documentoEdit.Descripcion = documento.Descripcion;
                documentoEdit.Empresas_Id = documento.Empresas_Id;
                documentoEdit.UsuarioModificacion = User.Identity.Name;
                documentoEdit.FechaModificacion = DateTime.Now;
                _context.Entry(documentoEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Este documento ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, documento.Empresas_Id, EnumTipoProcesoRastro.EntidadesDocumentos, EnumTipoAccionRastro.Modificar, documento.Descripcion, null);

            return Ok();
        }

        [HttpGet("verDocumento/{id}/{tipo}")]
        public async Task<IActionResult> DownloadDocumentoById([FromRoute] Guid id, string tipo)
        {
            string filePath = "";

            var documento = await _context.EntidadesDocumentos.FindAsync(id);
            if (documento.URL != null)
            {
                filePath = Path.Combine(_server.WebRootPath, "Documentos", "Entidades", tipo, documento.Entidades_Id.ToString(), documento.URL);
            }
            else
            {
                filePath = Path.Combine(_server.WebRootPath, "Imagenes", "noimage.png");
            }

            if (System.IO.File.Exists(filePath))
            {
                byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);
                return new FileContentResult(fileBytes, "application/octet");
            }
            else
            {
                return Conflict("Documento inexistente");
            }
        }

        [HttpDelete("documentos/{idDocumento}")]
        public async Task<IActionResult> DeleteDocumento([FromRoute] Guid idDocumento)
        {
            var documento = await _context.EntidadesDocumentos.FindAsync(idDocumento);
            _context.EntidadesDocumentos.Remove(documento);
            await _context.SaveChangesAsync();

            if (System.IO.File.Exists(documento.URL))
            {
                System.IO.File.Delete(documento.URL);
            }

            await _gestorRastro.AddRastro(User.Identity.Name, documento.Empresas_Id, EnumTipoProcesoRastro.Entidades, EnumTipoAccionRastro.Eliminar, documento.Descripcion, null);

            return Ok(documento);
        }

    }
}

