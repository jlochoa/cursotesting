﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PalabrasClavesController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IConfiguration _configuration;
        private readonly IGestorRastro _gestorRastro;

        public PalabrasClavesController(ApineticsContext context, IConfiguration configuration, IGestorRastro gestorRastro)
        {
            _context = context;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
        }

        public class Keywords
        {
            public string keyword { get; set; }
        }

        public class PalabraClav
        {
            public int added { get; set; }
            public List<int> ids { get; set; }
        }

        // GET: api/PalabrasClave
        [HttpGet("{idDominio}")]
        public async Task<IActionResult> GetPalabrasClaveByIdDominio([FromRoute] Guid idDominio)
        {
            var palabrasClave = await (from x in _context.PalabrasClave
                                       where x.Dominios_Id == idDominio
                                       select new PalabrasClave
                                       {
                                           Id = x.Id,
                                           Dominios_Id = x.Dominios_Id,
                                           Descripcion = x.Descripcion,
                                           IdPalabraClaveSeRanking = x.IdPalabraClaveSeRanking
                                       }).ToListAsync();

            var idEmpresa = await (from x in _context.Dominios
                                   where x.Id == idDominio
                                   select x.Empresas_Id).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Palabras_Clave, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(palabrasClave);
        }
        // PUT: api/PalabrasClave
        [HttpPut]
        public async Task<IActionResult> PutPalabraClave([FromBody] DTOCompPalabrasClave palabraClave)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                var dominioIdSeRanking = await (from x in _context.Dominios
                                                where x.Id == palabraClave.Dominios_Id
                                                select x.IdSeRanking).SingleOrDefaultAsync();

                var palabraClaveEdit = await _context.PalabrasClave.FindAsync(palabraClave.Id);

                if (palabraClaveEdit != null)
                {
                    palabraClaveEdit.Dominios_Id = (Guid)palabraClave.Dominios_Id;
                    palabraClaveEdit.Descripcion = palabraClave.Descripcion;
                    palabraClaveEdit.IdPalabraClaveSeRanking = palabraClave.IdSeRanking;
                    palabraClaveEdit.UsuarioModificacion = User.Identity.Name;
                    palabraClaveEdit.FechaModificacion = DateTime.Now;

                    _context.Entry(palabraClaveEdit).State = EntityState.Modified;
                }
                else
                {
                    throw new Exception("Esta palabra clave ya no existe");
                }

                await _context.SaveChangesAsync();

                //lo hacemos para SE Ranking
                var token = _configuration.GetSection("TokenSeRanking").Value;

                var infor = new
                {
                    token = token,
                    keyword = palabraClave.Descripcion
                };

                var json = Newtonsoft.Json.JsonConvert.SerializeObject(infor);
                var data = new System.Net.Http.StringContent(json, Encoding.UTF8, "application/json");

                var url = "https://api4.seranking.com/sites/" + dominioIdSeRanking + "/keywords/" + palabraClaveEdit.IdPalabraClaveSeRanking;
                using var client = new HttpClient();

                var response = await client.PatchAsync(url, data);

                string result = response.Content.ReadAsStringAsync().Result;

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            var idEmpresa = await (from x in _context.Dominios
                                   where x.Id == palabraClave.Dominios_Id
                                   select x.Empresas_Id).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Palabras_Clave, EnumTipoAccionRastro.Modificar, palabraClave.Descripcion, null);

            return Ok();
        }

        // POST: api/PalabrasClave
        [HttpPost]
        public async Task<IActionResult> PostPalabraClave([FromBody] DTOCompPalabrasClave palabraClave)
        {
            var IdSeRanking = await (from x in _context.Dominios
                                     where x.Id == palabraClave.Dominios_Id
                                     select x.IdSeRanking).SingleOrDefaultAsync();

            using var transaction = _context.Database.BeginTransaction();
            try
            {
                PalabrasClave nuevo = new PalabrasClave
                {
                    Dominios_Id = (Guid)palabraClave.Dominios_Id,
                    Descripcion = palabraClave.Descripcion,
                    IdPalabraClaveSeRanking = palabraClave.IdSeRanking,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
            };

                await _context.PalabrasClave.AddAsync(nuevo);
                await _context.SaveChangesAsync();

                //lo hacemos tambien en SE Ranking
                if (IdSeRanking != null && IdSeRanking != 0)
                {
                    List<Keywords> nuevaPalabraClave = new List<Keywords>();
                    Keywords aa = new Keywords
                    {
                        keyword = palabraClave.Descripcion

                    };
                    nuevaPalabraClave.Add(aa);
                    var json = Newtonsoft.Json.JsonConvert.SerializeObject(nuevaPalabraClave);
                    var data = new System.Net.Http.StringContent(json, Encoding.UTF8, "application/json");

                    var url = "https://api4.seranking.com/sites/" + IdSeRanking + "/keywords";
                    using var client = new HttpClient();

                    var token = _configuration.GetSection("TokenSeRanking").Value;

                    client.DefaultRequestHeaders.Add("Authorization", "Token " + token);

                    var response = await client.PostAsync(url, data);

                    string result = response.Content.ReadAsStringAsync().Result;

                    //el codigo que nos devuelve lo ponemos en el campo correspondiente

                    PalabraClav infor = JsonSerializer.Deserialize<PalabraClav>(result);
                    nuevo.IdPalabraClaveSeRanking = infor.ids[0];
                }

                _context.Entry(nuevo).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                var idEmpresa = await (from x in _context.Dominios
                                       where x.Id == palabraClave.Dominios_Id
                                       select x.Empresas_Id).SingleOrDefaultAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Palabras_Clave, EnumTipoAccionRastro.Agregar, palabraClave.Descripcion, null);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }

        // DELETE: api/PalabrasClave
        [HttpDelete("{idPalabraClave}")]
        public async Task<IActionResult> DeletePalabraClave([FromRoute] Guid idPalabraClave)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                var palabraClave = await _context.PalabrasClave.FindAsync(idPalabraClave);
                if (palabraClave == null)
                {
                    return NotFound();
                }

                var dominioIdSeRanking = await (from x in _context.Dominios
                                                where x.Id == palabraClave.Dominios_Id
                                                select x.IdSeRanking).SingleOrDefaultAsync();

                _context.PalabrasClave.Remove(palabraClave);
                await _context.SaveChangesAsync();

                if (palabraClave.IdPalabraClaveSeRanking != null && palabraClave.IdPalabraClaveSeRanking != 0)
                { 
                    var token = _configuration.GetSection("TokenSeRanking").Value;

                    var url = "https://api4.seranking.com/sites/" + dominioIdSeRanking + "/keywords?keywords_ids[]=" + palabraClave.IdPalabraClaveSeRanking.Value;
                    using var client = new HttpClient();
                    client.DefaultRequestHeaders.Add("Authorization", "Token " + token);

                    var response = await client.DeleteAsync(url);

                    string result = response.Content.ReadAsStringAsync().Result;
                }

                var idEmpresa = await (from x in _context.Dominios
                                       where x.Id == palabraClave.Dominios_Id
                                       select x.Empresas_Id).SingleOrDefaultAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Palabras_Clave, EnumTipoAccionRastro.Eliminar, palabraClave.Descripcion, null);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }
    }
}