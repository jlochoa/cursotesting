﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using static WebAPIMaster.Controllers.DominiosController;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PublicacionesController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IHttpContextAccessor _accessor;
        private readonly IWebHostEnvironment _server;
        private readonly IConfiguration _configuration;
        private readonly IGestorRastro _gestorRastro;

        public PublicacionesController(ApineticsContext context, IHttpContextAccessor accessor, IWebHostEnvironment env, IConfiguration configuration, IGestorRastro gestorRastro)
        {
            _context = context;
            _accessor = accessor;
            _server = env;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Publicaciones
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetPublicacionesByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var publicaciones = await (from x in _context.Publicaciones
                                       where x.Empresas_Id == idEmpresa
                                       orderby x.FechaPublicacion descending
                                       select new DTOPublicaciones
                                       {
                                           Id = x.Id,
                                           Empresas_Id = x.Empresas_Id,
                                           Dominios_Id = x.Dominios_Id,
                                           Texto = x.Texto,
                                           FechaPublicacion = x.FechaPublicacion,
                                           Borrador = x.Borrador,
                                           Publicado = x.Publicado,
                                           Redes = x.Redes,
                                           IdPublicacionMetricool = x.IdPublicacionMetricool
                                       }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Publicaciones, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(publicaciones);
        }

        // POST: api/Publicaciones/uploadImagen
        //[HttpPost, Route("uploadImagen/{id}")]
        //public async Task<IActionResult> UploadImagen([FromRoute] Guid id)
        //{
        //    var dominio = await _context.Dominios.FindAsync(id);

        //    var uploadPath = Path.Combine(_server.WebRootPath, "Dominios");

        //    string newName = "";
        //    foreach (var file in Request.Form.Files)
        //    {
        //        if (file.Length > 0)
        //        {
        //            FileInfo currentFile = new FileInfo(file.FileName);
        //            newName = id + "_" + file.FileName;
        //            var filePath = Path.Combine(uploadPath, newName);
        //            using (var fileStream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(fileStream);
        //            }
        //        }
        //    }
        //    dominio.Logo = newName;
        //    _context.Entry(dominio).State = EntityState.Modified;

        //    await _context.SaveChangesAsync();

        //    await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Cambiar_imagen, dominio.Dominio, null);

        //    return Ok();
        //}

        // PUT: api/Publicaciones
        [HttpPut]
        public async Task<IActionResult> PutPublicacion([FromBody] DTOPublicaciones publicacion)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var publicacionEdit = await _context.Publicaciones.Where(x => x.IdPublicacionMetricool == publicacion.IdPublicacionAnt).FirstOrDefaultAsync();

                if (publicacionEdit != null)
                {
                    publicacionEdit.Dominios_Id = publicacion.Dominios_Id;
                    publicacionEdit.Texto = publicacion.Texto;
                    publicacionEdit.FechaPublicacion = publicacion.FechaPublicacion;
                    publicacionEdit.Borrador = publicacion.Borrador;
                    publicacionEdit.Publicado = publicacion.Publicado;
                    publicacionEdit.Redes = publicacion.Redes;
                    publicacionEdit.IdPublicacionMetricool = publicacion.IdPublicacionMetricool;
                    publicacionEdit.UsuarioModificacion = User.Identity.Name;
                    publicacionEdit.FechaModificacion = DateTime.Now;

                    _context.Entry(publicacionEdit).State = EntityState.Modified;

                    await _context.SaveChangesAsync();

                    await _gestorRastro.AddRastro(User.Identity.Name, publicacion.Empresas_Id, EnumTipoProcesoRastro.Publicaciones, EnumTipoAccionRastro.Modificar, publicacion.IdPublicacionMetricool, null);
                }
                else
                {
                    throw new Exception("Esta publicación ya no existe");
                }

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }

        // POST: api/Publicaciones
        [HttpPost]
        public async Task<IActionResult> PostPublicacion([FromBody] DTOPublicaciones publicacion)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                Publicaciones nuevo = new Publicaciones
                {
                    Dominios_Id = publicacion.Dominios_Id,
                    Empresas_Id = publicacion.Empresas_Id,
                    Texto = publicacion.Texto,
                    FechaPublicacion = publicacion.FechaPublicacion,
                    Borrador = publicacion.Borrador,
                    Publicado = publicacion.Publicado,
                    Redes = publicacion.Redes,
                    IdPublicacionMetricool = publicacion.IdPublicacionMetricool,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now,
                };

                await _context.Publicaciones.AddAsync(nuevo);
                await _context.SaveChangesAsync();

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, publicacion.Empresas_Id, EnumTipoProcesoRastro.Publicaciones, EnumTipoAccionRastro.Agregar, publicacion.IdPublicacionMetricool, null);

            return Ok();
        }

        // DELETE: api/Publicaciones
        [HttpDelete("{idEmpresa}/{idPublicacion}")]
        public async Task<IActionResult> DeletePublicacion([FromRoute] Guid idEmpresa, int idPublicacion)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var publicacion = await _context.Publicaciones.Where(x => x.Empresas_Id == idEmpresa && x.IdPublicacionMetricool == idPublicacion.ToString()).FirstOrDefaultAsync();

                if (publicacion == null)
                {
                    return NotFound();
                }

                _context.Publicaciones.Remove(publicacion);
                await _context.SaveChangesAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, publicacion.Empresas_Id, EnumTipoProcesoRastro.Publicaciones, EnumTipoAccionRastro.Eliminar, publicacion.IdPublicacionMetricool, null);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }
    }
}
