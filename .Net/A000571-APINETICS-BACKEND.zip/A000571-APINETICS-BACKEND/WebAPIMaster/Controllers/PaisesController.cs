﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Text.Json;
using System.Collections.Generic;
using Microsoft.IdentityModel.Tokens;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PaisesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public PaisesController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro; ;
        }

        // GET: api/Paises
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetPaisesCombo([FromRoute] Guid idEmpresa)
        {
            var total = await _context.Paises.CountAsync();
            var paises = await (from x in _context.Paises
                                where x.Empresas_Id == idEmpresa || x.Empresas_Id == null
                                orderby x.Nombre
                                select new DTODataComboMC
                                {
                                    Value = x.Id,
                                    Label = x.Nombre,
                                }).ToListAsync();

            return Ok(paises);
        }

        // GET: api/Paises
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetPaisesById([FromRoute] Guid idEmpresa)
        {
            var paises = await (from x in _context.Paises
                                where x.Empresas_Id == idEmpresa || x.Empresas_Id == null
                                orderby x.Empresas_Id != null descending, x.Nombre
                                select new DTOPaises
                                {
                                    Id = x.Id,
                                    Nombre = x.Nombre,
                                    Spain = x.Spain,
                                    Cee = x.Cee,
                                    CodPais = x.CodPais,
                                    Empresas_Id = x.Empresas_Id,
                                }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Paises, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(paises);
        }

        // PUT: api/Paises
        [HttpPut]
        public async Task<IActionResult> PutPaises([FromBody] DTOPaises pais)
        {
            var paisEdit = await _context.Paises.FindAsync(pais.Id);

            if (paisEdit != null)
            {
                paisEdit.Nombre = pais.Nombre;
                paisEdit.Spain = pais.Spain;
                paisEdit.Cee = pais.Cee;
                paisEdit.CodPais = pais.CodPais;
                paisEdit.Empresas_Id = pais.Empresas_Id;
                paisEdit.UsuarioModificacion = User.Identity.Name;
                paisEdit.FechaModificacion = DateTime.Now;
                _context.Entry(paisEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Este pais ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, paisEdit.Empresas_Id, EnumTipoProcesoRastro.Paises, EnumTipoAccionRastro.Modificar, paisEdit.Nombre, null);

            return Ok(paisEdit);
        }

        // POST: api/Paises
        [HttpPost]
        public async Task<IActionResult> PostPaises([FromBody] DTOPaises pais)
        {
            Paises nuevoPais = new Paises
            {
                Nombre = pais.Nombre,
                Spain = pais.Spain,
                Cee = pais.Cee,
                CodPais = pais.CodPais,
                Empresas_Id = pais.Empresas_Id,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now,
            };

            await _context.Paises.AddAsync(nuevoPais);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, pais.Empresas_Id, EnumTipoProcesoRastro.Paises, EnumTipoAccionRastro.Agregar, pais.Nombre, null);

            return Ok(nuevoPais);
        }

        // DELETE: api/Paises/5
        [HttpDelete("{idPais}")]
        public async Task<IActionResult> DeletePaises([FromRoute] Guid idPais)
        {
            var pais = await _context.Paises.FindAsync(idPais);
            if (pais == null)
            {
                return NotFound();
            }

            _context.Paises.Remove(pais);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, pais.Empresas_Id, EnumTipoProcesoRastro.Paises, EnumTipoAccionRastro.Eliminar, pais.Nombre, null);

            return Ok(pais);
        }

    }
}

