﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using Microsoft.IdentityModel.Tokens;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ContactosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IWebHostEnvironment _server;
        private readonly IGestorRastro _gestorRastro;

        public ContactosController(ApineticsContext context, IGestorRastro gestorRastro, IWebHostEnvironment env)
        {
            _context = context;
            _gestorRastro = gestorRastro;
            _server = env;
        }

        // GET: api/Contactos

        [HttpGet("combo/{idEntidad}")]
        public async Task<IActionResult> GetContactosCombo([FromRoute] Guid idEntidad)
        {
            var contactos = await (from x in _context.Contactos
                                   where x.Entidades_Id == idEntidad
                                   orderby x.Apellido1
                                   select new DTODataComboMC
                                   {
                                       Value = x.Id,
                                       Label = !x.Apellido1.IsNullOrEmpty() ? x.Apellido1 + ", " + x.Nombre : x.Nombre
                                   }).ToListAsync();

            return Ok(contactos);

        }

        [HttpGet("combo2/{idEmpresa}/{responsable}")]
        public async Task<IActionResult> GetTrabajadoresCombo([FromRoute] Guid idEmpresa, bool responsable)
        {
            List<DTODataComboMC> trabajadores;

            if (responsable) { 
                trabajadores = await (from x in _context.Trabajadores
                                  where x.Empresas_Id == idEmpresa && x.Responsable == true
                                  orderby x.Nombre
                                  select new DTODataComboMC
                                  {
                                      Value = x.Id,
                                      Label = x.Nombre
                                  }).ToListAsync();
            }
            else
            {
                trabajadores = await (from x in _context.Trabajadores
                                  where x.Empresas_Id == idEmpresa
                                      orderby x.Nombre
                                  select new DTODataComboMC
                                  {
                                      Value = x.Id,
                                      Label = x.Nombre
                                  }).ToListAsync();
            }

            return Ok(trabajadores);
        }

        // GET: api/Personas
        [HttpGet("{idEntidad}")]
        public async Task<IActionResult> GetEntidadContactoById([FromRoute] Guid idEntidad)
        {
            var contacto = await (from x in _context.Contactos
                                  where x.Entidades_Id == idEntidad
                                  select new DTOContactos
                                  {
                                      Id = x.Id,
                                      Empresas_Id = x.Empresas_Id,
                                      Entidades_Id = x.Entidades_Id,
                                      Entidad = x.Entidades.Descripcion,
                                      Nombre = x.Nombre,
                                      Apellido1 = x.Apellido1,
                                      Apellido2 = x.Apellido2,
                                      Direccion = x.Direccion,
                                      Localidades_Id = x.Localidades_Id,
                                      CodigoPostal = x.CodigoPostal,
                                      Provincias_Id = x.Provincias_Id,
                                      Paises_Id = x.Paises_Id,
                                      Telefono = x.Telefono,
                                      Movil = x.Movil,
                                      Fax = x.Fax,
                                      Email = x.Email,
                                      UrlImagen = x.UrlImagen,
                                      Maestros_IdDepartamento = x.Departamento,
                                      Cargo = x.Cargo,
                                      //Maestros_IdClasif1 = x.Maestros_IdClasif1,
                                      //Maestros_IdClasif2 = x.Maestros_IdClasif2,
                                      //Clasif1 = x.Maestros_IdClasif1 != null ? x.Maestros_IdClasif1Navigation.Descripcion : "",
                                      //Clasif2 = x.Maestros_IdClasif2 != null ? x.Maestros_IdClasif2Navigation.Descripcion : "",
                                      Telefonos = (from y in _context.ContactosTelefonos where y.Contactos_Id == x.Id select new DTOContactosTelefonos { Contactos_Id = y.Contactos_Id, Telefono = y.Telefono }).ToList(),
                                      Correos = (from y in _context.ContactosCorreos where y.Contactos_Id == x.Id select new DTOContactosCorreos { Contactos_Id = y.Contactos_Id, Email = y.Email }).ToList(),


                                  }).ToListAsync();

            if (contacto.Count < 1)
            {
               // Conflict("Tus contactos están vacíos.");
            }
            else
            {

                await _gestorRastro.AddRastro(User.Identity.Name, contacto[0].Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Consultar, null, null);

            }

            return Ok(contacto);
        }

        // GET: api/Persona
        [HttpGet("obtenerEntidades/{idEmpresa}")]
        public async Task<IActionResult> GetEntidadesCombo([FromRoute] Guid idEmpresa)
        {
            List<DTODataComboMC> entidad;

                entidad = await (from x in _context.Entidades
                                  where x.Empresas_Id == idEmpresa
                                  orderby x.Descripcion
                                  select new DTODataComboMC
                                  {
                                      Value = x.Id,
                                      Label = x.Descripcion
                                  }).ToListAsync();

            return Ok(entidad);
        }

        // GET: api/Departamentos/combo
        [HttpGet("entidad/{idEntidad}")]
        public async Task<IActionResult> ObtenerTodasEntidades([FromRoute] Guid idEntidad)
        {
            string entidades = await (from x in _context.Entidades
                                       where x.Id == idEntidad
                                       orderby x.Descripcion
                                      select x.Descripcion).SingleOrDefaultAsync();


            return Ok(entidades);
        }

        // PUT: api/Trabajadores
        [HttpPut]
        public async Task<IActionResult> PutContactos([FromBody] DTOContactos contacto)
        {
            var contactoEdit = await _context.Contactos.FindAsync(contacto.Id);

            if (contactoEdit != null)
            {
                contactoEdit.Entidades_Id = (Guid)contacto.Entidades_Id;
                contactoEdit.Nombre = contacto.Nombre;
                contactoEdit.Apellido1 = contacto.Apellido1;
                contactoEdit.Apellido2 = contacto.Apellido2;
                contactoEdit.Direccion = contacto.Direccion;
                contactoEdit.Localidades_Id = contacto.Localidades_Id;
                contactoEdit.CodigoPostal = contacto.CodigoPostal;
                contactoEdit.Provincias_Id = contacto.Provincias_Id;
                contactoEdit.Paises_Id = contacto.Paises_Id;
                contactoEdit.Telefono = contacto.Telefono;
                contactoEdit.Movil = contacto.Movil;
                contactoEdit.Fax = contacto.Fax;
                contactoEdit.Email = contacto.Email;
                contactoEdit.Departamento = contacto.Maestros_IdDepartamento;
                contactoEdit.Cargo = contacto.Cargo;
                //contactoEdit.Maestros_IdClasif1 = contacto.Maestros_IdClasif1;
                //contactoEdit.Maestros_IdClasif2 = contacto.Maestros_IdClasif2;
                contactoEdit.UsuarioModificacion = User.Identity.Name;
                contactoEdit.FechaModificacion = DateTime.Now;
                
                _context.Entry(contactoEdit).State = EntityState.Modified;
                await _context.SaveChangesAsync();

            }
            else
            {
                return Conflict("Este contacto ya no existe");
            }

            //TELEFONOS//
            var telefonosEliminar = await (from x in _context.ContactosTelefonos
                                           where x.Contactos_Id == contacto.Id
                                           select x).ToListAsync();

            foreach (var j in telefonosEliminar)
            {

                _context.ContactosTelefonos.Remove(j);

            }

            foreach (var i in contacto.Telefonos)
            {

                ContactosTelefonos nuevo = new ContactosTelefonos
                {

                    Contactos_Id = (Guid)contacto.Id,
                    Telefono = i.Telefono,
                    Empresas_Id = contacto.Empresas_Id,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

                await _context.ContactosTelefonos.AddAsync(nuevo);

            }





            //CORREOS//
            var correosEliminar = await (from x in _context.ContactosCorreos
                                         where x.Contactos_Id == contacto.Id
                                         select x).ToListAsync();

            foreach (var j in correosEliminar)
            {

                _context.ContactosCorreos.Remove(j);

            }

            foreach (var i in contacto.Correos)
            {

                ContactosCorreos nuevo = new ContactosCorreos
                {
                    Contactos_Id = (Guid)contacto.Id,
                    Email = i.Email,
                    Empresas_Id = contacto.Empresas_Id,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

                await _context.ContactosCorreos.AddAsync(nuevo);

            }

            await _gestorRastro.AddRastro(User.Identity.Name, contactoEdit.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Modificar, null, null);

            return Ok();
      
        }

        // POST: api/Contactos
        [HttpPost]
        public async Task<IActionResult> PostContactos([FromBody] DTOContactos contacto)
        {

                Contactos nuevoContactos = new Contactos
                {
                    Entidades_Id = (Guid)contacto.Entidades_Id,
                    Empresas_Id = contacto.Empresas_Id,
                    Nombre = contacto.Nombre,
                    Apellido1 = contacto.Apellido1,
                    Apellido2 = contacto.Apellido2,
                    Direccion = contacto.Direccion,
                    Localidades_Id = contacto.Localidades_Id,
                    CodigoPostal = contacto.CodigoPostal,
                    Provincias_Id = contacto.Provincias_Id,
                    Paises_Id = contacto.Paises_Id,
                    Telefono = contacto.Telefono,
                    Movil = contacto.Movil,
                    Fax = contacto.Fax,
                    Email = contacto.Email,
                    Departamento = contacto.Maestros_IdDepartamento,
                    Cargo = contacto.Cargo,
                    //Maestros_IdClasif1 = contacto.Maestros_IdClasif1,
                    //Maestros_IdClasif2 = contacto.Maestros_IdClasif2,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

            await _context.Contactos.AddAsync(nuevoContactos);
            await _context.SaveChangesAsync();

            foreach (var i in contacto.Telefonos)
            {

                ContactosTelefonos nuevo = new ContactosTelefonos
                {
                    Contactos_Id = nuevoContactos.Id,
                    Telefono = i.Telefono,
                    Empresas_Id = contacto.Empresas_Id,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

                await _context.ContactosTelefonos.AddAsync(nuevo);

            }
            await _context.SaveChangesAsync();


            foreach (var i in contacto.Correos)
            {

                ContactosCorreos nuevo2 = new ContactosCorreos
                {
                    Contactos_Id = nuevoContactos.Id,
                    Email = i.Email,
                    Empresas_Id = contacto.Empresas_Id,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

                await _context.ContactosCorreos.AddAsync(nuevo2);


            }
            await _context.SaveChangesAsync();


           
            await _gestorRastro.AddRastro(User.Identity.Name, contacto.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Agregar, contacto.Nombre, null);

            return Ok();
        }




        // POST: api/Clientes/uploadImagen
        [HttpPost, Route("uploadImagen/{id}")]
        public async Task<IActionResult> UploadLogo([FromRoute] Guid id)
        {
            //id es el idCliente
            var contacto = await _context.Contactos.FindAsync(id);

            var uploadPath = Path.Combine(_server.WebRootPath, "Contactos");

            // Borrar Imagen existente antes de subir otra
            if (contacto.UrlImagen != null)
            {
                string filePath = "";

                filePath = Path.Combine(_server.WebRootPath, "Contactos", contacto.UrlImagen);

                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }
            }
            //

            string newName = "";
            foreach (var file in Request.Form.Files)
            {
                if (file.Length > 0)
                {
                    FileInfo currentFile = new FileInfo(file.FileName);
                    //newName = id + "_logo" + currentFile.Extension;
                    newName = id + "_" + file.FileName;
                    var filePath = Path.Combine(uploadPath, newName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                }
            }

            contacto.UrlImagen = newName;
            _context.Entry(contacto).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, contacto.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Cambiar_imagen, contacto.Nombre, null);

            return Ok();
        }

        // GET: api/Contactos/downloadImagen/idContacto
        [HttpGet("downloadImagen/{idContacto}")]
        public async Task<IActionResult> DownloadImagenByIdContacto([FromRoute] Guid idContacto)
        {
            string filePath = "";


            var contacto = await _context.Contactos.FindAsync(idContacto);
            if (contacto.UrlImagen != null)
            {
                filePath = Path.Combine(_server.WebRootPath, "Contactos", contacto.UrlImagen);
            }
            else
            {
                filePath = Path.Combine(_server.WebRootPath, "Imagenes", "noimage.png");
            }

            if (System.IO.File.Exists(filePath))
            {
                byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);

                await _gestorRastro.AddRastro(User.Identity.Name, contacto.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Ver_imagen, contacto.Nombre, null);

                return new FileContentResult(fileBytes, "application/octet");
            }
            else
            {
                return Conflict("Imagen inexistente");
            }
        }

        [HttpDelete("deleteImagen/{idContacto}")]
        public async Task<IActionResult> DeleteImagen([FromRoute] Guid idContacto)
        {
            String filePath = "";
            var imagen = await _context.Contactos.FindAsync(idContacto);

            filePath = Path.Combine(_server.WebRootPath, "Contactos", imagen.UrlImagen);

            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
                imagen.UrlImagen = null;
            }


            await _gestorRastro.AddRastro(User.Identity.Name, imagen.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Eliminar, imagen.UrlImagen, null);

            return Ok(imagen);
        }


        // DELETE: api/Trabajadores/5
        [HttpDelete("{IdContacto}")]
        public async Task<IActionResult> DeleteContactos([FromRoute] Guid IdContacto)
        {
            var contacto = await _context.Contactos.FindAsync(IdContacto);
            if (contacto == null)
            {
                return NotFound("Contacto no encontrado");
            }

            // Borrar Imagen
            if (contacto.UrlImagen != null)
            {
                string filePath = "";
                filePath = Path.Combine(_server.WebRootPath, "Contactos", contacto.UrlImagen);

                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }
            }
            //



            var telefonos = await (from x in _context.ContactosTelefonos
                                   where x.Contactos_Id == contacto.Id
                                   select x).ToListAsync();

            foreach (var j in telefonos)
            {

                _context.ContactosTelefonos.Remove(j);

            }


            var correos = await (from x in _context.ContactosCorreos
                                 where x.Contactos_Id == contacto.Id
                                 select x).ToListAsync();

            foreach (var j in correos)
            {

                _context.ContactosCorreos.Remove(j);

            }


            _context.Contactos.Remove(contacto);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, contacto.Empresas_Id, EnumTipoProcesoRastro.Contactos, EnumTipoAccionRastro.Eliminar, contacto.Nombre, null);

            return Ok(contacto);
        }

    }
}

