﻿using System;
using System.Collections.Generic;
//using System.Data.Entity.Core.Objects;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CalendariosController : ControllerBase
    {
        private readonly ApineticsContext _context;

        public CalendariosController(ApineticsContext context)
        {
            _context = context;
        }

        // GET: api/Calendarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Calendario>>> GetCalendario()
        {
            return await _context.Calendario.ToListAsync();
        }

        // GET: api/Calendarios/5
        [HttpGet("{Id}/{year}")]
        public async Task<IActionResult> GetCalendario([FromRoute] Guid Id, [FromRoute] int year)
        {
            var calendario = await (from x in _context.Calendario
                                    where x.Empresas_Id == Id && x.Fecha.Year == year
                                    select new DTODiaCalendario
                                    {
                                        Id = x.Id,
                                        Fecha = x.Fecha.ToDateTime(new TimeOnly(0, 0)),
                                        Trabajadores_Id = x.Trabajadores_Id,
                                        Abreviatura = x.Trabajadores.Abreviatura,
                                        Empresas_Id = x.Empresas_Id,
                                    }).ToListAsync();

            if (calendario == null)
            {
                return NotFound();
            }

            return Ok(calendario);
        }

        // PUT: api/Calendarios/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCalendario(Guid id, Calendario calendario)
        {
            if (id != calendario.Id)
            {
                return BadRequest();
            }

            _context.Entry(calendario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CalendarioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        // POST: api/Calendarios
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<IActionResult> PostCalendario([FromBody] DTODiaCalendario dia)
        {
            if (dia == null)
            {
                return BadRequest ("No se proporcionaron datos válidos.");
            }

            var f = new DateOnly(dia.Fecha.Year, dia.Fecha.Month, dia.Fecha.Day);
            bool existe = await _context.Calendario.AnyAsync(x => x.Fecha == f && x.Empresas_Id == dia.Empresas_Id);

            if (!existe)
            {
                await _context.Calendario.AddAsync(new Calendario
                {
                    Fecha = f,
                    Empresas_Id = dia.Empresas_Id,
                    Trabajadores_Id = dia.Trabajadores_Id,
                });
            }

            await _context.SaveChangesAsync();
            return Ok(new { response = "Asignaciones guardadas correctamente" });
        }

        //DELETE: api/Calendarios/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Calendario>> DeleteCalendario(Guid id)
        {
            var calendario = await _context.Calendario.FindAsync(id);
            if (calendario == null)
            {
                return NotFound();
            }

            _context.Calendario.Remove(calendario);
            await _context.SaveChangesAsync();

            return calendario;
        }


        [HttpDelete("{Id}/{tipo}")]
        public async Task<IActionResult> DeleteCalendarios(Guid Id, string tipo)
        {
            var calendarios = await _context.Calendario.Where(x => x.Empresas_Id == new Guid("5AA878E7-B399-4195-8298-D6CBF37A779C")).ToListAsync();

            DateTime firstSaturday = new DateTime(1753, 1, 6);
            DateTime firstSunday = new DateTime(1753, 1, 7);

            var i = 0;
            if (tipo.Length > 1)
            {
                while (i < calendarios.Count)
                {
                    if (calendarios[i].Fecha.DayOfWeek != DayOfWeek.Saturday &&
                        calendarios[i].Fecha.DayOfWeek != DayOfWeek.Sunday)
                    {
                        calendarios.Remove(calendarios[i]);
                    }
                    else
                    {
                        i++;
                    }
                }
            }
            else
            {
                if (tipo == "S")
                {
                    while (i < calendarios.Count)
                    {
                        if (calendarios[i].Fecha.DayOfWeek != DayOfWeek.Saturday)
                        {
                            calendarios.Remove(calendarios[i]);
                        }
                        else
                        {
                            i++;
                        }
                    }
                }
                else
                {
                    while (i < calendarios.Count)
                    {
                        if (calendarios[i].Fecha.DayOfWeek != DayOfWeek.Sunday)
                        {
                            calendarios.Remove(calendarios[i]);
                        }
                        else
                        {
                            i++;
                        }
                    }
                }
            }

            if (calendarios == null)
            {
                return NotFound();
            }
            _context.Calendario.RemoveRange(calendarios);
            await _context.SaveChangesAsync();
            return Ok();
        }
        private bool CalendarioExists(Guid id)
        {
            return _context.Calendario.Any(e => e.Id == id);
        }




        //¡¡¡BORRAR TRABAJADOR ASIGNADO A DÍA!!!
        // DELETE: api/Calendarios/EliminarAsignacion/{id}/{trabajadorId}
        [HttpDelete("EliminarAsignacion/{id}/{trabajadorId}")]
        public async Task<IActionResult> DeleteAsignacion(Guid id, Guid trabajadorId)
        {
            //buscar asignacion específica en el calendario por fecha y trabajador
            var asignacion = await _context.Calendario
                                    .Where(c => c.Id == id && c.Trabajadores_Id == trabajadorId)
                                    .FirstOrDefaultAsync();

            if (asignacion == null)
            {
                return NotFound(new {message = "Asignación no encontrada"});
            }

            //eliminar la asignación
            _context.Calendario.Remove(asignacion);
            await _context.SaveChangesAsync();
            return Ok();
        }
    }
}
