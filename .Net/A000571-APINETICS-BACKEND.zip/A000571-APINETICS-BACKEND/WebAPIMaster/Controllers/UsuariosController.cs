﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;
using static WebAPIMaster.ModelsDTO.DTOEntidades;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IConfiguration _configuration;
        private readonly IGestorRastro _gestorRastro;
        private readonly IPasswords _passwords;

        public UsuariosController(ApineticsContext context, IConfiguration configuration, IGestorRastro gestorRastro, IPasswords passwords)
        {
            _context = context;
            _gestorRastro = gestorRastro;
            _configuration = configuration;
            _passwords = passwords;
        }


        // GET: api/Usuarios
        //[HttpGet("{idEmpresa}")]
        //public async Task<IActionResult> GetUsuariosById([FromRoute] Guid idEmpresa)
        //{
        //    var yo = User.Identity.Name;
        //    var tipo = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).SingleOrDefaultAsync();
        //    if (tipo.SuperAdministrador == true)
        //    {
        //        //si el logueado es superadmin
        //        // ve a todos(superadmins, distribuidores y empleados) de la empresa seleccionada
        //        List<DTOUsuarios> usuarios = new List<DTOUsuarios>();
        //        var infor = await _context.Usuarios.Where(x => x.Empresas_Id == idEmpresa || x.SuperAdministrador == true).OrderBy(x => x.Nombre).ToListAsync();
        //        foreach (var usuario in infor)
        //        {
        //            var entidad = await _context.Entidades.FindAsync(usuario.Entidades_Id);

        //            DTOUsuarios nuevo = new DTOUsuarios
        //            {
        //                Id = usuario.Id,
        //                Entidades_Id = usuario.Entidades_Id,
        //                Email = usuario.Email,
        //                Nombre = entidad != null ? entidad.RazonSocial : usuario.Nombre,
        //                RazonSocial = usuario.Entidades.RazonSocial,
        //                NIFCIF = usuario.Entidades.NIFCIF,
        //                NombreConyuge = usuario.Entidades.NombreConyuge,
        //                ApellidosConyuge = usuario.Entidades.Apellido1Conyuge + " " + usuario.Entidades.Apellido2Conyuge,
        //                NIFConyuge = usuario.Entidades.NIFConyuge,
        //                Direccion = entidad != null ? entidad.Direccion : usuario.Direccion,
        //                CodigoPostal = entidad != null ? entidad.CodigoPostal : usuario.CodigoPostal,
        //                Localidades_Id = usuario.Entidades.Localidades_Id,
        //                //TelefonoFijo = usuario.TelefonoFijo,
        //                TelefonoMovil = usuario.TelefonoMovil,
        //                Observaciones = entidad != null ? entidad.Observaciones : usuario.Observaciones,
        //                Activo = entidad != null ? entidad.Estado : usuario.Activo,
        //                Empresas_Id = entidad != null ? entidad.Empresas_Id : usuario.Empresas_Id,
        //                Distribuidor = usuario.Distribuidor,
        //                Roles_Id = usuario.Roles_Id,
        //                IntentosErroneos = usuario.IntentosErroneos,
        //                SuperAdministrador = usuario.SuperAdministrador,
        //                Telefonos = (from z in _context.EntidadesTelefonos where z.Entidades_Id == usuario.Entidades_Id select new DTOEntidadesTelefonos { Entidades_Id = usuario.Entidades_Id, Telefono = z.Telefono }).ToList(),
        //                Correos = (from z in _context.EntidadesCorreos where z.Entidades_Id == usuario.Entidades_Id select new DTOEntidadesCorreos { Entidades_Id = usuario.Entidades_Id, Email = z.Email }).ToList()
        //            };

        //            var telefono = await _context.EntidadesTelefonos.Where(x => x.Entidades_Id == usuario.Entidades_Id)
        //                .Select(x => x.Telefono).FirstOrDefaultAsync();

        //            nuevo.TelefonoFijo = telefono;

        //            if (usuario.Roles_Id != null)
        //            {
        //                var rol = await (from x in _context.Roles
        //                                 where x.Id == usuario.Roles_Id
        //                                 select x.Descripcion).FirstOrDefaultAsync();

        //                nuevo.NombreRol = rol;
        //            }
        //            else
        //            {
        //                nuevo.NombreRol = "Super Administrador";
        //            }

        //            var sesion = await (from x in _context.Rastro
        //                                where x.Usuarios_Id == usuario.Id
        //                                orderby x.FechaAccion descending
        //                                select x.Operacion).FirstOrDefaultAsync();

        //            if (sesion != null)
        //            {
        //                nuevo.SesionActiva = sesion != "Cerrar_sesion" && usuario.Roles_Id != null ? true : false;
        //            }

        //            usuarios.Add(nuevo);
        //        }

        //        var distribuidorores = await (from x in _context.UsuariosDistribuidores
        //                                      where x.Empresas_Id == idEmpresa
        //                                      select new DTOUsuarios
        //                                      {
        //                                          Id = x.Usuarios.Id,
        //                                          Nombre = x.Usuarios.Entidades.RazonSocial,
        //                                          Direccion = x.Usuarios.Entidades.Direccion,
        //                                          CodigoPostal = x.Usuarios.Entidades.CodigoPostal,
        //                                          TelefonoFijo = x.Usuarios.TelefonoFijo,
        //                                          TelefonoMovil = x.Usuarios.TelefonoMovil,
        //                                          Email = x.Usuarios.Email,
        //                                          SuperAdministrador = x.Usuarios.SuperAdministrador,
        //                                          Observaciones = x.Usuarios.Entidades.Observaciones,
        //                                          Activo = x.Usuarios.Entidades.Estado,
        //                                          Empresas_Id = x.Usuarios.Entidades.Empresas_Id,
        //                                          Distribuidor = x.Usuarios.Distribuidor,
        //                                          Roles_Id = x.Usuarios.Roles_Id,
        //                                          IntentosErroneos = x.Usuarios.IntentosErroneos,
        //                                          NombreRol = "Distribuidor"
        //                                      }).ToListAsync();



        //        foreach (var i in distribuidorores)
        //        {
        //            var empresas = await (from x in _context.UsuariosDistribuidores
        //                                  where x.Usuarios_Id == i.Id
        //                                  select (Guid)x.Empresas_Id).ToListAsync();


        //            i.Empresas = empresas;

        //            usuarios.Add(i);
        //        }


        //        await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

        //        return Ok(usuarios);


        //    }
        //    else if (tipo.Distribuidor == true)
        //    {
        //        //si el logueado es distribuidor
        //        //se ve a el mismo y a ningun distribuidor mas y a los empleados de la empresa seleccionada

        //        var usuarios = await (from x in _context.Usuarios
        //                              join y in _context.Entidades on x.Entidades_Id equals y.Id
        //                              where (x.Empresas_Id == idEmpresa && x.SuperAdministrador != true && x.Distribuidor != true) || (x.Id == tipo.Id)
        //                              select new DTOUsuarios
        //                              {
        //                                  Id = x.Id,
        //                                  Nombre = y.RazonSocial,
        //                                  Direccion = y.Direccion,
        //                                  CodigoPostal = y.CodigoPostal,
        //                                  TelefonoFijo = x.TelefonoFijo,
        //                                  TelefonoMovil = x.TelefonoMovil,
        //                                  Email = x.Email,
        //                                  SuperAdministrador = x.SuperAdministrador,
        //                                  Observaciones = y.Observaciones,
        //                                  Activo = y.Estado,
        //                                  Empresas_Id = y.Empresas_Id,
        //                                  Distribuidor = x.Distribuidor,
        //                                  Roles_Id = x.Roles_Id,
        //                                  IntentosErroneos = x.IntentosErroneos,
        //                                  NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
        //                              }).ToListAsync();


        //        var empresas = await (from x in _context.UsuariosDistribuidores
        //                              where x.Usuarios_Id == tipo.Id
        //                              select (Guid)x.Empresas_Id).ToListAsync();

        //        foreach (var i in usuarios)
        //        {
        //            if (i.Id == tipo.Id)
        //            {
        //                i.Empresas = empresas;
        //            }
        //        }

        //        await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

        //        return Ok(usuarios);


        //    }
        //    else if (tipo.SuperAdministrador != true && tipo.Distribuidor != true && tipo.Roles_Id == new Guid("596198CF-A905-4D91-B83A-9CB69A6A25ED"))
        //    {
        //        var usuarios = await (from x in _context.Usuarios
        //                              join y in _context.Entidades on x.Entidades_Id equals y.Id
        //                              where (x.Empresas_Id == idEmpresa && x.SuperAdministrador != true && x.Distribuidor != true) || (x.Id == tipo.Id)
        //                              select new DTOUsuarios
        //                              {
        //                                  Id = x.Id,
        //                                  Nombre = y.RazonSocial,
        //                                  Direccion = y.Direccion,
        //                                  CodigoPostal = y.CodigoPostal,
        //                                  TelefonoFijo = x.TelefonoFijo,
        //                                  TelefonoMovil = x.TelefonoMovil,
        //                                  Email = x.Email,
        //                                  SuperAdministrador = x.SuperAdministrador,
        //                                  Observaciones = y.Observaciones,
        //                                  Activo = y.Estado,
        //                                  Empresas_Id = y.Empresas_Id,
        //                                  Distribuidor = x.Distribuidor,
        //                                  Roles_Id = x.Roles_Id,
        //                                  IntentosErroneos = x.IntentosErroneos,
        //                                  NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
        //                              }).ToListAsync();

        //        await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

        //        return Ok(usuarios);

        //    }
        //    else
        //    {
        //        var usuarios = await (from x in _context.Usuarios
        //                              join y in _context.Entidades on x.Entidades_Id equals y.Id
        //                              where x.Id == tipo.Id
        //                              select new DTOUsuarios
        //                              {
        //                                  Id = x.Id,
        //                                  Nombre = y.RazonSocial,
        //                                  Direccion = y.Direccion,
        //                                  CodigoPostal = y.CodigoPostal,
        //                                  TelefonoFijo = x.TelefonoFijo,
        //                                  TelefonoMovil = x.TelefonoMovil,
        //                                  Email = x.Email,
        //                                  SuperAdministrador = x.SuperAdministrador,
        //                                  Observaciones = y.Observaciones,
        //                                  Activo = y.Estado,
        //                                  Empresas_Id = y.Empresas_Id,
        //                                  Distribuidor = x.Distribuidor,
        //                                  Roles_Id = x.Roles_Id,
        //                                  IntentosErroneos = x.IntentosErroneos,
        //                                  NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
        //                              }).ToListAsync();

        //        await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

        //        return Ok(usuarios);
        //    }
        //}

        // GET: api/Usuarios
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetUsuariosCombo([FromRoute] Guid idEmpresa)
        {
            var usuario = await (from x in _context.Usuarios
                                 where (x.Empresas_Id == idEmpresa)
                                 orderby x.Nombre
                                 select new DTODataCombo
                                 {
                                     Value = x.Id,
                                     Label = x.Email
                                 }).ToListAsync();

            return Ok(usuario);
        }

        //// GET: api/Usuarios
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetUsuariosByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var admin = new Guid("E31D4C6D-519F-401A-BE91-E45499B706D6");
            var tipo = await (from x in _context.Usuarios
                              where x.Email == User.Identity.Name
                              select x).SingleOrDefaultAsync();

            if (tipo.SuperAdministrador == true)
            {
                var usuarios = await (from x in _context.Usuarios
                                      where (x.Empresas_Id == idEmpresa || x.SuperAdministrador == true)
                                      && x.Deshabilitado == false
                                      select new DTOUsuarios
                                      {
                                          Id = x.Id,
                                          Nombre = x.Nombre,
                                          Direccion = x.Direccion,
                                          CodigoPostal = x.CodigoPostal,
                                          Telefono = (!x.TelefonoFijo.IsNullOrEmpty() ? x.TelefonoFijo : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() && !x.TelefonoMovil.IsNullOrEmpty() ? "/" : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() ? x.TelefonoMovil : ""),
                                          TelefonoFijo = x.TelefonoFijo,
                                          TelefonoMovil = x.TelefonoMovil,
                                          Email = x.Email,
                                          SuperAdministrador = x.SuperAdministrador,
                                          Observaciones = x.Observaciones,
                                          Activo = x.Activo,
                                          Empresas_Id = x.Empresas_Id,
                                          Distribuidor = x.Distribuidor,
                                          Roles_Id = x.Roles_Id,
                                          IntentosErroneos = x.IntentosErroneos,
                                          NombreRol = x.Roles.Descripcion
                                      }).ToListAsync();

                var distribuidorores = await (from x in _context.UsuariosDistribuidores
                                              join y in _context.Usuarios on x.Usuarios_Id equals y.Id
                                              where x.Empresas_Id == idEmpresa && y.Deshabilitado == false
                                              select new DTOUsuarios
                                              {
                                                  Id = x.Usuarios.Id,
                                                  Nombre = x.Usuarios.Nombre,
                                                  Direccion = x.Usuarios.Direccion,
                                                  CodigoPostal = x.Usuarios.CodigoPostal,
                                                  Telefono = (!x.Usuarios.TelefonoFijo.IsNullOrEmpty() ? x.Usuarios.TelefonoFijo : "") +
                                                             (!x.Usuarios.TelefonoMovil.IsNullOrEmpty() && !x.Usuarios.TelefonoMovil.IsNullOrEmpty() ? "/" : "") +
                                                             (!x.Usuarios.TelefonoMovil.IsNullOrEmpty() ? x.Usuarios.TelefonoMovil : ""),
                                                  TelefonoFijo = x.Usuarios.TelefonoFijo,
                                                  TelefonoMovil = x.Usuarios.TelefonoMovil,
                                                  Email = x.Usuarios.Email,
                                                  SuperAdministrador = x.Usuarios.SuperAdministrador,
                                                  Observaciones = x.Usuarios.Observaciones,
                                                  Activo = x.Usuarios.Activo,
                                                  Empresas_Id = x.Usuarios.Empresas_Id,
                                                  Distribuidor = x.Usuarios.Distribuidor,
                                                  Roles_Id = x.Usuarios.Roles_Id,
                                                  IntentosErroneos = x.Usuarios.IntentosErroneos,
                                                  NombreRol = "Distribuidor"
                                              }).ToListAsync();

                foreach (var i in distribuidorores)
                {
                    var empresas = await (from x in _context.UsuariosDistribuidores
                                          where x.Usuarios_Id == i.Id
                                          select x.Empresas_Id).ToListAsync();

                    if (empresas != null)
                    {
                        i.Empresas = empresas;
                    }

                    usuarios.Add(i);
                }

                for (var i = 0; i < usuarios.Count; i++)
                {
                    var sesion = await (from x in _context.Rastro
                                        where x.Usuarios_Id == usuarios[i].Id
                                        orderby x.FechaAccion descending
                                        select x.Operacion).FirstOrDefaultAsync();

                    if (sesion != null)
                    {
                        usuarios[i].SesionActiva = sesion != "Cerrar_sesion" && usuarios[i].Roles_Id != null ? true : false;
                    }
                }

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

                return Ok(usuarios);
            }
            else if (tipo.Distribuidor == true)
            {
                var usuarios = await (from x in _context.Usuarios
                                      where ((x.Empresas_Id == idEmpresa && x.SuperAdministrador != true && x.Distribuidor != true) || (x.Id == tipo.Id))
                                      && x.Deshabilitado == false
                                      select new DTOUsuarios
                                      {
                                          Id = x.Id,
                                          Nombre = x.Nombre,
                                          Direccion = x.Direccion,
                                          CodigoPostal = x.CodigoPostal,
                                          Telefono = (!x.TelefonoFijo.IsNullOrEmpty() ? x.TelefonoFijo : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() && !x.TelefonoMovil.IsNullOrEmpty() ? "/" : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() ? x.TelefonoMovil : ""),
                                          TelefonoFijo = x.TelefonoFijo,
                                          TelefonoMovil = x.TelefonoMovil,
                                          Email = x.Email,
                                          SuperAdministrador = x.SuperAdministrador,
                                          Observaciones = x.Observaciones,
                                          Activo = x.Activo,
                                          Empresas_Id = x.Empresas_Id,
                                          Distribuidor = x.Distribuidor,
                                          Roles_Id = x.Roles_Id,
                                          IntentosErroneos = x.IntentosErroneos,
                                          NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
                                      }).ToListAsync();

                var empresas = await (from x in _context.UsuariosDistribuidores
                                      where x.Usuarios_Id == tipo.Id
                                      select x.Empresas_Id).ToListAsync();

                foreach (var i in usuarios)
                {
                    if (i.Id == tipo.Id)
                    {
                        i.Empresas = empresas;
                    }
                }

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

                return Ok(usuarios);
            }
            else if (tipo.SuperAdministrador != true && tipo.Distribuidor != true && tipo.Roles_Id == admin)
            {
                var usuarios = await (from x in _context.Usuarios
                                      where ((x.Empresas_Id == idEmpresa && x.SuperAdministrador != true && x.Distribuidor != true) || (x.Id == tipo.Id))
                                      && x.Deshabilitado == false
                                      select new DTOUsuarios
                                      {
                                          Id = x.Id,
                                          Nombre = x.Nombre,
                                          Direccion = x.Direccion,
                                          CodigoPostal = x.CodigoPostal,
                                          Telefono = (!x.TelefonoFijo.IsNullOrEmpty() ? x.TelefonoFijo : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() && !x.TelefonoMovil.IsNullOrEmpty() ? "/" : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() ? x.TelefonoMovil : ""),
                                          TelefonoFijo = x.TelefonoFijo,
                                          TelefonoMovil = x.TelefonoMovil,
                                          Email = x.Email,
                                          SuperAdministrador = x.SuperAdministrador,
                                          Observaciones = x.Observaciones,
                                          Activo = x.Activo,
                                          Empresas_Id = x.Empresas_Id,
                                          Distribuidor = x.Distribuidor,
                                          Roles_Id = x.Roles_Id,
                                          IntentosErroneos = x.IntentosErroneos,
                                          NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
                                      }).ToListAsync();
                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);
                return Ok(usuarios);
            }
            else
            {
                var usuarios = await (from x in _context.Usuarios
                                      where x.Id == tipo.Id && x.Deshabilitado == false
                                      select new DTOUsuarios
                                      {
                                          Id = x.Id,
                                          Nombre = x.Nombre,
                                          Direccion = x.Direccion,
                                          CodigoPostal = x.CodigoPostal,
                                          Telefono = (!x.TelefonoFijo.IsNullOrEmpty() ? x.TelefonoFijo : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() && !x.TelefonoMovil.IsNullOrEmpty() ? "/" : "") +
                                                     (!x.TelefonoMovil.IsNullOrEmpty() ? x.TelefonoMovil : ""),
                                          TelefonoFijo = x.TelefonoFijo,
                                          TelefonoMovil = x.TelefonoMovil,
                                          Email = x.Email,
                                          SuperAdministrador = x.SuperAdministrador,
                                          Observaciones = x.Observaciones,
                                          Activo = x.Activo,
                                          Empresas_Id = x.Empresas_Id,
                                          Distribuidor = x.Distribuidor,
                                          Roles_Id = x.Roles_Id,
                                          IntentosErroneos = x.IntentosErroneos,
                                          NombreRol = x.Roles_Id != null ? x.Roles.Descripcion : null
                                      }).ToListAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Consultar, null, null);

                return Ok(usuarios);
            }
        }

        [HttpGet("obtenerPermisos")]
        public async Task<IActionResult> GetPermisosUsuario([FromQuery] string email)
        {
            var perfil = await (from x in _context.Usuarios
                                where x.Email == email
                                select new
                                {
                                    x.Empresas_Id,
                                    x.Roles_Id,
                                }).SingleOrDefaultAsync();

            var param = await _context.Parametros.Where(x => x.Id == perfil.Empresas_Id).FirstAsync();

            if (param == null)
            {
                return Conflict("Faltan por establecer los parámetros de empresa.");
            }

            var procesos = await (from x in _context.Procesos select x.Id).ToListAsync();

            var datos = await (from x in _context.Permisos
                               where x.Empresas_Id == perfil.Empresas_Id
                               && x.Roles_Id == perfil.Roles_Id
                               && procesos.Contains((Guid)x.Procesos_Id)
                               select new
                               {
                                   IdProceso = x.Procesos.Id,
                                   Roles_Id = x.Roles_Id,
                                   Procesos_Id = (Guid)x.Procesos_Id,
                                   Empresas_Id = x.Empresas_Id,
                                   Visible = x.Visible,
                                   Modificable = x.Modificable,
                                   Orden = x.Procesos.Orden
                               }).ToListAsync();

            return Ok(datos);
        }

        [HttpGet("sesion")]
        public async Task<IActionResult> GetSesionActiva()
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();
            var activo = false;
            if (usuario != null)
            {
                var sesion = await (from x in _context.Rastro
                                    where x.Usuarios_Id == usuario.Id
                                    orderby x.FechaAccion descending
                                    select x.Operacion).FirstOrDefaultAsync();

                if (sesion != null)
                {
                    activo = sesion != "Cerrar_sesion" ? true : false;
                }
            }
            return Ok(activo);
        }

        [HttpPut]
        public async Task<IActionResult> PutUsuarios([FromBody] DTOUsuarios usuario)
        {
            if (usuario.Email != null && usuario.Email.Trim() != "")
            {
                var emailExiste = await _context.Usuarios.Where(x => x.Email == usuario.Email && x.Id != usuario.Id).FirstOrDefaultAsync();
                if (emailExiste != null)
                {
                    if (emailExiste.Deshabilitado == true)
                    {
                        return Conflict("Este email está asignado a un usuario deshabilitado por el sistema");
                    }
                    return Conflict("Un usuario con este email ya está registrado");
                }
            }

            var entidad = await _context.Entidades.FindAsync(usuario.Entidades_Id);

            var usuarioEdit = await _context.Usuarios.FindAsync(usuario.Id);

            if (usuarioEdit != null)
            {
                usuarioEdit.Entidades_Id = usuario.Entidades_Id;
                usuarioEdit.Nombre = usuario.Nombre;
                usuarioEdit.Direccion = usuario.Direccion;
                usuarioEdit.CodigoPostal = usuario.CodigoPostal;
                //usuarioEdit.TelefonoFijo = usuario.TelefonoFijo;
                //usuarioEdit.TelefonoMovil = usuario.TelefonoMovil;
                usuarioEdit.SuperAdministrador = usuario.SuperAdministrador;
                usuarioEdit.Observaciones = usuario.Observaciones;
                usuarioEdit.Activo = usuario.Activo;
                usuarioEdit.Empresas_Id = usuario.Empresas_Id;
                usuarioEdit.Distribuidor = usuario.Distribuidor;
                usuarioEdit.Roles_Id = usuario.Roles_Id;

                var telefono = await _context.EntidadesTelefonos.Where(x => x.Entidades_Id == usuario.Entidades_Id)
                        .Select(x => x.Telefono).FirstOrDefaultAsync();

                usuarioEdit.TelefonoFijo = telefono;
                _context.Entry(usuarioEdit).State = EntityState.Modified;

                if (usuario.Distribuidor == true)
                {
                    var eliminar = await (from x in _context.UsuariosDistribuidores
                                          where x.Usuarios_Id == usuario.Id
                                          select x).ToListAsync();

                    foreach (var e in eliminar)
                    {
                        _context.UsuariosDistribuidores.Remove(e);
                    }

                    if (usuario.Empresas != null && usuario.Empresas.Count != 0)
                    {
                        foreach (var empresa in usuario.Empresas)
                        {
                            UsuariosDistribuidores nuevo = new UsuariosDistribuidores
                            {
                                Usuarios_Id = (Guid)usuario.Id,
                                Empresas_Id = (Guid)empresa

                            };

                            await _context.UsuariosDistribuidores.AddAsync(nuevo);
                        }
                    }
                }
            }
            else
            {
                return Conflict("Este usuario ya no existe");
            }

            await _context.SaveChangesAsync();
            await _gestorRastro.AddRastro(User.Identity.Name, usuario.Empresas_Id, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Modificar, usuario.Email, null);

            return Ok();
        }

        [HttpPut("cambiarEstado/{Id}")]
        public async Task<IActionResult> cambiarEstado([FromRoute] Guid Id)
        {
            var usuarioEdit = await _context.Usuarios.FindAsync(Id);
            if (usuarioEdit != null)
            {
                usuarioEdit.Activo = !usuarioEdit.Activo;

                _context.Entry(usuarioEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("No se encuentra al usuario");
            }

            await _context.SaveChangesAsync();
            await _gestorRastro.AddRastro(User.Identity.Name, usuarioEdit.Empresas_Id, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Modificar, usuarioEdit.Email, null);

            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> PostUsuarios([FromBody] DTOUsuarios usuario)
        {
            if (usuario.Email != null && usuario.Email.Trim() != "")
            {
                var emailExiste = await _context.Usuarios.AnyAsync(x => x.Email == usuario.Email);
                if (emailExiste)
                {
                    return Conflict("Un usuario con este email ya está registrado");
                }
            }

            var secret = _configuration.GetSection("HeSecretPass").Value;
            string passMD5 = _passwords.Encrypt(usuario.Password, secret);

            var entidad = await _context.Entidades.FindAsync(usuario.Entidades_Id);

            using var transaction = _context.Database.BeginTransaction();

            try
            {
                // AQUÍ COMIENZA LA MODIFICACIÓN, INTRODUCCIÓN DE ENTIDADEsCONTROLLER //

                Entidades nuevoEntidad = new Entidades();

                if (usuario.Entidades_Id == null)
                {
                    string apellidoFisicoCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(usuario.Entidad.Apellido1Fisico))
                    {
                        apellidoFisicoCompleto = usuario.Entidad.Apellido1Fisico;
                        if (!string.IsNullOrEmpty(usuario.Entidad.Apellido2Fisico))
                        {
                            apellidoFisicoCompleto += "" + usuario.Entidad.Apellido2Fisico;
                        }
                    }

                    string apellidoConyugeCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(usuario.Entidad.Apellido1Conyuge))
                    {
                        apellidoConyugeCompleto = usuario.Entidad.Apellido1Conyuge;
                        if (!string.IsNullOrEmpty(usuario.Entidad.Apellido2Conyuge))
                        {
                            apellidoConyugeCompleto += "" + usuario.Entidad.Apellido2Conyuge;
                        }
                    }
                    nuevoEntidad = new Entidades()
                    {
                        Codigo = usuario.Entidad.Codigo,
                        Tipo = usuario.Entidad.Tipo,
                        Nombre = usuario.Entidad.Tipo == "J" ? usuario.Entidad.Nombre :
                                (usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + "; " : "") + usuario.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + usuario.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + usuario.Entidad.Nombre : "") : "",
                        RazonSocial = usuario.Entidad.Tipo == "J" ? usuario.Entidad.RazonSocial :
                                (usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + "; " : "") + usuario.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + usuario.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + usuario.Entidad.Nombre : "") : "",
                        NombreFisico = usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC" ? usuario.Entidad.NombreFisico : null,
                        Apellido1Fisico = usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC" ? usuario.Entidad.Apellido1Fisico : null,
                        Apellido2Fisico = usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC" ? usuario.Entidad.Apellido2Fisico : null,
                        NombreConyuge = usuario.Entidad.Tipo == "FC" ? usuario.Entidad.NombreConyuge : null,
                        Apellido1Conyuge = usuario.Entidad.Tipo == "FC" ? usuario.Entidad.Apellido1Conyuge : null,
                        Apellido2Conyuge = usuario.Entidad.Tipo == "FC" ? usuario.Entidad.Apellido2Conyuge : null,
                        NIFCIF = usuario.Entidad.NIFCIF,
                        Descripcion = usuario.Entidad.Tipo == "J" ? usuario.Entidad.RazonSocial :
                                (usuario.Entidad.Tipo == "F" || usuario.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + usuario.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + usuario.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(usuario.Entidad.NombreConyuge) ? " Y " + usuario.Entidad.NombreConyuge : "") : "",
                        Empresas_Id = usuario.Entidad.Empresas_Id,
                        DescCorta = usuario.Entidad.DescCorta,
                        CodigoPostal = usuario.Entidad.CodigoPostal,
                        Localidades_Id = usuario.Entidad.Localidades_Id,
                        Observaciones = usuario.Entidad.Observaciones,
                        Estado = usuario.Entidad.Activa,
                        Paises_Id = usuario.Entidad.Paises_Id,
                        Provincias_Id = usuario.Entidad.Provincias_Id,
                        Direccion = usuario.Entidad.Direccion,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };
                    //añadir entidad recién creada a la BBDD

                    await _context.Entidades.AddAsync(nuevoEntidad);
                    await _context.SaveChangesAsync();

                    // TELEFONOS
                    foreach (var telefonos in usuario.Entidad.Telefonos)
                    {
                        var telefonoExistente = await _context.EntidadesTelefonos.
                            AnyAsync(t => t.Telefono == telefonos.Telefono && t.Empresas_Id == nuevoEntidad.Empresas_Id);
                        if (!telefonoExistente)

                        {
                            EntidadesTelefonos nuevoTelefono = new EntidadesTelefonos
                            {
                                Entidades_Id = nuevoEntidad.Id,
                                Telefono = telefonos.Telefono,
                                Empresas_Id = nuevoEntidad.Empresas_Id,
                                UsuarioCreacion = User.Identity.Name,
                                FechaCreacion = DateTime.Now,
                                UsuarioModificacion = User.Identity.Name,
                                FechaModificacion = DateTime.Now
                            };

                            await _context.EntidadesTelefonos.AddAsync(nuevoTelefono);
                        }
                    }
                    // CORREOS

                    foreach (var correo in usuario.Entidad.Correos)
                    {
                        var correoExistente = await _context.EntidadesCorreos.
                            AnyAsync(c => c.Email == correo.Email && c.Empresas_Id == nuevoEntidad.Empresas_Id);
                        if (!correoExistente)
                        {
                            EntidadesCorreos nuevoCorreo = new EntidadesCorreos
                            {
                                Entidades_Id = nuevoEntidad.Id,
                                Email = correo.Email,
                                Empresas_Id = nuevoEntidad.Empresas_Id,
                                UsuarioCreacion = User.Identity.Name,
                                FechaCreacion = DateTime.Now,
                                UsuarioModificacion = User.Identity.Name,
                                FechaModificacion = DateTime.Now
                            };
                            await _context.EntidadesCorreos.AddAsync(nuevoCorreo);
                        }
                    }

                    // ENTIDADES TIPOS   

                    EntidadesTipos nuevoEntidadTipo = new EntidadesTipos
                    {
                        Entidades_Id = nuevoEntidad.Id,
                        TiposEntidades_Id = new Guid("85CD8B16-2E5B-452F-9A53-1B4EBBAD39A8"),
                        Empresas_Id = nuevoEntidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };
                    await _context.EntidadesTipos.AddAsync(nuevoEntidadTipo);
                    await _context.SaveChangesAsync();

                }
                // CREAR USUARIO
                Usuarios nuevoUsuario = new Usuarios
                {
                    Entidades_Id = usuario.Entidades_Id,
                    //Nombre = usuario.RazonSocial,
                    //Direccion = entidad.Direccion,
                    //CodigoPostal = entidad.CodigoPostal,
                    //TelefonoFijo = usuario.TelefonoFijo,
                    //TelefonoMovil = usuario.TelefonoMovil,
                    Email = usuario.Email,
                    SuperAdministrador = usuario.SuperAdministrador,
                    Observaciones = usuario.Observaciones,
                    Activo = true,
                    Empresas_Id = usuario.Empresas_Id,
                    Distribuidor = usuario.Distribuidor,
                    Password = passMD5,
                    Roles_Id = usuario.Roles_Id,
                    IntentosErroneos = 0,
                    Deshabilitado = false,
                };
                await _context.Usuarios.AddAsync(nuevoUsuario);
                await _context.SaveChangesAsync();

                if (usuario.Distribuidor == true)
                {
                    if (usuario.Empresas != null && usuario.Empresas.Count != 0)
                    {
                        foreach (var empresa in usuario.Empresas)
                        {
                            UsuariosDistribuidores nuevo = new UsuariosDistribuidores
                            {
                                Usuarios_Id = nuevoUsuario.Id,
                                Empresas_Id = (Guid)empresa
                            };

                            await _context.UsuariosDistribuidores.AddAsync(nuevo);
                            await _context.SaveChangesAsync();
                        }
                    }
                }
                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, usuario.Empresas_Id, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Agregar, usuario.Email, null);

            return Ok();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> DeleteUsuarios([FromRoute] Guid Id)
        {
            var usuario = await _context.Usuarios.FindAsync(Id);
            if (usuario == null)
            {
                return NotFound();
            }
            usuario.Deshabilitado = true;
            _context.Entry(usuario).State = EntityState.Modified;

            //_context.Usuarios.Remove(usuario);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, usuario.Empresas_Id, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Eliminar, usuario.Email, null);

            return Ok(usuario);
        }

        [HttpPut("desbloquearUsuario/{Id}")]
        public async Task<IActionResult> DesbloquearUsuario([FromRoute] Guid Id)
        {
            var usuario = await _context.Usuarios.FindAsync(Id);

            if (usuario != null)
            {
                usuario.IntentosErroneos = 0;
                _context.Entry(usuario).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, usuario.Empresas_Id, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.DesbloquearUsuario, usuario.Email, null);

            return Ok();
        }
    }
}