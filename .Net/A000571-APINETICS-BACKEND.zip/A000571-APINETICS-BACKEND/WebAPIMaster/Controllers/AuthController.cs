﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;

namespace WebAPIMaster.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;
        private readonly IHttpContextAccessor _accessor;
        private readonly IConfiguration _configuration;
        private readonly IPasswords _passwords;

        public AuthController(ApineticsContext context, IGestorRastro gestorRastro, IConfiguration configuration, IPasswords passwords, IHttpContextAccessor accessor)
        {
            _context = context;
            _gestorRastro = gestorRastro;
            _configuration = configuration;
            _passwords = passwords;
            _accessor = accessor;
        }

        [HttpPost, Route("login")]
        public async Task<ActionResult> Login([FromBody] InfoLogin user)
        {
            if (user == null)
            {
                return BadRequest("Credenciales vacías");
            }
            var secretPass = _configuration.GetSection("AnSecretPass").Value;
            string passMD5 = _passwords.Encrypt(user.Password, secretPass);

            Usuarios usuario = null;

            usuario = await (from x in _context.Usuarios
                             where x.Email == user.UserName.Trim()
                             select x).SingleOrDefaultAsync();

            if (usuario == null)
            {
                return Unauthorized();
            }
            else
            {
                //si el usuario está deshabilitado no le dejamos entrar
                if (usuario.Deshabilitado == true)
                {
                    return Conflict("Deshabilitado");
                }

                //si el usuario está inactivo no le dejamos entrar
                if (usuario.Activo != true)
                {
                    return Conflict("Inactivo");
                }

                //si el usuario ha introducido la contraseña mas de 4 veces mal no le dejamos entrar
                if (usuario.IntentosErroneos > 4)
                {
                    return Conflict("Bloqueado");
                }
                else
                {
                    // Password incorrecto
                    if (usuario.Password != passMD5)
                    {
                        if (usuario.IntentosErroneos == null)
                        {
                            usuario.IntentosErroneos = 0;
                        }
                        usuario.IntentosErroneos++;
                        _context.Entry(usuario).State = EntityState.Modified;
                        await _context.SaveChangesAsync();

                        await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Acceso_Password_Incorrecto, null, null);

                        return Unauthorized();
                    }
                    else
                    {
                        if ((usuario.SuperAdministrador == false || usuario.SuperAdministrador == null) &&
                            (usuario.Distribuidor == false || usuario.Distribuidor == null)) {

                            var ultimoRastro = await _context.Rastro.Where(r => r.Usuarios_Id == usuario.Id).OrderByDescending(r => r.FechaAccion).FirstOrDefaultAsync();
               
                            if (ultimoRastro == null || ultimoRastro.Operacion == "Cerrar_sesion")
                            {
                                usuario.IntentosErroneos = 0;
                                _context.Entry(usuario).State = EntityState.Modified;
                                await _context.SaveChangesAsync();
                                await _gestorRastro.AddRastro(usuario.Email, usuario.Empresas_Id, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Iniciar_sesion, null, null);
                            }
                            else
                            {
                                Empresas empresa = await _context.Empresas.Where(r => r.Id == usuario.Empresas_Id).FirstOrDefaultAsync();
                                var tiempoTranscurrido = DateTime.Now - ultimoRastro.FechaAccion;
                                //if (tiempoTranscurrido.Value.TotalMinutes > 0.1)
                                if (tiempoTranscurrido.Value.TotalMinutes > (empresa.TiempoEspera / 60))
                                {
                                    var infoLogout = new InfoLogout()
                                    {
                                        UserName = usuario.Email,
                                        Tipo = "F"
                                    };
                                    await this.Logout(infoLogout);
                                    usuario.IntentosErroneos = 0;
                                    _context.Entry(usuario).State = EntityState.Modified;
                                    await _context.SaveChangesAsync();
                                    await _gestorRastro.AddRastro(usuario.Email, usuario.Empresas_Id, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Iniciar_sesion, null, null);
                                }
                                else
                                {
                                    return Conflict("Otro equipo tiene la sesión iniciada con el usuario '" + usuario.Email + "'. ¿Deseas cerrar la sesión activa e iniciarla en este equipo?");
                                }
                            }
                        }
                        else
                        {
                            using (var client = new HttpClient())
                            {
                                var secretKey = _configuration.GetSection("SecretCaptchaApinetics").Value;
                                var response = await client.PostAsync($"https://www.google.com/recaptcha/api/siteverify?secret={secretKey}&response={user.reCaptchaToken}", null);

                                if (response.IsSuccessStatusCode)
                                {
                                    var resultString = await response.Content.ReadAsStringAsync();
                                    var result = Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(resultString);
                                    usuario.IntentosErroneos = 0;

                                    _context.Entry(usuario).State = EntityState.Modified;
                                    await _context.SaveChangesAsync();
                                    await _gestorRastro.AddRastro(usuario.Email, null, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Iniciar_sesion, null, null);
                                }
                                else
                                {
                                    return Conflict("Captcha error");
                                }
                            }
                        }
                    }
                }
            }

            var token = await GenerateToken(usuario, false);
            return Ok(token);
        }

        [HttpPost, Route("refreshtoken")]
        public async Task<ActionResult> RefreshToken([FromBody] RefreshTokenModel token)
        {
            var usuario = await (from x in _context.Usuarios
                                 where x.RefreshToken == token.Token
                                 select x).SingleOrDefaultAsync();

            if (usuario != null)
            {
                return Ok(await GenerateToken(usuario, true));
            }
            else
            {
                return Unauthorized();
            }
        }

        private async Task<TokenModel> GenerateToken(Usuarios usuario, bool refresh)
        {

            var idEmpresa = await (from x in _context.Usuarios
                                   where x.Email == usuario.Email
                                   select x.Empresas_Id).SingleOrDefaultAsync();


            var superAdmin = await (from x in _context.Usuarios
                                    where x.Email == usuario.Email
                                    select x.SuperAdministrador).SingleOrDefaultAsync();

            var distribuidor = await (from x in _context.Usuarios
                                      where x.Email == usuario.Email
                                      select x.Distribuidor).SingleOrDefaultAsync();


            var secret = _configuration.GetSection("AnSecret").Value;
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

            var tokenOptions = new JwtSecurityToken(
                issuer: "http://pruebasissuer.com",
                audience: "http://pruebasaudience.com",
                claims: new List<Claim>{
                        new Claim(ClaimTypes.Name, usuario.Email),
                        new Claim(ClaimTypes.SerialNumber, idEmpresa.ToString()),
                        new Claim(ClaimTypes.Role, superAdmin.ToString()),
                        new Claim(ClaimTypes.Actor, distribuidor.ToString()),
                        new Claim(ClaimTypes.Anonymous, superAdmin==true||distribuidor==true?"true":"false")
                },
                expires: refresh ? DateTime.Now.AddDays(30) : DateTime.Now.AddMinutes(5),
                signingCredentials: signinCredentials
            );
            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);

            var refreshOptions = new JwtSecurityToken(
                claims: new List<Claim>{
                        new Claim(ClaimTypes.Name, usuario.Email),
                        new Claim(ClaimTypes.Hash, Guid.NewGuid().ToString()),
                },
                signingCredentials: signinCredentials
            );
            var refreshString = new JwtSecurityTokenHandler().WriteToken(refreshOptions);

            usuario.RefreshToken = refreshString;
            await _context.SaveChangesAsync();

            return new TokenModel()
            {
                UserName = usuario.Email,
                Token = tokenString,
                RefreshToken = refreshString
            };
        }


        [Authorize]
        [HttpPut("changepassword/notoldpass")]
        public async Task<IActionResult> UpdatePassNotOldpass([FromBody] InfoChangePassword info)
        {
            var user = await _context.Usuarios.Where(a => a.Email == info.EmailLogin).FirstAsync();
            var secretPass = _configuration.GetSection("AnSecretPass").Value;
            if (user != null)
            {
                //contraseña nueva
                byte[] xNew = Convert.FromBase64String(info.NewPass);
                string newPass = Encoding.UTF8.GetString(xNew, 0, xNew.Length);
                string newPassMD5 = _passwords.Encrypt(newPass, secretPass);

                user.Password = newPassMD5;
                _context.Entry(user).State = EntityState.Modified;

                await _context.SaveChangesAsync();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.Usuarios, EnumTipoAccionRastro.Cambiar_password, info.EmailLogin, null);

            return Ok();
        }


        [Authorize]
        [HttpPut("changepassword")]
        public async Task<IActionResult> UpdatePass([FromBody] InfoChangePassword info)
        {
            var usuario = await _context.Usuarios.Where(a => a.Email == info.EmailLogin).FirstAsync();

            //contraseña actual
            byte[] x = Convert.FromBase64String(info.OldPass);
            string oldPass = Encoding.UTF8.GetString(x, 0, x.Length);
            var secretPass = _configuration.GetSection("AnSecretPass").Value;
            string oldPassMD5 = _passwords.Encrypt(oldPass, secretPass);

            if (oldPassMD5 == usuario.Password)
            {
                //contraseña nueva
                byte[] xNew = Convert.FromBase64String(info.NewPass);
                string newPass = Encoding.UTF8.GetString(xNew, 0, xNew.Length);
                string newPassMD5 = _passwords.Encrypt(newPass, secretPass);

                usuario.Password = newPassMD5;
                _context.Entry(usuario).State = EntityState.Modified;

                _context.Entry(usuario).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Cambiar_password, info.EmailLogin, null);

                return Ok();
            }
            else
            {
                return Conflict("Contraseña actual incorrecta");
            }
        }

        [HttpPost("cerrarSesionUsuario")]
        public async Task<IActionResult> CerrarSesionUsuario([FromQuery] string email)
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == email).FirstOrDefaultAsync();

            if (usuario != null)
            {
                Rastro rastro = new Rastro
                {
                    FechaAccion = DateTime.Now,
                    Observaciones = "Cierre de sesión forzada por el usuario.",
                    Proceso = "Acceso",
                    Operacion = "Cerrar_sesion",
                    Usuarios_Id = usuario.Id,
                    Ip = _accessor.HttpContext.Connection.RemoteIpAddress.ToString(),
                    Empresas_Id = usuario.Empresas_Id,
                    TipoLogout = "F"
                };
                await _context.Rastro.AddAsync(rastro);
                await _context.SaveChangesAsync();
            }

            return Ok();
        }

        [HttpPost("cerrarSesionUsuarioById/{idUsuario}")]
        public async Task<IActionResult> CerrarSesionUsuario([FromRoute] Guid idUsuario)
        {
            var usuarioActual = User.Identity.Name;
            var usuario = await _context.Usuarios.FindAsync(idUsuario);

            if (usuario != null)
            {
                Rastro rastro = new Rastro
                {
                    FechaAccion = DateTime.Now,
                    Observaciones = "Cierre de sesión forzada por el Super Administrador.",
                    Proceso = "Acceso",
                    Operacion = "Cerrar_sesion",
                    Usuarios_Id = idUsuario,
                    Ip = _accessor.HttpContext.Connection.RemoteIpAddress.ToString(),
                    Empresas_Id = usuario.Empresas_Id,
                    TipoLogout = "F"
                };
                await _context.Rastro.AddAsync(rastro);
                await _context.SaveChangesAsync();
            }

            return Ok();
        }

        [Authorize]
        [HttpPost("logout")]
        public async Task<ActionResult> Logout([FromBody]InfoLogout user)
        {
            await _gestorRastro.AddRastro(user.UserName, null, EnumTipoProcesoRastro.Acceso, EnumTipoAccionRastro.Cerrar_sesion, null, user.Tipo);
            return Ok();
        }

        [Authorize]
        [HttpGet("obtenerTiempoByEmail")]
        public async Task<IActionResult> ObtenerTiempoEsperaEmpresa([FromBody] string email)
        {
            var usuario = await _context.Usuarios.Where(u => u.Email == email).FirstOrDefaultAsync();

            var empresa = await _context.Empresas.Where(e => usuario.Empresas_Id == e.Id).FirstOrDefaultAsync();

            var tiempo = await (from x in _context.Empresas
                                where x.Id == empresa.Id
                                select x.TiempoEspera).SingleOrDefaultAsync();

            return Ok(tiempo);
        }
    }
}