﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;

namespace WebAPIMaster.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParametrosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public ParametrosController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Parametros
        [HttpGet("{Empresas_Id}")]
        public async Task<IActionResult> GetParametrosByIdEmpresa([FromRoute] Guid Empresas_Id)
        {
            var parametros = await (from x in _context.Parametros
                                           where x.Id == Empresas_Id
                                            select new Parametros
                                            {
                                               Id = x.Id,
                                               IdAccesoBi = x.IdAccesoBi,
                                               SuperUsuario = x.SuperUsuario
                                            }).FirstOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, Empresas_Id, EnumTipoProcesoRastro.Parametros, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(parametros);
        }

        // GET: api/Parametros/RRSS
        [HttpGet("RRSS")]
        public async Task<IActionResult> GetParametrosRRSS()
        {
            var parametros = await (from x in _context.ParametrosRRSS
                                     select x).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.ParametrosRRSS, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(parametros);
        }

        // PUT: api/Parametros
        [HttpPut]
        public async Task<IActionResult> PutParametros([FromBody] ParametrosRRSS parametros)
        {
            var parametrosEdit = await _context.ParametrosRRSS.FindAsync(parametros.Id);

            if (parametrosEdit != null)
            {
                /*parametrosEdit.NumImgPermitidasTwitter = parametros.NumImgPermitidasTwitter;
                parametrosEdit.MaxImgSizeTwitter = parametros.MaxImgSizeTwitter;
                parametrosEdit.FormatoImgTwitter = parametros.FormatoImgTwitter;
                parametrosEdit.MaxGifSizeTwitter = parametros.MaxGifSizeTwitter;
                parametrosEdit.MaxVideoSizeTwitter = parametros.MaxVideoSizeTwitter;
                parametrosEdit.MaxDuracionVideoTwitter = parametros.MaxDuracionVideoTwitter;
                parametrosEdit.NumImgPermitidasInstagram = parametros.NumImgPermitidasInstagram;          
                parametrosEdit.MaxDimensionesImagenInstagram = parametros.MaxDimensionesImagenInstagram;
                parametrosEdit.MaxDimensionesVideoInsta = parametros.MaxDimensionesVideoInsta;
                parametrosEdit.MaxDuracionVideoInsta = parametros.MaxDuracionVideoInsta;
                parametrosEdit.MinDuracionVideoInsta = parametros.MinDuracionVideoInsta;
                parametrosEdit.NumImgPermitidasLinkedin = parametros.NumImgPermitidasLinkedin;
                parametrosEdit.FormatoVideoLinkedin = parametros.FormatoVideoLinkedin;
                parametrosEdit.MaxSizeVideoLinkedin = parametros.MaxSizeVideoLinkedin;
                parametrosEdit.MinSizeVideoLinkedin = parametros.MinSizeVideoLinkedin;
                parametrosEdit.MinDuracionVideoLinkedin = parametros.MinDuracionVideoLinkedin;
                parametrosEdit.MaxDuracionVideoLinkedin = parametros.MaxDuracionVideoLinkedin;
                parametrosEdit.NumImgPermitidasFacebook = parametros.NumImgPermitidasFacebook;
                parametrosEdit.NumImgPermitidasPinterest = parametros.NumImgPermitidasPinterest;
                parametrosEdit.NumImgPermitidasTiktok = parametros.NumImgPermitidasTiktok;
                parametrosEdit.MinDimensionesImagenInsta = parametros.MinDimensionesImagenInsta;
                parametrosEdit.MinDimensionesVideoInsta = parametros.MinDimensionesVideoInsta;*/
                parametrosEdit.TodasValidacionesX = parametros.TodasValidacionesX;
                parametrosEdit.TodasValidacionesInstagram = parametros.TodasValidacionesInstagram;
                parametrosEdit.TodasValidacionesLinkedin = parametros.TodasValidacionesLinkedin;
                parametrosEdit.TodasValidacionesFacebook = parametros.TodasValidacionesFacebook;
                parametrosEdit.TodasValidacionesPinterest = parametros.TodasValidacionesPinterest;
                parametrosEdit.TodasValidacionesTiktok = parametros.TodasValidacionesTiktok;

                _context.Entry(parametrosEdit).State = EntityState.Modified;
            }
            else
            {
                throw new Exception("Estos parametros ya no existen");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.ParametrosRRSS, EnumTipoAccionRastro.Modificar, null, null);

            return Ok();
        }
    }
}
