﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PermisosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public PermisosController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }


        // GET: api/Permisos
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetPermisosByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var empresa = await _context.Empresas.FindAsync(idEmpresa);
            var usuario = await (from x in _context.Usuarios
                              where x.Email == User.Identity.Name
                              select x).FirstOrDefaultAsync();
            var rol = await _context.Roles.Where(x => x.Id == usuario.Roles_Id).FirstOrDefaultAsync();

            if (empresa == null || usuario == null)
            {
                return NotFound();
            }

            var permisos = new List<Permisos>();

            if (usuario.SuperAdministrador == false && empresa.OpcionBotones == "O")
            {
                permisos = await (from x in _context.Permisos
                                  join r in _context.Roles on x.Roles_Id equals r.Id
                                  where x.Empresas_Id == idEmpresa
                                  && x.Modificable == true
                                  && r.Nivel > rol.Nivel
                                  && (x.Procesos.Descripcion != "Ayuda"
                                  || x.Procesos.Descripcion != "Parámetros de Redes Sociales")

                                  select new Permisos
                                  {
                                      Id = x.Id,
                                      Empresas_Id = x.Empresas_Id,
                                      Procesos_Id = x.Procesos_Id,
                                      Roles_Id = x.Roles_Id,
                                      Visible = x.Visible,
                                      Modificable = x.Modificable
                                  }).ToListAsync();
            }
            else
            {
                if (usuario.SuperAdministrador == false)
                {
                    permisos = await (from x in _context.Permisos
                                      join r in _context.Roles on x.Roles_Id equals r.Id
                                      where x.Empresas_Id == idEmpresa
                                      && r.Nivel > rol.Nivel
                                      && (x.Procesos.Descripcion != "Ayuda"
                                      || x.Procesos.Descripcion != "Parámetros de Redes Sociales")
                                      select new Permisos
                                      {
                                          Id = x.Id,
                                          Empresas_Id = x.Empresas_Id,
                                          Procesos_Id = x.Procesos_Id,
                                          Roles_Id = x.Roles_Id,
                                          Visible = x.Visible,
                                          Modificable = x.Modificable
                                      }).ToListAsync();
                }
                else
                {
                    permisos = await (from x in _context.Permisos
                                      join r in _context.Roles on x.Roles_Id equals r.Id
                                      where x.Empresas_Id == idEmpresa
                                      && (x.Procesos.Descripcion != "Ayuda"
                                      || x.Procesos.Descripcion != "Parámetros de Redes Sociales")
                                      select new Permisos
                                      {
                                          Id = x.Id,
                                          Empresas_Id = x.Empresas_Id,
                                          Procesos_Id = x.Procesos_Id,
                                          Roles_Id = x.Roles_Id,
                                          Visible = x.Visible,
                                          Modificable = x.Modificable
                                      }).ToListAsync();
                }
            }

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Permisos, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(permisos);
        }


        // PUT: api/Permisos
        [HttpPut]
        public async Task<IActionResult> PutPermisos([FromBody] DTOPermisos[] permisos)
        {
            if (permisos.Length > 0)
            {
                var permisosEliminar = await (from x in _context.Permisos
                                              where x.Empresas_Id == permisos[0].Empresas_Id
                                              select x).ToListAsync();

                _context.Permisos.RemoveRange(permisosEliminar);

                foreach (var p in permisos)
                {
                    // CAMBIAR si es necesario
                    var nuevoPermisos = await _context.Permisos.FindAsync(p.Id);

                    if (nuevoPermisos != null)
                    {
                        nuevoPermisos.Empresas_Id = p.Empresas_Id;
                        nuevoPermisos.Procesos_Id = p.Procesos_Id;
                        nuevoPermisos.Roles_Id = p.Roles_Id;
                        nuevoPermisos.Visible = p.Visible;
                        nuevoPermisos.Modificable = p.Modificable;

                        _context.Entry(nuevoPermisos).State = EntityState.Modified;
                    }
                    else
                    {
                        nuevoPermisos = new Permisos
                        {
                            Empresas_Id = p.Empresas_Id,
                            Procesos_Id = p.Procesos_Id,
                            Roles_Id = p.Roles_Id,
                            Visible = p.Visible,
                            Modificable = p.Modificable
                        };

                        await _context.Permisos.AddAsync(nuevoPermisos);
                    }
                }

                await _context.SaveChangesAsync();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, permisos[0].Empresas_Id, EnumTipoProcesoRastro.Permisos, EnumTipoAccionRastro.Modificar, null, null);

            return Ok();
        }
    }
}