﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProvinciasController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public ProvinciasController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Provincias
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetProvinciasCombo([FromRoute] Guid idEmpresa)
        {
            var provincias = await (from x in _context.Provincias
                                     where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                     orderby x.Nombre
                                     select new DTODataComboMC
                                     {
                                         Value = x.Id,
                                         Label = x.Nombre
                                     }).ToListAsync();

            return Ok(provincias);
        }

        // GET: api/Provincias
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetProvinciasByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var provincias = await (from x in _context.Provincias
                                    where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                     orderby x.Empresas_Id != null descending, x.Nombre
                                     select new DTOProvincias
                                     {
                                         Id = x.Id,
                                         Codigo = x.Codigo,
                                         Nombre = x.Nombre,
                                         Autonomia = x.Autonomia,
                                         Paises_Id = x.Paises_Id,
                                         Empresas_Id = x.Empresas_Id,
                                         NombrePais = x.Paises.Nombre
                                     }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Provincias, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(provincias);
        }

        // PUT: api/Provincias
        [HttpPut]
        public async Task<IActionResult> PutProvincias([FromBody] DTOProvincias provincia)
        {
            if (provincia.Nombre != null && provincia.Nombre.Trim() != "")
            {
                var provinciaExiste = await _context.Provincias.AnyAsync(x => x.Nombre == provincia.Nombre && x.Id != provincia.Id && x.Empresas_Id == provincia.Empresas_Id);
                if (provinciaExiste)
                {
                    return Conflict("Una provincia con este nombre está registrada para esta empresa");
                }
            }

            if (provincia.Nombre != null && provincia.Nombre.Trim() != "")
            {
                var provinciaExiste2 = await _context.Provincias.AnyAsync(x => x.Nombre == provincia.Nombre && x.Id != provincia.Id && x.Empresas_Id == null);
                if (provinciaExiste2)
                {
                    return Conflict("Una provincia con este nombre está registrada como genérica");
                }
            }

            var provinciaEdit = await _context.Provincias.FindAsync(provincia.Id);

            if (provinciaEdit != null)
            {
                provinciaEdit.Nombre = provincia.Nombre;
                provinciaEdit.Codigo = provincia.Codigo;
                provinciaEdit.Autonomia = provincia.Autonomia;
                provinciaEdit.Paises_Id = provincia.Paises_Id;
                provinciaEdit.UsuarioModificacion = User.Identity.Name;
                provinciaEdit.FechaModificacion = DateTime.Now;
                _context.Entry(provinciaEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Esta provincia ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, provinciaEdit.Empresas_Id, EnumTipoProcesoRastro.Provincias, EnumTipoAccionRastro.Modificar, provinciaEdit.Nombre, null);

            return Ok();
        }

        // POST: api/Provincias
        [HttpPost]
        public async Task<IActionResult> PostProvincias([FromBody] DTOProvincias provincia)
        {
            if (provincia.Nombre != null && provincia.Nombre.Trim() != "")
            {
                var provinciaExiste = await _context.Provincias.AnyAsync(x => x.Nombre.ToUpper() == provincia.Nombre.ToUpper() && x.Empresas_Id == provincia.Empresas_Id);
                if (provinciaExiste)
                {
                    return Conflict("Una provincia con este nombre ya está registrada para esta empresa");
                }
            }

            if (provincia.Nombre != null && provincia.Nombre.Trim() != "")
            {
                var provinciaExiste2 = await _context.Provincias.AnyAsync(x => x.Nombre == provincia.Nombre && x.Empresas_Id == null);
                if (provinciaExiste2)
                {
                    return Conflict("Una provincia con este nombre ya está registrada como genérica");
                }
            }

            Provincias nuevaProvincia = new Provincias
            {
                Nombre = provincia.Nombre,
                Codigo = provincia.Codigo,
                Autonomia = provincia.Autonomia,
                Paises_Id = provincia.Paises_Id,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now,
                Empresas_Id = provincia.Empresas_Id,
            };

            await _context.Provincias.AddAsync(nuevaProvincia);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, provincia.Empresas_Id, EnumTipoProcesoRastro.Provincias, EnumTipoAccionRastro.Modificar, provincia.Nombre, null);

            return Ok(nuevaProvincia);
        }

        // DELETE: api/Provincias
        [HttpDelete("{idProvincia}")]
        public async Task<IActionResult> DeleteProvincia([FromRoute] Guid idProvincia)
        {
            var entidades = await _context.Entidades.AnyAsync(x => x.Provincias_Id == idProvincia);
            if (entidades)
            {
                return Conflict("Esta provincia está asignada a alguna entidad. No se puede eliminar");
            }

            var contactos = await _context.Contactos.AnyAsync(x => x.Provincias_Id == idProvincia);
            if (contactos)
            {
                return Conflict("Esta provincia esta asignada a algún contacto de entidad. No se puede eliminar");
            }

            var localidades = await _context.Localidades.AnyAsync(x => x.Provincias_Id == idProvincia);
            if (localidades)
            {
                return Conflict("Esta provincia esta asignada a alguna localidad. No se puede eliminar");
            }

            var provincia = await _context.Provincias.FindAsync(idProvincia);
            if (provincia == null)
            {
                return NotFound();
            }

            _context.Provincias.Remove(provincia);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, provincia.Empresas_Id, EnumTipoProcesoRastro.Provincias, EnumTipoAccionRastro.Eliminar, provincia.Nombre, null);

            return Ok(provincia);
        }
    }
}

