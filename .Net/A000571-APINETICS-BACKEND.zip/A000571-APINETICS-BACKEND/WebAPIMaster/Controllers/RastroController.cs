﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RastroController : ControllerBase
    {
        private readonly ApineticsContext _context;

        public RastroController(ApineticsContext context)
        {
            _context = context;
        }
        
        // GET: api/Rastro
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetRastroByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var infor = await (from x in _context.Usuarios
                                where x.Email==User.Identity.Name
                                select x).SingleOrDefaultAsync();


            if(infor.SuperAdministrador==true)
            {
                var rastro = await (from x in _context.Rastro
                                    where x.Empresas_Id == idEmpresa || x.Empresas_Id == null 
                                    orderby x.FechaAccion descending
                                    select new DTORastro
                                    {
                                        Id = x.Id,
                                        FechaAccion = x.FechaAccion,
                                        Observaciones = x.Observaciones,
                                        Proceso = x.Proceso,
                                        Operacion = x.Operacion,
                                        Ip = x.Ip,
                                        NombreUsuario = x.Usuarios.Email
                                    }).ToListAsync();


                return Ok(rastro);

            }
            else
            {
                var rastro = await (from x in _context.Rastro
                                    where x.Empresas_Id == idEmpresa 
                                    orderby x.FechaAccion descending
                                    select new DTORastro
                                    {
                                        Id = x.Id,
                                        FechaAccion = x.FechaAccion,
                                        Observaciones = x.Observaciones,
                                        Proceso = x.Proceso,
                                        Operacion = x.Operacion,
                                        Ip = x.Ip,
                                        NombreUsuario = x.Usuarios.Email
                                    }).ToListAsync();

                return Ok(rastro);
            }
        }
    }
}