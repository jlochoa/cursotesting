﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.DataModels;
using System.Collections.Generic;
using System.Diagnostics;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProcesosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        public class IProcesos
        {
            public string Orden { get; set; }
            public string Descripcion { get; set; }
            public Guid IdProceso { get; set; }
        }

        public ProcesosController(ApineticsContext context)
        {
            _context = context;
        }

        // GET: api/Procesos
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetProcesos(Guid idEmpresa)
        {
            var empresa = await _context.Empresas.FindAsync(idEmpresa);
            var usuario = await (from x in _context.Usuarios
                                 where x.Email == User.Identity.Name
                                 select x).FirstOrDefaultAsync();

            if (empresa == null || usuario == null)
            {
                return NotFound();
            }

            var procesos = new List<IProcesos>();

            if (usuario.SuperAdministrador == false)
            {
                var rol = usuario.Roles_Id;

                var permisos = await (from x in _context.Permisos
                                      where x.Roles_Id == rol &&
                                      x.Empresas_Id == idEmpresa &&
                                      (x.Visible == true || x.Modificable == true)
                                      select x.Procesos_Id).ToListAsync();

                procesos = await (from x in _context.Procesos
                                  where permisos.Contains(x.Id)
                                  orderby x.Orden
                                  select new IProcesos
                                  {
                                      Orden = x.Orden,
                                      Descripcion = x.Descripcion,
                                      IdProceso = x.Id
                                  }).ToListAsync();
            }
            else
            {
                procesos = await (from x in _context.Procesos
                                  orderby x.Orden
                                  select new IProcesos
                                  {
                                      Orden = x.Orden,
                                      Descripcion = x.Descripcion,
                                      IdProceso = x.Id
                                  }).ToListAsync();
            }

            return Ok(procesos);
        }
        // GET: api/Procesos
        //[HttpGet]
        //public async Task<IActionResult> GetProcesos()
        //{
        //    var procesos = await (from x in _context.Procesos
        //                          orderby x.Orden
        //                          select new Procesos
        //                          {
        //                              Orden = x.Orden,
        //                              Descripcion = x.Descripcion,
        //                              Id = x.Id
        //                          }).ToListAsync();

        //    return Ok(procesos);
        //}
    }
}