﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CompetidoresController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;
        private readonly IConfiguration _configuration;

        public CompetidoresController(ApineticsContext context, IConfiguration configuration, IGestorRastro gestorRastro)
        {
            _context = context;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
        }

        public class Compet
        {
            public int id { get; set; }
        }



        // GET: api/Competidores
        [HttpGet("{idDominio}")]
        public async Task<IActionResult> GetCompetidoresByIdDominio([FromRoute] Guid idDominio)
        {

            var competidores = await (from x in _context.Competidores
                                       where x.Dominios_Id == idDominio
                                       select new Competidores
                                       {
                                           Id = x.Id,
                                           Dominios_Id = x.Dominios_Id,
                                           Descripcion = x.Descripcion,
                                           IdCompetidorSeRanking = x.IdCompetidorSeRanking
                                       }).ToListAsync();

            var idEmpresa = await (from x in _context.Dominios
                                   where x.Id == idDominio
                                   select x.Empresas_Id).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Competidores, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(competidores);
        }

        // PUT: api/Competidores
        [HttpPut]
        public async Task<IActionResult> PutCompetidores([FromBody] DTOCompPalabrasClave competidor)
        {
            var competidorEdit = await _context.Competidores.FindAsync(competidor.Id);

            if (competidorEdit != null)
            {
                competidorEdit.Dominios_Id = (Guid)competidor.Dominios_Id;
                competidorEdit.Descripcion = competidor.Descripcion;
                competidorEdit.IdCompetidorSeRanking = competidor.IdSeRanking;
                competidorEdit.UsuarioModificacion = User.Identity.Name;
                competidorEdit.FechaModificacion = DateTime.Now;

                _context.Entry(competidorEdit).State = EntityState.Modified;
            }
            else
            {
                throw new Exception("Este competidor ya no existe");
            }

            await _context.SaveChangesAsync();

            var idEmpresa = await (from x in _context.Dominios
                                   where x.Id == competidor.Dominios_Id
                                   select x.Empresas_Id).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Competidores, EnumTipoAccionRastro.Modificar, competidor.Descripcion, null);

            return Ok();
        }

        // POST: api/Competidores
        [HttpPost]
        public async Task<IActionResult> PostCompetidores([FromBody] DTOCompPalabrasClave competidor)
        {

            var IdSeRanking = await (from x in _context.Dominios
                                    where x.Id == competidor.Dominios_Id
                                    select x.IdSeRanking).SingleOrDefaultAsync();

            using var transaction = _context.Database.BeginTransaction();
            try
            {
                Competidores nuevo = new Competidores
                {
                    Dominios_Id = (Guid)competidor.Dominios_Id,
                    Descripcion = competidor.Descripcion,
                    IdCompetidorSeRanking = competidor.IdSeRanking,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now
                };

                await _context.Competidores.AddAsync(nuevo);

                await _context.SaveChangesAsync();

                //lo hacemos tambien en SE Ranking
                if (IdSeRanking != null && IdSeRanking != 0)
                {
                    var infor = new
                    {
                        site_id = IdSeRanking,
                        url = competidor.Descripcion
                    };

                    var json = Newtonsoft.Json.JsonConvert.SerializeObject(infor);
                    var data = new System.Net.Http.StringContent(json, Encoding.UTF8, "application/json");

                    var url = "https://api4.seranking.com/competitors";
                    using var client = new HttpClient();
                    var token = _configuration.GetSection("AppSettings:TokenSeRanking").Value;

                    client.DefaultRequestHeaders.Add("Authorization", "Token " + token);

                    var response = await client.PostAsync(url, data);

                    string result = response.Content.ReadAsStringAsync().Result;

                    Compet aa = JsonSerializer.Deserialize<Compet>(result);
                    nuevo.IdCompetidorSeRanking = aa.id;
                }

                _context.Entry(nuevo).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                var idEmpresa = await (from x in _context.Dominios
                                       where x.Id == competidor.Dominios_Id
                                       select x.Empresas_Id).SingleOrDefaultAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Competidores, EnumTipoAccionRastro.Agregar, competidor.Descripcion, null);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }

        // DELETE: api/Competidor
        [HttpDelete("{idCompetidor}")]
        public async Task<IActionResult> DeletePalabraClave([FromRoute] Guid idCompetidor)
        {
            var competidor = await _context.Competidores.FindAsync(idCompetidor);
            if (competidor == null)
            {
                return NotFound();
            }

            _context.Competidores.Remove(competidor);
            await _context.SaveChangesAsync();

            if (competidor.IdCompetidorSeRanking != null && competidor.IdCompetidorSeRanking != 0)
            {
                var url = "https://api4.seranking.com/competitors/" + competidor.IdCompetidorSeRanking;
                using var client = new HttpClient();
                var token = _configuration.GetSection("AppSettings:TokenSeRanking").Value;

                client.DefaultRequestHeaders.Add("Authorization", "Token "+token);

                var response = await client.DeleteAsync(url);

                string result = response.Content.ReadAsStringAsync().Result;
            }

            var idEmpresa = await (from x in _context.Dominios
                                   where x.Id == competidor.Dominios_Id
                                   select x.Empresas_Id).SingleOrDefaultAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Competidores, EnumTipoAccionRastro.Eliminar, competidor.Descripcion, null);

            return Ok();
        }
    }
}
