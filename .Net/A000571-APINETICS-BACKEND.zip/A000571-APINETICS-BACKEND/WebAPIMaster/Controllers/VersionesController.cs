﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class VersionesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public VersionesController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Persona
        [HttpGet("combo")]
        public async Task<IActionResult> GetVersionesCombo()
        {
            List<DTODataCombo> Versiones;

            Versiones = await (from x in _context.Versiones
                               orderby x.Version
                               select new DTODataCombo
                               {
                                   Value = x.Id,
                                   Label = x.Version
                               }).ToListAsync();

            return Ok(Versiones);
        }

        // GET: api/Version
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetVersion(Guid idEmpresa)
        {
            var Version = await (from x in _context.Versiones
                                orderby x.Fecha descending 
                                select new DTOVersiones
                                {
                                    Id = x.Id,
                                    Version = x.Version,
                                    Fecha = x.Fecha.ToString("dd/MM/yyyy"),
                                    Notas = x.Notas,
                                }).FirstOrDefaultAsync();

            if (Version == null)
            {
                return NotFound();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Versiones, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(Version);
        }

        [HttpPost]
        public async Task<IActionResult> PostVersion([FromBody] DTOVersiones version)
        {
            if (version == null)
            {
                return BadRequest();
            }

            Versiones nuevaVersion = new Versiones
            {
                Version = version.Version,
                Fecha = DateTime.Now,
                Notas = version.Notas
            };

            await _context.Versiones.AddAsync(nuevaVersion);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }
}

