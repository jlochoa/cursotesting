﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.DataModelsBI;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class BIReportController : ControllerBase
    {
        // Cuenta anterior
        // private static readonly string 
        // Username = "iguelbenzu@cesinsl.onmicrosoft.com";
        // private static readonly string Password = "Fntm201901";
        //private static readonly string Username = "m.sunsundegui@cimacesin.onmicrosoft.com";
        //private static readonly string Password = "[9l%fDbKw\"{\"OJ3";


        //private static readonly string Username = "ignacioj@cimacesin.onmicrosoft.com";
        //private static readonly string Password = "v}:Rv_[\"-:*FH8y";


        private static readonly string ApplicationSecret = "qh6IoQShrt3qzoOCKagsJmmD5f4bpRb6Q4u5Zqydcis=";
        private static readonly string AuthorityUrl = "https://login.microsoftonline.com/common/";
        private static readonly string ResourceUrl = "https://analysis.windows.net/powerbi/api";
        // private static readonly string ApplicationId = "5ce96fd1-1543-492c-9d34-106cd2d79c22";
        private static readonly string ApplicationId = "57302134-47bb-4f49-baad-96930c918712";
        private static readonly string ApiUrl = "https://api.powerbi.com";
        private static readonly string WorkspaceId = "1812f788-30ff-4ff3-a36c-c0c7f3806fb1";
        // private static readonly string ReportId = "e5350ec5-78f1-471b-bd76-a926379c33d3";
        private static readonly string TenantAzure = "75897b5c-0a4f-4121-ac96-f5131fb761b5";
        // private static readonly string TenantAzure = "83e564f6-3c0b-42a6-996c-8db1b6972a33";

        private readonly ApineticsContext _context;
        private readonly EvolucionaContext _contextEvoluciona;
        private readonly IGestorRastro _gestorRastro;
        private readonly IHttpContextAccessor _accessor;
        private readonly IConfiguration _configuration;
        private readonly IPasswords _passwords;

        public BIReportController(ApineticsContext context, EvolucionaContext contextEvoluciona, IConfiguration configuration, IHttpContextAccessor accesor, IGestorRastro gestorRastro, IPasswords passwords)
        {
            _context = context;
            _contextEvoluciona = contextEvoluciona;
            _accessor = accesor;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
            _passwords = passwords;
        }

        // GET: api/BIReport
        [HttpGet("{informe}")]
        public async Task<ActionResult> GetAccessToken([FromRoute] string informe)
        {

            var token = await EmbedReport(_contextEvoluciona, _passwords, _configuration);

            if (token == "")
            {
                return Unauthorized();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.Informe_BI, EnumTipoAccionRastro.Actualizar, informe, null);
            return Ok(new { token = token });
        }

        // GET: api/obtenerDatosBI
        [HttpGet("obtenerDatosBI")]
        public async Task<ActionResult> GetDatosInformes()
        {
            var idInforme = new Guid("73A6E115-4AE2-4CFA-AD37-934F49E1F9B0");

            var informacion = (from x in _contextEvoluciona.Informes
                               where x.Id == idInforme
                               select x).FirstOrDefault();


            return Ok(informacion);
        }

        public async Task<string> EmbedReport(EvolucionaContext contextEvoluciona, IPasswords passwords, IConfiguration configuration)
        {
            try
            {
                var error = GetWebConfigErrors(contextEvoluciona);
                if (error != null)
                {
                    return null;
                }

                var authenticationResult = await AuthenticateAsync(contextEvoluciona, passwords, configuration);

                if (authenticationResult == null)
                {
                    return null;
                }

                return authenticationResult.AccessToken;
            }
            catch (Exception exc)
            {
                return exc.ToString();
            }

        }

        private string GetWebConfigErrors(EvolucionaContext contextEvoluciona)
        {
            var accesobi = contextEvoluciona.AccesoBI.First();

            string Password = _passwords.Decrypt(accesobi.Password, _configuration.GetSection("EvolucionaEncryptPasswordCuenta").Value);

            string Username = accesobi.Usuario;


            // Application Id must have a value.
            if (string.IsNullOrWhiteSpace(ApplicationId))
            {
                return "ApplicationId is empty. please register your application as Native app in https://dev.powerbi.com/apps and fill client Id in web.config.";
            }

            // Application Id must be a Guid object.
            Guid result;
            if (!Guid.TryParse(ApplicationId, out result))
            {
                return "ApplicationId must be a Guid object. please register your application as Native app in https://dev.powerbi.com/apps and fill application Id in web.config.";
            }

            // Workspace Id must have a value.
            if (string.IsNullOrWhiteSpace(WorkspaceId))
            {
                return "WorkspaceId is empty. Please select a group you own and fill its Id in web.config";
            }

            // Workspace Id must be a Guid object.
            if (!Guid.TryParse(WorkspaceId, out result))
            {
                return "WorkspaceId must be a Guid object. Please select a workspace you own and fill its Id in web.config";
            }

            // Username must have a value.
            if (string.IsNullOrWhiteSpace(Username))
            {
                return "Username is empty. Please fill Power BI username in web.config";
            }

            // Password must have a value.
            if (string.IsNullOrWhiteSpace(Password))
            {
                return "Password is empty. Please fill password of Power BI username in web.config";
            }

            return null;
        }

        private static async Task<OAuthResult> AuthenticateAsync(EvolucionaContext contextEvoluciona, IPasswords passwords, IConfiguration configuration)
        {
            var accesobi = contextEvoluciona.AccesoBI.First();

            string Password = passwords.Decrypt(accesobi.Password, configuration.GetSection("EvolucionaEncryptPasswordCuenta").Value);

            string Username = accesobi.Usuario;

            var oauthEndpoint = new Uri("https://login.microsoftonline.com/" + TenantAzure + "/oauth2/token");
            using (var client = new HttpClient())
            {
                FormUrlEncodedContent args = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("resource", ResourceUrl),
                    new KeyValuePair<string, string>("client_id", ApplicationId),
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("username", Username),
                    new KeyValuePair<string, string>("password", Password),
                    new KeyValuePair<string, string>("scope", "openid"),
                });
                var result = await client.PostAsync(oauthEndpoint, new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("resource", ResourceUrl),
                    new KeyValuePair<string, string>("client_id", ApplicationId),
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("username", Username),
                    new KeyValuePair<string, string>("password", Password),
                    new KeyValuePair<string, string>("scope", "openid"),
                }));

                var content = await result.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<OAuthResult>(content);
            }
        }

        class OAuthResult
        {
            [JsonProperty("token_type")]
            public string TokenType { get; set; }
            [JsonProperty("scope")]
            public string Scope { get; set; }
            [JsonProperty("experies_in")]
            public int ExpiresIn { get; set; }
            [JsonProperty("ext_experies_in")]
            public int ExtExpiresIn { get; set; }
            [JsonProperty("experies_on")]
            public int ExpiresOn { get; set; }
            [JsonProperty("not_before")]
            public int NotBefore { get; set; }
            [JsonProperty("resource")]
            public Uri Resource { get; set; }
            [JsonProperty("access_token")]
            public string AccessToken { get; set; }
            [JsonProperty("refresh_token")]
            public string RefreshToken { get; set; }
        }
    }
}