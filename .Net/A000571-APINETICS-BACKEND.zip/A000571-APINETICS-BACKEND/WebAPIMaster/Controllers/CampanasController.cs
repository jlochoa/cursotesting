﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using ExcelDataReader;
using Mailjet.Client;
using Mailjet.Client.Resources;
using Mailjet.Client.TransactionalEmails;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CampanasController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;
        private readonly IHttpContextAccessor _accessor;
        private readonly IPasswords _passwords;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _server;

        public CampanasController(ApineticsContext context, IHttpContextAccessor accessor, IPasswords passwords, IConfiguration configuration, IWebHostEnvironment env, IGestorRastro gestorRastro)
        {
            _context = context;
            _accessor = accessor;
            _passwords = passwords;
            _configuration = configuration;
            _server = env;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Campanas
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetListasContactosCombo([FromRoute] Guid idEmpresa)
        {
            var listaContactos = await (from x in _context.Campanas
                                        where x.Empresas_Id == idEmpresa
                                        select new DTODataCombo
                                        {
                                            Value = x.Id,
                                            Label = x.Nombre,
                                        }).ToListAsync();

            return Ok(listaContactos);
        }

        // GET: api/Campanas
        [HttpGet("combo2/{idDominio}")]
        public async Task<IActionResult> GetPlantillasCombo([FromRoute] Guid idDominio)
        {
            var plantillas = new List<DTODataComboP>();

            var dominio = await _context.Dominios.FindAsync(idDominio);

            string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
            string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

            MailjetClient client = new MailjetClient(apiKey, apiSecret);

            MailjetRequest request = new MailjetRequest
            {
                Resource = Template.Resource,
                Filters = new Dictionary<string, string> { { "Limit", "1000" } }
            };

            MailjetResponse response = await client.GetAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var data = response.GetData();

                foreach (var template in data)
                {
                    plantillas.Add(new DTODataComboP
                    {
                        Value = template["ID"].ToString(),
                        Label = template["Name"].ToString(),
                    });
                }

                plantillas = plantillas.OrderBy(p => p.Label).ToList();
            }

            return Ok(plantillas);
        }

        // GET: api/Campanas
        [HttpGet("combo3/{idDominio}")]
        public async Task<IActionResult> GetCorreosCombo([FromRoute] Guid idDominio)
        {
            var correos = new List<DTODataComboP>();

            var dominio = await _context.Dominios.FindAsync(idDominio);

            string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
            string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

            MailjetClient client = new MailjetClient(apiKey, apiSecret);

            MailjetRequest request = new MailjetRequest
            {
                Resource = Sender.Resource,
                Filters = new Dictionary<string, string> { { "Limit", "1000" } }
            };

            MailjetResponse response = await client.GetAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var data = response.GetData();

                foreach (var template in data)
                {
                    correos.Add(new DTODataComboP
                    {
                        Value = template["ID"].ToString(),
                        Label = template["Email"].ToString(),
                    });
                }

                correos = correos.OrderBy(p => p.Label).ToList();
            }

            return Ok(correos);
        }


        // GET: api/Campanas
        [HttpGet("plantilla/{idDominio}/{idPlantilla}")]
        public async Task<IActionResult> GetPlantilla([FromRoute] Guid idDominio, string idPlantilla)
        {
            var plantilla = new DTOPlantilla();

            var dominio = await _context.Dominios.FindAsync(idDominio);

            string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
            string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

            MailjetClient client = new MailjetClient(apiKey, apiSecret);

            MailjetRequest request = new MailjetRequest
            {
                Resource = TemplateDetailcontent.Resource,
                ResourceId = ResourceId.Numeric(Int32.Parse(idPlantilla))
            };

            MailjetResponse response = await client.GetAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var data = response.GetData();
                var firstItem = data.FirstOrDefault();
                if (firstItem != null)
                {
                    plantilla = new DTOPlantilla()
                    {
                        Asunto = firstItem["Headers"]?["Subject"]?.ToString(),
                        DeNombre = firstItem["Headers"]?["SenderName"]?.ToString(),
                        DeEmail = firstItem["Headers"]?["SenderEmail"]?.ToString(),
                        //IdCorreoEnvio = firstItem["Headers"]["Sender"]?.ToString(),
                        Contenido = firstItem["Text-part"]?.ToString(),
                        ContenidoHTML = firstItem["Html-part"]?.ToString(),
                    };
                }
            }
            return Ok(plantilla);
        }

        // GET: api/Campanas
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetCampanasByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var campanas = await (from x in _context.Campanas
                                  where x.Dominios.Empresas_Id == idEmpresa
                                  select new DTOCampanas
                                  {
                                      Id=x.Id,
                                      Dominios_Id=x.Dominios_Id,
                                      Codigo=x.Codigo,
                                      Nombre=x.Nombre,
                                      Asunto=x.Asunto,
                                      DeEmail=x.DeEmail,
                                      DeNombre = x.DeNombre,
                                      Contenido = x.Contenido,
                                      ContenidoHTML = x.ContenidoHTML,
                                      ListasContactos_Id=x.ListasContactos_Id,
                                      FechaHoraEnvio=x.FechaHoraEnvio,
                                      EnvioProgramado=x.EnvioProgramado,
                                      Enviado=x.Enviado,
                                      DescripcionDominio=x.Dominios.Dominio,
                                      DescripcionListaContactos = x.ListasContactos.Nombre
                                  }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Campañas, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(campanas);
        }

        // GET: api/Campanas
        [HttpGet("mailjet/bulk/{idDominio}")]
        public async Task<IActionResult> PostTodasCampanas([FromRoute] Guid idDominio)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var dominios = await _context.Dominios
                    .Where(x => x.ApiKey != null && x.ApiSecret != null)
                    .ToListAsync();

                var campanasActualizadas = new HashSet<string>(); // Para rastrear los códigos de campañas procesadas
                var campanasC = new List<DTOCampanas>();

                foreach (var dominio in dominios)
                {
                    string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                    string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                    MailjetClient client = new MailjetClient(apiKey, apiSecret);

                    MailjetRequest request = new MailjetRequest
                    {
                        Resource = Campaigndraft.Resource,
                        Filters = new Dictionary<string, string> { { "Limit", "1000" } }
                    };

                    MailjetResponse response = await client.GetAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var data = response.GetData();

                        foreach (var campaign in data)
                        {
                            var codigo = campaign["ID"].ToString();
                            campanasActualizadas.Add(codigo);

                            var contactsListId = campaign["ContactsListID"]?.ToString();

                            var listaContactos = !string.IsNullOrEmpty(contactsListId)
                                ? await _context.ListasContactos
                                    .Where(x => x.IdListaMailjet.ToString() == contactsListId)
                                    .FirstOrDefaultAsync()
                                : null;

                            var campanaExistente = await _context.Campanas
                                .FirstOrDefaultAsync(x => x.Codigo == codigo);

                            if (campanaExistente != null)
                            {
                                // Actualizar la campaña existente
                                campanaExistente.Nombre = campaign["Title"].ToString();
                                campanaExistente.ListasContactos_Id = listaContactos?.Id;
                                campanaExistente.Asunto = campaign["Subject"].ToString();
                                campanaExistente.DeEmail = campaign["SenderEmail"].ToString();
                                campanaExistente.DeNombre = campaign["SenderName"].ToString();
                                campanaExistente.IdPlantilla = campaign["TemplateID"]?.ToString() ?? null;
                                campanaExistente.IdCorreoEnvio = campaign["Sender"]?.ToString() ?? null;
                                campanaExistente.FechaHoraEnvio = campaign["DeliveredAt"] != null && !string.IsNullOrEmpty(campaign["DeliveredAt"].ToString())
                                    ? DateTime.Parse(campaign["DeliveredAt"].ToString())
                                    : null;
                                campanaExistente.Enviado = (int)campaign["Status"] == 2;
                                campanaExistente.EnvioProgramado = (int)campaign["Status"] == 1;
                                campanaExistente.UsuarioModificacion = User.Identity.Name;
                                campanaExistente.FechaModificacion = DateTime.Now;
                            }
                            else
                            {
                                // Insertar una nueva campaña
                                var nuevaCampana = new Campanas
                                {
                                    Nombre = campaign["Title"].ToString(),
                                    Codigo = codigo,
                                    ListasContactos_Id = listaContactos?.Id,
                                    Asunto = campaign["Subject"].ToString(),
                                    DeEmail = campaign["SenderEmail"].ToString(),
                                    DeNombre = campaign["SenderName"].ToString(),
                                    IdPlantilla = campaign["TemplateID"]?.ToString() ?? null,
                                    IdCorreoEnvio = campaign["Sender"]?.ToString() ?? null,
                                    FechaHoraEnvio = campaign["DeliveredAt"] != null && !string.IsNullOrEmpty(campaign["DeliveredAt"].ToString())
                                        ? DateTime.Parse(campaign["DeliveredAt"].ToString())
                                        : null,
                                    Enviado = (int)campaign["Status"] == 2,
                                    EnvioProgramado = (int)campaign["Status"] == 1,
                                    UsuarioCreacion = User.Identity.Name,
                                    FechaCreacion = DateTime.Parse(campaign["CreatedAt"].ToString()),
                                    UsuarioModificacion = User.Identity.Name,
                                    FechaModificacion = DateTime.Now,
                                    Dominios_Id = dominio.Id,
                                    Empresas_Id = dominio.Empresas_Id
                                };
                                await _context.Campanas.AddAsync(nuevaCampana);
                            }
                        }
                    }
                    else
                    {
                        return StatusCode((int)response.StatusCode, "Error al obtener las campañas de Mailjet");
                    }
                }

                // Guardar cambios de las actualizaciones e inserciones
                await _context.SaveChangesAsync();

                // Eliminar campañas que no están en los datos nuevos
                var codigosExistentes = await _context.Campanas
                    .Where(x => x.Dominios_Id == idDominio)
                    .Select(x => x.Codigo)
                    .ToListAsync();

                var codigosAEliminar = codigosExistentes
                    .Except(campanasActualizadas)
                    .ToList();

                var campanasAEliminar = await _context.Campanas
                    .Where(x => codigosAEliminar.Contains(x.Codigo))
                    .ToListAsync();

                _context.Campanas.RemoveRange(campanasAEliminar);
                await _context.SaveChangesAsync();

                // Generar respuesta con las campañas actualizadas
                campanasC = await (from x in _context.Campanas
                                   where x.Dominios_Id == idDominio
                                   orderby x.FechaHoraEnvio == null, x.FechaHoraEnvio descending
                                   select new DTOCampanas
                                   {
                                       Nombre = x.Nombre,
                                       Codigo = x.Codigo,
                                       ListasContactos_Id = x.ListasContactos_Id,
                                       Asunto = x.Asunto,
                                       DeEmail = x.DeEmail,
                                       DeNombre = x.DeNombre,
                                       IdPlantilla = x.IdPlantilla,
                                       IdCorreoEnvio = x.IdCorreoEnvio,
                                       Contenido = x.Contenido,
                                       ContenidoHTML = x.ContenidoHTML,
                                       FechaHoraEnvio = x.FechaHoraEnvio,
                                       Enviado = x.Enviado,
                                       EnvioProgramado = x.EnvioProgramado,
                                       Dominios_Id = x.Dominios_Id,
                                       Empresas_Id = x.Empresas_Id,
                                       DescripcionDominio = x.Dominios.Nombre,
                                       DescripcionListaContactos = x.ListasContactos.Nombre
                                   }).ToListAsync();

                await _gestorRastro.AddRastro(User.Identity.Name, dominios.First().Empresas_Id, EnumTipoProcesoRastro.Campañas, EnumTipoAccionRastro.Agregar, "Bulk import Mailjet", null);

                transaction.Commit();
                return Ok(campanasC);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        [HttpPost("mailjet")]
        public async Task<IActionResult> PostEnvioCampañas([FromBody] DTOCampanas campana)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var contactos = new List<string>();

                var dominio = await _context.Dominios.FindAsync(campana.Dominios_Id);
                var listaContactos = await _context.ListasContactos.FindAsync(campana.ListasContactos_Id);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Campaigndraft.Resource,
                }
                 .Property(Campaigndraft.EditMode, "html2")
                 .Property(Campaigndraft.IsStarred, "false")
                 .Property(Campaigndraft.IsTextPartIncluded, "true")
                 .Property(Campaigndraft.Locale, "es_ES")
                 .Property(Campaigndraft.Template, campana.IdPlantilla)
                 .Property(Campaigndraft.Title, campana.Nombre)
                 .Property(Campaigndraft.ContactsListID, listaContactos.IdListaMailjet)
                 .Property(Campaigndraft.SenderName, campana.DeNombre)
                 .Property(Campaigndraft.Sender, campana.IdCorreoEnvio)
                 //.Property(Campaigndraft.SenderEmail, campana.DeEmail)
                 .Property(Campaigndraft.Subject, campana.Asunto);

                MailjetResponse response = await client.PostAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var draft = response.GetData();
                    var firstItem = draft.FirstOrDefault();

                    MailjetRequest request2 = new MailjetRequest
                    {
                        Resource = CampaigndraftDetailcontent.Resource,
                        ResourceId = ResourceId.Numeric((int)firstItem["ID"])
                    }
                    .Property(CampaigndraftDetailcontent.Htmlpart, campana.ContenidoHTML);

                    MailjetResponse response2 = await client.PostAsync(request2);
                    if (response2.IsSuccessStatusCode)
                    {
                        var data = response.GetData();

                        if (campana.FechaHoraEnvio != null)
                        {
                            DateTime f = (DateTime)campana.FechaHoraEnvio;
                            string fechaFormateada = $"{f.Year:D4}-{f.Month:D2}-{f.Day:D2}T{f.Hour:D2}:{f.Minute:D2}:{f.Second:D2}Z";
                            MailjetRequest request3 = new MailjetRequest
                            {
                                Resource = CampaigndraftSchedule.Resource,
                                ResourceId = ResourceId.Numeric((int)firstItem["ID"])
                            }
                            .Property(CampaigndraftSchedule.Date, fechaFormateada);

                            MailjetResponse response3 = await client.PostAsync(request3);

                            if (response3.IsSuccessStatusCode)
                            {
                                var data2 = response3.GetData();
                            }
                            else
                            {
                                var data2 = response3.GetData();

                                return StatusCode(400, $"Error al programar el envío");
                            }
                        }
                    }
                    else
                    {
                        return StatusCode(400, $"Error al volcar el texto del email");
                    }
                }
                else
                {
                    return StatusCode(400, $"Error al guardar el borrador");
                }

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        [HttpPost("plantilla")]
        public async Task<IActionResult> PostPlantilla([FromBody] DTOUploadPlantilla plantilla)
        {
            try
            {
                string idPlantilla = null;
                var dominio = await _context.Dominios.FindAsync(plantilla.IdDominio);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                MailjetRequest request = new MailjetRequest
                {
                    Resource = Template.Resource,
                }
                .Property(Template.Name, plantilla.NombrePlantilla)
                .Property(Template.Locale, "es_ES")
                .Property(Template.OwnerType, "user")
                .Property(Template.Copyright, "Todos los Derechos Reservados © 2025 CIMA Nuevas Tecnologías Informáticas");

                if (plantilla.IdPlantilla == null)
                {
                    MailjetResponse response = await client.PostAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var data = response.GetData();
                        var firstItem = data.FirstOrDefault();

                        if (firstItem != null)
                        {
                            idPlantilla = firstItem["ID"]?.ToString();
                            var from = plantilla.DeNombre != null ? '\u0022' + plantilla.DeNombre + '\u0022' + (plantilla.DeEmail != null ?
                                " <" + plantilla.DeEmail + ">" : "") : plantilla.DeEmail != null ? plantilla.DeEmail : null;

                            MailjetRequest request2 = new MailjetRequest
                            {
                                Resource = TemplateDetailcontent.Resource,
                                ResourceId = ResourceId.Numeric(Int32.Parse(idPlantilla))
                            }
                            .Property(TemplateDetailcontent.Htmlpart, plantilla.ContenidoHTML);
                            //.Property(TemplateDetailcontent.Subject, plantilla.Asunto);

                            JObject headers = new JObject();

                            if (!plantilla.Asunto.IsNullOrEmpty())
                            {
                                headers["Subject"] = plantilla.Asunto;
                            }

                            if (!plantilla.DeNombre.IsNullOrEmpty())
                            {
                                headers["SenderName"] = plantilla.DeNombre;
                            }

                            if (!plantilla.DeEmail.IsNullOrEmpty())
                            {
                                headers["SenderEmail"] = plantilla.DeEmail;
                            }

                            if (from != null)
                            {
                                headers["From"] = from;
                            }

                            request2.Property(TemplateDetailcontent.Headers, headers);

                            MailjetResponse response2 = await client.PostAsync(request2);
                            if (!response2.IsSuccessStatusCode)
                            {
                                return StatusCode(400, $"Error al cargar el contenido de la plantilla");
                            }
                        }
                    }
                    else
                    {
                        var p = response.GetData();
                        return StatusCode(400, $"Error al crear la plantilla");
                    }
                }
                else
                {
                    idPlantilla = plantilla.IdPlantilla;

                    request.ResourceId = ResourceId.Numeric(Int32.Parse(idPlantilla));

                    MailjetResponse response = await client.PutAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var from = plantilla.DeNombre != null ? '\u0022' + plantilla.DeNombre + '\u0022' + (plantilla.DeEmail != null ?
                                    " <" + plantilla.DeEmail + ">" : "") : plantilla.DeEmail != null ? plantilla.DeEmail : null;

                        MailjetRequest request2 = new MailjetRequest
                        {
                            Resource = TemplateDetailcontent.Resource,
                            ResourceId = ResourceId.Numeric(Int32.Parse(idPlantilla))
                        }
                        .Property(TemplateDetailcontent.Htmlpart, plantilla.ContenidoHTML);

                        JObject headers = new JObject();

                        if (!plantilla.Asunto.IsNullOrEmpty())
                        {
                            headers["Subject"] = plantilla.Asunto;
                        }

                        if (!plantilla.DeNombre.IsNullOrEmpty())
                        {
                            headers["SenderName"] = plantilla.DeNombre;
                        }

                        if (!plantilla.DeEmail.IsNullOrEmpty())
                        {
                            headers["SenderEmail"] = plantilla.DeEmail;
                        }

                        if (from != null)
                        {
                            headers["From"] = from;
                        }

                        request2.Property(TemplateDetailcontent.Headers, headers);

                        MailjetResponse response2 = await client.PutAsync(request2);
                        if (!response2.IsSuccessStatusCode)
                        {
                            return StatusCode(400, $"Error al cargar el contenido de la plantilla");
                        }
                    }
                    else
                    {
                        var p = response.GetData();
                        return StatusCode(400, $"Error al actualizar la plantilla");
                    }
                }

                return Ok(new { IdPlantilla = idPlantilla });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // PUT: api/Campanas
        [HttpPut("mailjet")]
        public async Task<IActionResult> PutCampana([FromBody] DTOCampanas campana)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var campanaEdit = await _context.Campanas.FindAsync(campana.Id);

                if (campanaEdit != null)
                {
                    return Conflict("No existe esta campaña");
                }

                var teniaFecha = campana.FechaHoraEnvio != null;

                var contactos = new List<string>();

                var dominio = await _context.Dominios.FindAsync(campana.Dominios_Id);
                var listaContactos = await _context.ListasContactos.FindAsync(campana.ListasContactos_Id);

                string apiKey = _passwords.Decrypt(dominio.ApiKey, _configuration.GetSection("AnSecretPass").Value);
                string apiSecret = _passwords.Decrypt(dominio.ApiSecret, _configuration.GetSection("AnSecretPass").Value);

                MailjetClient client = new MailjetClient(apiKey, apiSecret);

                DateTime f = (DateTime)campana.FechaHoraEnvio;
                string fechaFormateada = $"{f.Year:D4}-{f.Month:D2}-{f.Day:D2}T{f.Hour:D2}:{f.Minute:D2}:{f.Second:D2}Z";
                MailjetRequest request = new MailjetRequest
                {
                    Resource = CampaigndraftSchedule.Resource,
                    ResourceId = ResourceId.Numeric(Int32.Parse(campana.Codigo))
                }
                .Property(CampaigndraftSchedule.Date, fechaFormateada);

                MailjetResponse response = null;
                if (teniaFecha)
                {
                    response = await client.PutAsync(request);
                }
                else
                {
                    response = await client.PostAsync(request);
                }

                if (response.IsSuccessStatusCode)
                {
                    var data = response.GetData();

                    if (campanaEdit != null)
                    {
                        campanaEdit.Nombre = campana.Nombre;
                        campanaEdit.Asunto = campana.Asunto;
                        campanaEdit.DeEmail = campana.DeEmail;
                        campanaEdit.DeNombre = campana.DeEmail;
                        campanaEdit.Contenido = campana.Contenido;
                        campanaEdit.ContenidoHTML = campana.ContenidoHTML;
                        campanaEdit.IdPlantilla = campana.IdPlantilla;
                        campanaEdit.IdCorreoEnvio = campana.IdCorreoEnvio;
                        campanaEdit.ListasContactos_Id = campana.ListasContactos_Id;
                        campanaEdit.FechaHoraEnvio = campana.FechaHoraEnvio;
                        campanaEdit.UsuarioModificacion = User.Identity.Name;
                        campanaEdit.FechaModificacion = DateTime.Now;

                        _context.Entry(campanaEdit).State = EntityState.Modified;

                        await _context.SaveChangesAsync();

                        await _gestorRastro.AddRastro(User.Identity.Name, campana.Empresas_Id, EnumTipoProcesoRastro.Campañas, EnumTipoAccionRastro.Modificar, campana.Nombre, null);
                    }
                }
                else
                {
                    var data = response.GetData();

                    return StatusCode(400, $"Error al programar el envío");
                }

                transaction.Commit();
                return Ok();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }

        // DELETE: api/Campanas
        [HttpDelete("{idCampana}")]
        public async Task<IActionResult> DeleteCampana([FromRoute] Guid idCampana)
        {
            var idEmpresa = await (from x in _context.Campanas
                                   where x.Id == idCampana
                                   select x.Dominios.Empresas_Id).FirstOrDefaultAsync();


            var campana = await _context.Campanas.FindAsync(idCampana);
            if (campana == null)
            {
                return NotFound();
            }

            _context.Campanas.Remove(campana);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Campañas, EnumTipoAccionRastro.Eliminar, campana.Nombre, null);

            return Ok();
        }
    }
}
