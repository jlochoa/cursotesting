﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.AppModels;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using WebAPIMaster.ModelsDTO;
using Microsoft.Extensions.Configuration;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.IdentityModel.Tokens;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresasController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _server;
        private readonly IGestorRastro _gestorRastro;
        private readonly IPasswords _passwords;

        public EmpresasController(ApineticsContext context, IGestorRastro gestorRastro, IWebHostEnvironment env, IConfiguration configuration, IPasswords passwords)
        {
            _context = context;
            _server = env;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
            _passwords = passwords;
        }

        // GET: api/Empresas
        [HttpGet("combo")]
        public async Task<IActionResult> GetEmpresasCombo()
        {
            var inforUsuario = await (from x in _context.Usuarios
                                      where x.Email == User.Identity.Name
                                      select x).SingleOrDefaultAsync();

            if (inforUsuario.SuperAdministrador == true)
            {
                var empresas = await (from x in _context.Empresas
                                      where x.Activo == true
                                      select new DTODataCombo
                                      {
                                          Value = x.Id,
                                          Label = x.Nombre,
                                      }).ToListAsync();

                return Ok(empresas);
            }
            else
            {
                //si el que ha hecho login es un usuario distribuidor
                //en el combo de todas las empresas mostraremos las empresas de las que es distribuidor
                //y las empresas de las que nadie es distribuidor

                List<DTODataCombo> listaFinal = new List<DTODataCombo>();

                //empresas de las que el es distribuidor
                var empresasDistribuidor = await (from x in _context.UsuariosDistribuidores
                                                  where x.Usuarios_Id == inforUsuario.Id
                                                  select x.Empresas_Id).ToListAsync();

                //empresas de las que nadie es distriuidor

                //primero obtenemos todas las empresas
                var empresas = await (from x in _context.Empresas
                                      where x.Activo == true
                                      select x.Id).ToListAsync();

                //luego obtenemos las empresas que tienen distribuidores
                var empDist = await (from x in _context.UsuariosDistribuidores
                                     select x.Empresas_Id).ToListAsync();

                foreach (var i in empresas)
                {
                    if (!empDist.Contains(i) && !empresasDistribuidor.Contains(i))
                    {

                        var nombreEmpresa = await (from x in _context.Empresas
                                                   where x.Id == i
                                                   select x.Nombre).SingleOrDefaultAsync();

                        DTODataCombo nuevo = new DTODataCombo()
                        {
                            Value = i,
                            Label = nombreEmpresa
                        };

                        listaFinal.Add(nuevo);
                    }
                }

                foreach (var j in empresasDistribuidor)
                {
                    var nombreEmpresa = await (from x in _context.Empresas
                                               where x.Id == j
                                               select x.Nombre).SingleOrDefaultAsync();

                    DTODataCombo nuevo = new DTODataCombo()
                    {
                        Value = j,
                        Label = nombreEmpresa
                    };

                    listaFinal.Add(nuevo);
                }

                return Ok(listaFinal);
            }
        }

        // GET: api/Empresas
        [HttpGet]
        public async Task<IActionResult> GetEmpresas()
        {
            var idPruebas = Guid.Parse("5C20349B-1652-4BCF-8758-0C731AB1473E");

            var empresas = await (from x in _context.Empresas
                                  where x.Activo == true
                                  orderby x.Id == idPruebas descending, x.Nombre
                                  select new Empresas
                                  {
                                      Nombre = x.Nombre,
                                      Id = x.Id,
                                      Logo = x.Logo
                                  }).ToListAsync();

            return Ok(empresas);
        }

        // GET: api/Empresas/Logo
        [HttpGet("Logo/{Id}")]
        public async Task<IActionResult> GetLogoEmpresaById([FromRoute] Guid Id)
        {
            string dirPath = Path.Combine(_server.WebRootPath, "Empresas");
            string[] files = Directory.GetFiles(dirPath, Id.ToString() + ".*");
            return Ok(new { Logo = files[0] });
        }

        // GET: api/Empresas
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetDatosEmpresaById([FromRoute] Guid Id)
        {
            var datos = await (from x in _context.Empresas
                               where x.Id == Id
                               select new DTOEmpresas
                               {
                                   Id = x.Id,
                                   Nombre = x.Nombre,
                                   Logo = "",
                                   CIF = x.CIF,
                                   Direccion = x.Direccion,
                                   CodigoPostal = x.CodigoPostal,
                                   Fax = x.Fax,
                                   Web = x.Web,
                                   EmailEnvio = x.EmailEnvio,
                                   OpcionBotones = x.OpcionBotones,
                                   ServidorEnvio = x.ServidorEnvio,
                                   PuertoEnvio = x.PuertoEnvio,
                                   PasswordEnvio = x.PasswordEnvio != null && x.PasswordEnvio.Trim() != "" ? "si" : "no",
                                   Telefonos = (from y in _context.EmpresasTelefonos
                                                where y.Empresas_Id == x.Id
                                                select new DTOEmpresasTelefonos
                                                {
                                                    Id = y.Id,
                                                    Empresas_Id = y.Empresas_Id,
                                                    Telefono = y.Telefono
                                                }).ToList(),
                                   Correos = (from y in _context.EmpresasCorreos
                                              where y.Empresas_Id == x.Id
                                              select new DTOEmpresasCorreos
                                              {
                                                  Id = y.Id,
                                                  Empresas_Id = y.Empresas_Id,
                                                  Correo = y.Correo
                                              }).ToList(),
                               }).SingleOrDefaultAsync();

            string dirPath = Path.Combine(_server.WebRootPath, "Empresas");
            string[] files = Directory.GetFiles(dirPath, datos.Id.ToString() + ".*");
            if (!files.IsNullOrEmpty())
            {
                datos.Logo = files[0];
            }

            await _gestorRastro.AddRastro(User.Identity.Name, Id, EnumTipoProcesoRastro.Empresa, EnumTipoAccionRastro.Consultar, datos.Nombre != null ? datos.Nombre : null, null);

            return Ok(datos);
        }

        // GET: api/Empresas
        [HttpGet("obtenerNombreById/{Id}")]
        public async Task<IActionResult> ObtenerNombre([FromRoute] Guid Id)
        {
            var nombre = await (from x in _context.Empresas
                                where x.Id == Id
                                select x.Nombre).SingleOrDefaultAsync();

            return Ok(new { nombre = nombre });
        }

        // GET: api/Empresas
        [HttpGet("obtenerTipoBotones/{Id}")]
        public async Task<IActionResult> ObtenerTipoBotonesEmpresa([FromRoute] Guid Id)
        {
            var tip = await (from x in _context.Empresas
                             where x.Id == Id
                             select x.OpcionBotones).SingleOrDefaultAsync();

            return Ok(new { tipo = tip });
        }

        // GET: api/Empresas/downloadImagen/idEmpresa
        [HttpGet("downloadImagen/{Id}")]
        public async Task<IActionResult> DownloadImagenByIdEmpresa([FromRoute] Guid Id)
        {
            //var empresa = await _context.Empresas.FindAsync(Id);

            //if (empresa != null)
            {
                string dirPath = Path.Combine(_server.WebRootPath, "Empresas");
                string[] files = Directory.GetFiles(dirPath, Id.ToString() + ".*");

                if (files.Length > 0)
                {
                    string filePath = files[0];
                    if (System.IO.File.Exists(filePath))
                    {
                        byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);
                        return new FileContentResult(fileBytes, "application/octet");
                    }
                    else
                    {
                        return Conflict("No se ha podido obtener la imagen");
                    }
                }
                else
                {
                    return Conflict("Imagen inexistente");
                }
            }
        }

        // POST: api/Empresas/uploadImagen
        [HttpPost, Route("uploadImagen/{Id}")]
        public async Task<IActionResult> UploadLogo([FromRoute] Guid Id)
        {
            //id es el idEmpresa
            var empresa = await _context.Empresas.FindAsync(Id);

            var uploadPath = Path.Combine(_server.WebRootPath, "Empresas");

            string newName = "";
            foreach (var file in Request.Form.Files)
            {
                if (file.Length > 0)
                {
                    string extension = Path.GetExtension(file.FileName);
                    newName = Id.ToString() + extension;

                    string[] existingFiles = Directory.GetFiles(uploadPath, Id.ToString() + ".*");
                    foreach (string f in existingFiles)
                    {
                        System.IO.File.Delete(f);
                    }

                    var filePath = Path.Combine(uploadPath, newName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                }
            }

            if (empresa != null)
            {
                await _gestorRastro.AddRastro(User.Identity.Name, Id, EnumTipoProcesoRastro.Empresa, EnumTipoAccionRastro.Cambiar_imagen, null, null);
            }

            return Ok();
        }


        // PUT: api/Empresas
        [HttpPut]
        public async Task<IActionResult> PutEmpresa([FromBody] DTOEmpresas empresa)
        {
            var empresaEdit = await (from x in _context.Empresas
                                     where x.Id == empresa.Id
                                     select x).SingleOrDefaultAsync();

            if (empresaEdit != null)
            {
                if (empresa.PasswordEnvio != null && empresa.PasswordEnvio.Trim() != "")
                {
                    var secret = _configuration.GetSection("AnSecretPass").Value;
                    string passMD5 = _passwords.Encrypt(empresa.PasswordEnvio, secret);

                    empresaEdit.PasswordEnvio = passMD5;
                }
                empresaEdit.Nombre = empresa.Nombre;
                empresaEdit.CIF = empresa.CIF;
                empresaEdit.Direccion = empresa.Direccion;
                empresaEdit.CodigoPostal = empresa.CodigoPostal;
                empresaEdit.Fax = empresa.Fax;
                empresaEdit.Web = empresa.Web;
                empresaEdit.EmailEnvio = empresa.EmailEnvio;
                empresaEdit.ServidorEnvio = empresa.ServidorEnvio;
                empresaEdit.PuertoEnvio = empresa.PuertoEnvio;
                empresaEdit.UsuarioModificacion = User.Identity.Name;
                empresaEdit.FechaModificacion = DateTime.Now;
                empresaEdit.OpcionBotones = empresa.OpcionBotones;

                _context.Entry(empresaEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Esta empresa ya no existe");
            }

            //TELEFONOS//
            var telefonosEliminar = await (from x in _context.EmpresasTelefonos
                                           where x.Empresas_Id == empresa.Id
                                           select x).ToListAsync();

            foreach (var j in telefonosEliminar)
            {
                _context.EmpresasTelefonos.Remove(j);
            }

            foreach (var i in empresa.Telefonos)
            {
                EmpresasTelefonos nuevo = new EmpresasTelefonos
                {
                    Empresas_Id = (Guid)empresa.Id,
                    Telefono = i.Telefono
                };

                await _context.EmpresasTelefonos.AddAsync(nuevo);
            }

            //CORREOS//
            var correosEliminar = await (from x in _context.EmpresasCorreos
                                         where x.Empresas_Id == empresa.Id
                                         select x).ToListAsync();

            foreach (var j in correosEliminar)
            {
                _context.EmpresasCorreos.Remove(j);
            }

            foreach (var i in empresa.Correos)
            {
                EmpresasCorreos nuevo = new EmpresasCorreos
                {
                    Empresas_Id = (Guid)empresa.Id,
                    Correo = i.Correo
                };

                await _context.EmpresasCorreos.AddAsync(nuevo);
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, empresa.Id, EnumTipoProcesoRastro.Empresa, EnumTipoAccionRastro.Modificar, empresa.Nombre, null);

            return Ok();
        }

        // POST: api/Empresas
        [HttpPost]
        public async Task<IActionResult> PostEmpresa([FromBody] DTOEmpresas nuevaEmpresa)
        {
            string passMD5 = null;
            if (nuevaEmpresa.PasswordEnvio != null && nuevaEmpresa.PasswordEnvio.Trim() != "")
            {
                var secret = _configuration.GetSection("AnSecretPass").Value;
                passMD5 = _passwords.Encrypt(nuevaEmpresa.PasswordEnvio, secret);
            }

            using var transaction = _context.Database.BeginTransaction();
            try
            {
                Empresas nueva = new Empresas
                {
                    Id = (Guid)nuevaEmpresa.Id,
                    Nombre = nuevaEmpresa.Nombre,
                    CIF = nuevaEmpresa.CIF,
                    Direccion = nuevaEmpresa.Direccion,
                    CodigoPostal = nuevaEmpresa.CodigoPostal,
                    Fax = nuevaEmpresa.Fax,
                    Web = nuevaEmpresa.Web,
                    EmailEnvio = nuevaEmpresa.EmailEnvio,
                    ServidorEnvio = nuevaEmpresa.ServidorEnvio,
                    PuertoEnvio = nuevaEmpresa.PuertoEnvio,
                    PasswordEnvio = passMD5,
                    Activo = true,
                    TiempoEspera = 3000,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now,
                    OpcionBotones = nuevaEmpresa.OpcionBotones
                };

                await _context.Empresas.AddAsync(nueva);

                await _context.SaveChangesAsync();

                foreach (var i in nuevaEmpresa.Telefonos)
                {

                    EmpresasTelefonos nuevo = new EmpresasTelefonos
                    {
                        Empresas_Id = nueva.Id,
                        Telefono = i.Telefono
                    };

                    await _context.EmpresasTelefonos.AddAsync(nuevo);
                }
                await _context.SaveChangesAsync();


                foreach (var i in nuevaEmpresa.Correos)
                {

                    EmpresasCorreos nuevo2 = new EmpresasCorreos
                    {
                        Empresas_Id = nueva.Id,
                        Correo = i.Correo
                    };

                    await _context.EmpresasCorreos.AddAsync(nuevo2);
                }
                await _context.SaveChangesAsync();

                Permisos nuevoPermiso = new Permisos
                {
                    Visible = true,
                    Modificable = true,
                    Procesos_Id = new Guid("C74EA5C2-09FD-460E-AE2A-6AB88A740BDB"),
                    Empresas_Id = (Guid)nuevaEmpresa.Id,
                    Roles_Id = new Guid("E31D4C6D-519F-401A-BE91-E45499B706D6")
                };

                await _context.Permisos.AddAsync(nuevoPermiso);

                await _context.SaveChangesAsync();

                Permisos nuevoPermiso2 = new Permisos
                {
                    Visible = true,
                    Modificable = true,
                    Procesos_Id = new Guid("BC9535CE-7197-4FBA-9DB9-8F51C0E2DE8E"),
                    Empresas_Id = (Guid)nuevaEmpresa.Id,
                    Roles_Id = new Guid("E31D4C6D-519F-401A-BE91-E45499B706D6")
                };

                await _context.Permisos.AddAsync(nuevoPermiso2);

                await _context.SaveChangesAsync();

                Parametros param = new Parametros
                {
                    Id = (Guid)nuevaEmpresa.Id,
                    IdAccesoBi = 1,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now,
                };

                await _context.Parametros.AddAsync(param);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
                return Conflict("Error");
            }

            await _gestorRastro.AddRastro(User.Identity.Name, nuevaEmpresa.Id, EnumTipoProcesoRastro.Empresa, EnumTipoAccionRastro.Agregar, nuevaEmpresa.Nombre, null);

            return Ok(new { Id = nuevaEmpresa.Id });
        }

        [HttpDelete("{idEmpresa}")]
        public async Task<IActionResult> DeleteEmpresa([FromRoute] Guid idEmpresa)
        {
            var empresa = await _context.Empresas.FindAsync(idEmpresa);

            if (empresa == null)
            {
                return Conflict("La empresa no existe");
            }

            var publicaciones = await _context.Publicaciones.AnyAsync(x => x.Empresas_Id == idEmpresa);

            if (publicaciones)
            {
                return Conflict("No se puede dar de baja la empresa " + empresa.Nombre + " porque tiene publicaciones pendientes de subir.");
            }

            empresa.Activo = false;

            _context.Entry(empresa).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Empresa, EnumTipoAccionRastro.Eliminar, empresa.Nombre + " deshabilitada", null);

            return Ok();
        }
    }
}