﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebAPIMaster.AppModels;

namespace WebAPIMaster.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GoogleRecaptchaController : ControllerBase
    {
        private readonly IConfiguration configuration;

        public GoogleRecaptchaController(IConfiguration config)
        {
            configuration = config;
        }

        [HttpPost]
        public async Task<IActionResult> ValidCaptcha([FromBody] string token)
        {
            using (var client = new HttpClient())
            {
                //var secretKey = "6LeEfbMoAAAAAD2Fl5jiCOF4Bl3_rBSIni5UXGtS";
                var secretKey = configuration.GetSection("SecretCaptchaApinetics").Value;
                var response = await client.PostAsync($"https://www.google.com/recaptcha/api/siteverify?secret={secretKey}&response={token}", null);

                if (response.IsSuccessStatusCode)
                {
                    var resultString = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<JObject>(resultString);
                    return Ok(result);
                }
                else
                {
                    return Unauthorized();
                }
            }
        }
    }
}