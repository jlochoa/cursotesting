﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Services.Passwords;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DominiosController : Controller
    {
        private readonly ApineticsContext _context;
        private readonly IHttpContextAccessor _accessor;
        private readonly IWebHostEnvironment _server;
        private readonly IConfiguration _configuration;
        private readonly IGestorRastro _gestorRastro;
        private readonly IPasswords _passwords;

        public DominiosController(ApineticsContext context, IHttpContextAccessor accessor, IWebHostEnvironment env, IConfiguration configuration, IGestorRastro gestorRastro, IPasswords passwords)
        {
            _context = context;
            _accessor = accessor;
            _server = env;
            _configuration = configuration;
            _gestorRastro = gestorRastro;
            _passwords = passwords;
        }

        public class SERanking
        {
             public int site_id { get; set; }
        }

        // GET: api/Dominios
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetDominiosCombo([FromRoute] Guid idEmpresa)
        {
            var dominios = await (from x in _context.Dominios
                                   where x.Empresas_Id == idEmpresa
                                   select new DTODataComboMC
                                   {
                                       Value = (Guid)x.Id,
                                       Label = x.Nombre + " - " + x.Dominio,
                                       IdMetricool=x.IdMetricool
                                   }).ToListAsync();
            return Ok(dominios);
        } 
        
        // GET: api/Dominios
        [HttpGet("combo2/{idEmpresa}")]
        public async Task<IActionResult> GetDominiosComboMailjet([FromRoute] Guid idEmpresa)
        {
            var dominios = await (from x in _context.Dominios
                                  where x.Empresas_Id == idEmpresa &&
                                  (x.ApiKey != null && x.ApiSecret != null)
                                  select new DTODataComboMC
                                  {
                                      Value = (Guid)x.Id,
                                      Label = x.Nombre + " - " + x.Dominio,
                                  }).ToListAsync();
            return Ok(dominios);
        }

        // GET: api/Dominios
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetDominiosByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var dominios = await (from x in _context.Dominios
                                    where x.Empresas_Id == idEmpresa
                                    select new DTODominios
                                    {
                                        Id = x.Id,
                                        Empresas_Id = x.Empresas_Id,
                                        Nombre = x.Nombre,
                                        Dominio = x.Dominio,
                                        IdGoogleA = x.IdGoogleA,
                                        IdSeRanking = x.IdSeRanking,
                                        IdMetricool = x.IdMetricool,
                                        Facebook = x.Facebook,
                                        Instagram = x.Instagram,
                                        MyBusiness = x.MyBusiness,
                                        X = x.X,
                                        FacebookAds = x.FacebookAds,
                                        IdMailJet = x.IdMailJet,
                                        Logo = x.Logo,
                                        LinkedIn = x.LinkedIn,
                                        Pinterest = x.Pinterest,
                                        TikTok = x.TikTok,
                                        YouTube = x.YouTube,
                                        Twitch = x.Twitch,
                                        GoogleAds = x.GoogleAds,
                                        TikTokAds = x.TikTokAds,
                                        TieneApiKey = !x.ApiKey.IsNullOrEmpty(),
                                        TieneSecretKey = !x.ApiSecret.IsNullOrEmpty()
                                    }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(dominios);
        }

        // GET: api/Dominios/redes
        [HttpGet("redes/{idDominio}")]
        public async Task<IActionResult> GetRedesDominios([FromRoute] Guid idDominio)
        {
            var dominio = await _context.Dominios.FindAsync(idDominio);

            if (dominio == null)
            {
                return Conflict("Error al cargar el dominio");
            }


            return Ok(dominio);
        }

        // GET: api/Dominios/downloadImagen
        [HttpGet("downloadImagen/{id}")]
        public async Task<IActionResult> DownloadImagenByIdDominio([FromRoute] int id)
        {
            string filePath = "";

            var dominio = await _context.Dominios.FindAsync(id);
            if (dominio.Logo != null)
            {
                filePath = Path.Combine(_server.WebRootPath, "Dominios", dominio.Logo);
            }
            else
            {
                filePath = Path.Combine(_server.WebRootPath, "Dominios", "noimage.png");
            }

            if (System.IO.File.Exists(filePath))
            {
                byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);

                await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Ver_imagen, dominio.Dominio, null);

                return new FileContentResult(fileBytes, "application/octet");
            }
            else
            {
                throw new Exception("Imagen inexistente");
            }
        }

        // POST: api/Dominios/uploadImagen
        [HttpPost, Route("uploadImagen/{id}")]
        public async Task<IActionResult> UploadImagen([FromRoute] Guid id)
        {
            var dominio = await _context.Dominios.FindAsync(id);

            var uploadPath = Path.Combine(_server.WebRootPath, "Dominios");

            string newName = "";
            foreach (var file in Request.Form.Files)
            {
                if (file.Length > 0)
                {
                    FileInfo currentFile = new FileInfo(file.FileName);
                    newName = id + "_" + file.FileName;
                    var filePath = Path.Combine(uploadPath, newName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                }
            }
            dominio.Logo = newName;
            _context.Entry(dominio).State = EntityState.Modified;

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Cambiar_imagen, dominio.Dominio, null);

            return Ok();
        }

        // PUT: api/Dominios
        [HttpPut]
        public async Task<IActionResult> PutDominio([FromBody] DTODominios dominio)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var secret = _configuration.GetSection("AnSecretPass").Value;
                string keyMD5 = null;
                string secMD5 = null;
                if (dominio.ApiKey != null)
                {
                    keyMD5 = _passwords.Encrypt(dominio.ApiKey, secret);
                }
                if (dominio.ApiSecret != null)
                {
                    secMD5 = _passwords.Encrypt(dominio.ApiSecret, secret);
                }

                var dominioEdit = await _context.Dominios.FindAsync(dominio.Id);

                if (dominioEdit != null)
                {
                    dominioEdit.Nombre = dominio.Nombre;
                    dominioEdit.IdGoogleA = dominio.IdGoogleA;
                    dominioEdit.IdSeRanking = dominio.IdSeRanking;
                    dominioEdit.IdMetricool = dominio.IdMetricool;
                    dominioEdit.Facebook = dominio.Facebook;
                    dominioEdit.Instagram = dominio.Instagram;
                    dominioEdit.MyBusiness = dominio.MyBusiness;
                    dominioEdit.X = dominio.X;
                    dominioEdit.IdMailJet = dominio.IdMailJet;
                    dominioEdit.LinkedIn = dominio.LinkedIn;
                    dominioEdit.Pinterest = dominio.Pinterest;
                    dominioEdit.TikTok = dominio.TikTok;
                    dominioEdit.YouTube = dominio.YouTube;
                    dominioEdit.Twitch = dominio.Twitch;
                    dominioEdit.GoogleAds = dominio.GoogleAds;
                    dominioEdit.FacebookAds = dominio.FacebookAds;
                    dominioEdit.TikTokAds = dominio.TikTokAds;
                    dominioEdit.UsuarioModificacion = User.Identity.Name;
                    dominioEdit.FechaModificacion = DateTime.Now;

                    if (keyMD5 != null)
                    {
                        dominioEdit.ApiKey = keyMD5;
                    }
                    if (secMD5 != null)
                    {
                        dominioEdit.ApiSecret = secMD5;
                    }

                    _context.Entry(dominioEdit).State = EntityState.Modified;

                    await _context.SaveChangesAsync();

                    await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Modificar, dominio.Dominio, null);

                    //Modificamos tambien el nombre en SE Ranking
                    var token = _configuration.GetSection("TokenSeRanking").Value;

                    var infor = new
                    {
                        token = token,
                        title = dominio.Nombre
                    };

                    var json = Newtonsoft.Json.JsonConvert.SerializeObject(infor);
                    var data = new StringContent(json, Encoding.UTF8, "application/json");

                    var url = "https://api4.seranking.com/sites/" + dominio.IdSeRanking;
                    using var client = new HttpClient();

                    var response = await client.PutAsync(url, data);

                    string result = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    throw new Exception("Este dominio ya no existe");
                }

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }

        // POST: api/Dominios
        [HttpPost]
        public async Task<IActionResult> PostDominio([FromBody] DTODominios dominio)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var secret = _configuration.GetSection("AnSecretPass").Value;
                string keyMD5 = null;
                string secMD5 = null;
                if (dominio.ApiKey != null)
                {
                    keyMD5 = _passwords.Encrypt(dominio.ApiKey, secret);
                }
                if (dominio.ApiSecret != null)
                {
                    secMD5 = _passwords.Encrypt(dominio.ApiSecret, secret);
                }

                Dominios nuevo = new Dominios
                {
                    Empresas_Id = (Guid)dominio.Empresas_Id,
                    Nombre = dominio.Nombre,
                    Dominio = dominio.Dominio,
                    IdGoogleA = dominio.IdGoogleA,
                    IdSeRanking = dominio.IdSeRanking,
                    IdMetricool = dominio.IdMetricool,
                    Facebook = dominio.Facebook,
                    Instagram = dominio.Instagram,
                    MyBusiness = dominio.MyBusiness,
                    X = dominio.X,
                    IdMailJet = dominio.IdMailJet,
                    LinkedIn = dominio.LinkedIn,
                    Pinterest = dominio.Pinterest,
                    TikTok = dominio.TikTok,
                    YouTube = dominio.YouTube,
                    Twitch = dominio.Twitch,
                    GoogleAds = dominio.GoogleAds,
                    FacebookAds = dominio.FacebookAds,
                    TikTokAds = dominio.TikTokAds,
                    ApiKey = keyMD5,
                    ApiSecret = secMD5,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now,
                };

                await _context.Dominios.AddAsync(nuevo);
                await _context.SaveChangesAsync();

                //Damos de alta el dominio en SE Ranking
                var token = _configuration.GetSection("TokenSeRanking").Value;

                var nuevoDom = new
                {
                    token = token,
                    url = dominio.Dominio,
                    title = dominio.Nombre
                };

                var json = Newtonsoft.Json.JsonConvert.SerializeObject(nuevoDom);
                var data = new StringContent(json, Encoding.UTF8, "application/json");

                var url = "https://api4.seranking.com/sites";
                using var client = new HttpClient();

                var response = await client.PostAsync(url, data);

                string result = response.Content.ReadAsStringAsync().Result;

                //el codigo que nos devuelve lo ponemos en el campo correspondiente

                SERanking infor = JsonSerializer.Deserialize<SERanking>(result);
                nuevo.IdSeRanking = infor.site_id;

                _context.Entry(nuevo).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Agregar, dominio.Dominio, null);

            return Ok();
        }

        // DELETE: api/Dominios
        [HttpDelete("{idDominio}")]
        public async Task<IActionResult> DeleteDominio([FromRoute] Guid idDominio)
        {
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var campanas = await _context.Campanas.AnyAsync(x => x.Dominios_Id == idDominio);
                if (campanas)
                {
                    return Conflict("Hay campañas creadas para este dominio. No se puede eliminar.");
                }

                var listaContactos = await _context.ListasContactos.AnyAsync(x => x.Dominios_Id == idDominio);
                if (listaContactos)
                {
                    return Conflict("Hay listas de contacto creadas para este dominio. No se puede eliminar.");
                }

                var palabrasClave = await (from x in _context.PalabrasClave
                                           where x.Dominios_Id == idDominio
                                           select x).ToListAsync();

                foreach (var p in palabrasClave)
                {
                    _context.PalabrasClave.Remove(p);
                }

                var competidores = await (from x in _context.Competidores
                                          where x.Dominios_Id == idDominio
                                          select x).ToListAsync();

                foreach (var c in competidores)
                {
                    _context.Competidores.Remove(c);

                }

                var dominio = await _context.Dominios.FindAsync(idDominio);

                if (dominio == null)
                {
                    return NotFound();
                }

                _context.Dominios.Remove(dominio);
                await _context.SaveChangesAsync();

                var token = _configuration.GetSection("TokenSeRanking").Value;

                var url = "https://api4.seranking.com/sites/" + dominio.IdSeRanking;
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "Token " + token);

                var response = await client.DeleteAsync(url);

                string result = response.Content.ReadAsStringAsync().Result;

                await _gestorRastro.AddRastro(User.Identity.Name, dominio.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Eliminar, dominio.Dominio, null);

                transaction.Commit();
            }
            catch (Exception)
            {
                transaction.Rollback();
            }

            return Ok();
        }

        [HttpPut("Metri/{idDominio}/{idMetricool}")]
        public async Task<IActionResult> PutDominioMetri([FromRoute] Guid idDominio, int idMetricool)
        {
            var dominioEdit = await _context.Dominios.FindAsync(idDominio);

            if (dominioEdit != null)
            {
                dominioEdit.IdMetricool = idMetricool;

                _context.Entry(dominioEdit).State = EntityState.Modified;
            }
            else
            {
                throw new Exception("Este dominio ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, dominioEdit.Empresas_Id, EnumTipoProcesoRastro.Dominios, EnumTipoAccionRastro.Modificar, idMetricool.ToString(), null);

            return Ok();
        }
    }
}

