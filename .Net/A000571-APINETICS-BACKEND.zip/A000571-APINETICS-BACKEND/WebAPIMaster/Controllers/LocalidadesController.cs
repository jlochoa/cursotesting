﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LocalidadesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public LocalidadesController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Localidades
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetLocalidadesCombo([FromRoute] Guid idEmpresa)
        {
            var localidades = await (from x in _context.Localidades
                                     where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                     orderby x.Nombre
                                     select new DTODataComboMC
                                     {
                                         Value = x.Id,
                                         Label = x.Nombre
                                     }).ToListAsync();

            return Ok(localidades);
        }

        // GET: api/Localidades
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetLocalidadesByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var localidades = await (from x in _context.Localidades
                                     where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                     orderby x.Empresas_Id != null descending, x.Nombre
                                     select new DTOLocalidades
                                     {
                                         Id = x.Id,
                                         Nombre = x.Nombre,
                                         Provincias_Id = x.Provincias_Id,
                                         CodigoPostal = x.CodigoPostal,
                                         Empresas_Id = x.Empresas_Id,
                                         NombreProvincia = x.Provincias.Nombre
                                     }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Localidades, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(localidades);
        }

        // GET: api/Localidades
        [HttpGet("obtenerCodigoPostal/{idLocalidad}")]
        public async Task<IActionResult> GetCodigoPostalByIdLocalidad([FromRoute] Guid idLocalidad)
        {
            int? codigoPostal = await (from x in _context.Localidades
                                       where x.Id == idLocalidad
                                       select x.CodigoPostal).SingleOrDefaultAsync();

            return Ok(codigoPostal);
        }

        // PUT: api/Localidades
        [HttpPut]
        public async Task<IActionResult> PutLocalidades([FromBody] DTOLocalidades localidad)
        {
            if (localidad.Nombre != null && localidad.Nombre.Trim() != "")
            {
                var localidadExiste = await _context.Localidades.AnyAsync(x => x.Nombre == localidad.Nombre && x.Id != localidad.Id && x.Empresas_Id == localidad.Empresas_Id);
                if (localidadExiste)
                {
                    return Conflict("Una localidad con este nombre está registrada para esta empresa");
                }
            }

            if (localidad.Nombre != null && localidad.Nombre.Trim() != "")
            {
                var localidadExiste2 = await _context.Localidades.AnyAsync(x => x.Nombre == localidad.Nombre && x.Id != localidad.Id && x.Empresas_Id == null);
                if (localidadExiste2)
                {
                    return Conflict("Una localidad con este nombre está registrada como genérica");
                }
            }

            var localidadEdit = await _context.Localidades.FindAsync(localidad.Id);

            if (localidadEdit != null)
            {
                localidadEdit.Nombre = localidad.Nombre;
                localidadEdit.Provincias_Id = localidad.Provincias_Id;
                localidadEdit.CodigoPostal = localidad.CodigoPostal;
                localidadEdit.UsuarioModificacion = User.Identity.Name;
                localidadEdit.FechaModificacion = DateTime.Now;
                localidadEdit.Empresas_Id = localidad.Empresas_Id;
                _context.Entry(localidadEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Esta localidad ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, localidadEdit.Empresas_Id, EnumTipoProcesoRastro.Localidades, EnumTipoAccionRastro.Modificar, localidadEdit.Nombre, null);

            return Ok();
        }

        // POST: api/Localidades
        [HttpPost]
        public async Task<IActionResult> PostLocalidades([FromBody] DTOLocalidades localidad)
        {
            if (localidad.Nombre != null && localidad.Nombre.Trim() != "")
            {
                var localidadExiste = await _context.Localidades.AnyAsync(x => x.Nombre.ToUpper() == localidad.Nombre.ToUpper() && x.Empresas_Id==localidad.Empresas_Id);
                if (localidadExiste)
                {
                    return Conflict("Una localidad con este nombre ya está registrada para esta empresa");
                }
            }

            if (localidad.Nombre != null && localidad.Nombre.Trim() != "")
            {
                var localidadExiste2 = await _context.Localidades.AnyAsync(x => x.Nombre == localidad.Nombre && x.Empresas_Id == null);
                if (localidadExiste2)
                {
                    return Conflict("Una localidad con este nombre ya está registrada como genérica");
                }
            }

            Localidades nuevoLocalidad = new Localidades
            {
                Nombre = localidad.Nombre,
                Provincias_Id = localidad.Provincias_Id,
                CodigoPostal = localidad.CodigoPostal,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now,
                Empresas_Id = localidad.Empresas_Id,
            };

            await _context.Localidades.AddAsync(nuevoLocalidad);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, localidad.Empresas_Id, EnumTipoProcesoRastro.Localidades, EnumTipoAccionRastro.Modificar, localidad.Nombre, null);

            return Ok(nuevoLocalidad);
        }

        // DELETE: api/Localidades/5
        [HttpDelete("{IdLocalidad}")]
        public async Task<IActionResult> DeleteLocalidades([FromRoute] Guid IdLocalidad)
        {
            var entidades = await _context.Entidades.AnyAsync(x => x.Localidades_Id == IdLocalidad);
            if (entidades)
            {
                return Conflict("Esta localidad esta asignada a alguna entidad. No se puede eliminar");
            }

            var contactos = await _context.Contactos.AnyAsync(x => x.Localidades_Id == IdLocalidad);
            if (contactos)
            {
                return Conflict("Esta localidad esta asignada a algún contacto. No se puede eliminar");
            }

            var empresas = await _context.Empresas.AnyAsync(x => x.Localidades_Id == IdLocalidad);
            if (empresas)
            {
                return Conflict("Esta localidad esta asignada a alguna empresa. No se puede eliminar");
            }

            var localidad = await _context.Localidades.FindAsync(IdLocalidad);
            if (localidad == null)
            {
                return NotFound();
            }

            _context.Localidades.Remove(localidad);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, localidad.Empresas_Id, EnumTipoProcesoRastro.Localidades, EnumTipoAccionRastro.Eliminar, localidad.Nombre, null);

            return Ok(localidad);
        }
    }
}

