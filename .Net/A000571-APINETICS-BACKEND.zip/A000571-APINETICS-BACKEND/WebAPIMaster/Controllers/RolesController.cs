﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Runtime.InteropServices.Marshalling;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public RolesController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Roles/combo
        //[AllowAnonymous]
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetRolesComboByIdEmpresa([FromRoute] Guid idEmpresa)
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();
            var rol = await _context.Roles.Where(x => x.Id == usuario.Roles_Id).FirstOrDefaultAsync();

            if (usuario.SuperAdministrador == null || usuario.SuperAdministrador == false)
            {
                var roles = await (from x in _context.Roles
                                   where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null) &&
                                   x.Nivel >= rol.Nivel
                                   select new DTODataCombo
                                   {
                                       Value = x.Id,
                                       Label = x.Descripcion,
                                   }).ToListAsync();

                return Ok(roles);
            }
            else
            {
                var roles = await (from x in _context.Roles
                                   where x.Empresas_Id == idEmpresa || x.Empresas_Id == null
                                   select new DTODataCombo
                                   {
                                       Value = x.Id,
                                       Label = x.Descripcion,
                                   }).ToListAsync();

                return Ok(roles);
            }
        }


        // GET: api/Roles
        //[AllowAnonymous]
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetRoles([FromRoute] Guid idEmpresa)
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();
            var rol = await _context.Roles.Where(x => x.Id == usuario.Roles_Id).FirstOrDefaultAsync();
            if (usuario.SuperAdministrador == null || usuario.SuperAdministrador == false)
            {
                var roles = await (from x in _context.Roles
                                   where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null) &&
                                   x.Nivel >= rol.Nivel
                                   orderby x.Nivel
                                   select new DTORoles
                                   {
                                       Id = x.Id,
                                       Nivel = x.Nivel,
                                       Descripcion = x.Descripcion,
                                       Empresas_Id = x.Empresas_Id
                                   }).ToListAsync();

                return Ok(roles);
            }
            else
            {
                var roles = await (from x in _context.Roles
                                   where x.Empresas_Id == idEmpresa || x.Empresas_Id == null
                                   orderby x.Nivel
                                   select new DTORoles
                                   {
                                       Id = x.Id,
                                       Nivel = x.Nivel,
                                       Descripcion = x.Descripcion,
                                       Empresas_Id = x.Empresas_Id
                                   }).ToListAsync();

                return Ok(roles);
            }
        }

        // POST: api/Roles
        [HttpPost]
        public async Task<IActionResult> PostRoles([FromBody] DTORoles rol)
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();
            var rolUsuario = await _context.Roles.Where(x => x.Id == usuario.Roles_Id).FirstOrDefaultAsync();

            if (rol.Descripcion != null && rol.Descripcion.Trim() != "")
            {
                var rolExiste = await _context.Roles.AnyAsync(x => x.Descripcion == rol.Descripcion && (x.Empresas_Id == rol.Empresas_Id || x.Empresas_Id == null));
                if (rolExiste)
                {
                    return Conflict("Este rol ya está registrado para esta empresa");
                }
            }

            if (rol.Nivel != null)
            {
                var nivelExiste = await _context.Roles.AnyAsync(x => x.Nivel == rol.Nivel && (x.Empresas_Id == rol.Empresas_Id || x.Empresas_Id == null));
                if (nivelExiste)
                {
                    return Conflict("Este nivel ya está asignado para otro rol");
                }

                if (usuario.SuperAdministrador == null || usuario.SuperAdministrador == false)
                {
                    var nivelSuperior = rolUsuario.Nivel > rol.Nivel;
                    if (nivelSuperior)
                    {
                        return Conflict("No puedes crear roles con nivel superior al tuyo");
                    }
                }
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Roles nuevo = new Roles
            {
                Descripcion = rol.Descripcion,
                Nivel = (int)rol.Nivel,
                Empresas_Id = rol.Empresas_Id,
                FechaCreacion = DateTime.Now,
                UsuarioCreacion = User.Identity.Name,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now
            };

            await _context.Roles.AddAsync(nuevo);

            await _context.SaveChangesAsync();

            //añadir Ayuda
            Permisos permisosAyuda = new Permisos
            {
                Visible = true,
                Modificable = true,
                Procesos_Id = new Guid("C74EA5C2-09FD-460E-AE2A-6AB88A740BDB"),
                Empresas_Id = rol.Empresas_Id,
                Roles_Id = nuevo.Id
            };

            await _context.Permisos.AddAsync(permisosAyuda);

            //añadir Parametros Redes Sociales
            Permisos permisosParametros = new Permisos
            {
                Visible = true,
                Modificable = true,
                Procesos_Id = new Guid("BC9535CE-7197-4FBA-9DB9-8F51C0E2DE8E"),
                Empresas_Id = rol.Empresas_Id,
                Roles_Id = nuevo.Id
            };

            await _context.Permisos.AddAsync(permisosParametros);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, rol.Empresas_Id, EnumTipoProcesoRastro.Roles, EnumTipoAccionRastro.Agregar, rol.Descripcion, null);

            return Ok();
        }


        // PUT: api/Roles
        [HttpPut]
        public async Task<IActionResult> PutRol([FromBody] DTORoles rol)
        {
            var usuario = await _context.Usuarios.Where(x => x.Email == User.Identity.Name).FirstOrDefaultAsync();
            var rolUsuario = await _context.Roles.Where(x => x.Id == usuario.Roles_Id).FirstOrDefaultAsync();

            if (rol.Descripcion != null && rol.Descripcion.Trim() != "")
            {
                var rolExiste = await _context.Roles.AnyAsync(x => x.Descripcion == rol.Descripcion && x.Id != rol.Id && (x.Empresas_Id == rol.Empresas_Id || x.Empresas_Id == null));
                if (rolExiste)
                {
                    return Conflict("Este rol ya está registrado para esta empresa");
                }
            }

            if (rol.Nivel != null)
            {
                var nivelExiste = await _context.Roles.AnyAsync(x => x.Nivel == rol.Nivel && x.Id != rol.Id && (x.Empresas_Id == rol.Empresas_Id || x.Empresas_Id == null));
                if (nivelExiste)
                {
                    return Conflict("Este nivel ya está asignado para otro rol");
                }

                if (usuario.SuperAdministrador == null || usuario.SuperAdministrador == false)
                {
                    var nivelSuperior = rolUsuario.Nivel > rol.Nivel;
                    if (nivelSuperior)
                    {
                        return Conflict("No puedes asignar a un rol un nivel superior al tuyo");
                    }
                }
            }

            var rolEdit = await _context.Roles.FindAsync(rol.Id);

            if (rolEdit != null)
            {
                rolEdit.Descripcion = rol.Descripcion;
                rolEdit.Nivel = (int)rol.Nivel;
                rolEdit.Empresas_Id = rol.Empresas_Id;
                rolEdit.FechaModificacion = DateTime.Now;
                rolEdit.UsuarioModificacion = User.Identity.Name;

                _context.Entry(rolEdit).State = EntityState.Modified;

                await _context.SaveChangesAsync();
            }
            else
            {
                return Conflict("Este rol ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, rol.Empresas_Id, EnumTipoProcesoRastro.Roles, EnumTipoAccionRastro.Modificar, rol.Descripcion, null);

            return Ok();
        }


        [HttpDelete("{idRol}")]
        public async Task<IActionResult> DeleteRol([FromRoute] Guid idRol)
        {
            var rol = await _context.Roles.FindAsync(idRol);

            if (rol == null)
            {
                return NotFound();
            }

            var usuarios = await _context.Usuarios.AnyAsync(x => x.Roles_Id == idRol);
            if (usuarios)
            {
                return Conflict("Este rol está asignado a algún usuario. No se puede eliminar.");
            }

            var permisos = await _context.Permisos.Where(x => x.Roles_Id == idRol).ToListAsync();

            _context.Permisos.RemoveRange(permisos);

            _context.Roles.Remove(rol);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, rol.Empresas_Id, EnumTipoProcesoRastro.Roles, EnumTipoAccionRastro.Eliminar, rol.Descripcion, null);

            return Ok();
        }

    }
}