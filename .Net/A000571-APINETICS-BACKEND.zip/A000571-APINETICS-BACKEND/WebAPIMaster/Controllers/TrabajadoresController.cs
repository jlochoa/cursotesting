﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;
using static WebAPIMaster.ModelsDTO.DTOEntidades;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TrabajadoresController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IWebHostEnvironment _server;
        private readonly IGestorRastro _gestorRastro;

        public TrabajadoresController(ApineticsContext context, IGestorRastro gestorRastro, IWebHostEnvironment env)
        {
            _context = context;
            _gestorRastro = gestorRastro;
            _server = env;
        }

        // GET: api/Persona
        [HttpGet("combo/{idEmpresa}/{responsable}")]
        public async Task<IActionResult> GetTrabajadoresCombo([FromRoute] Guid idEmpresa, bool responsable)
        {
            List<DTODataComboTrabajadoresId> trabajadores;

            if (responsable) { 
                trabajadores = await (from x in _context.Trabajadores
                                  where x.Empresas_Id == idEmpresa && x.Responsable == true
                                  orderby x.Nombre
                                  select new DTODataComboTrabajadoresId
                                  {
                                      Value = x.Id,
                                      Label = x.Nombre,
                                      Corto = x.Abreviatura,
                                  }).ToListAsync();
            }
            else
            {
                trabajadores = await (from x in _context.Trabajadores
                                where x.Empresas_Id == idEmpresa
                                orderby x.Nombre
                                select new DTODataComboTrabajadoresId
                                {
                                    Value = x.Id,
                                    Label = x.Nombre,
                                    Corto = x.Abreviatura
                                }).ToListAsync();
            }

            return Ok(trabajadores);
        }



        // GET: api/Personas
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetTrabajadoresById([FromRoute] Guid idEmpresa)
        {
            var trabajadores = await (from x in _context.Trabajadores
                                      where x.Empresas_Id == idEmpresa
                                      orderby x.Nombre
                                      select new DTOTrabajadores
                                      {
                                          Id = x.Id,
                                          Entidades_Id = x.Entidades_Id,
                                          Tipo = x.Entidades.Tipo,
                                          Nombre = x.Entidades.Tipo == "J" ? x.Entidades.Nombre : x.Entidades.NombreFisico,
                                          RazonSocial = x.Entidades.RazonSocial,
                                          NIFCIF = x.Entidades.NIFCIF,
                                          NombreConyuge = x.Entidades.NombreConyuge,
                                          ApellidosConyuge = x.Entidades.Apellido1Conyuge + " " + x.Entidades.Apellido2Conyuge,
                                          NIFConyuge = x.Entidades.NIFConyuge,
                                          Direccion = x.Entidades.Direccion,
                                          CodigoPostal = x.Entidades.CodigoPostal,
                                          Localidades_Id = x.Entidades.Localidades_Id,

                                          Empresas_Id = x.Empresas_Id,
                                          Abreviatura = x.Abreviatura,
                                          Responsable = (bool)x.Responsable,
                                          Maestros_IdDepartamento = x.Maestros_IdDepartamento,
                                          FechaAlta = x.FechaAlta,
                                          FechaBaja = x.FechaBaja,
                                          Activo = (bool)x.Activo,
                                          Departamento = x.Maestros.Descripcion,
                                          Usuarios_Id = x.Usuarios_Id,
                                          Usuario = x.Usuarios.Nombre,
                                          Telefonos = (from z in _context.EntidadesTelefonos where z.Entidades_Id == x.Entidades_Id select new DTOEntidadesTelefonos { Entidades_Id = x.Entidades_Id, Telefono = z.Telefono }).ToList(),
                                          Correos = (from z in _context.EntidadesCorreos where z.Entidades_Id == x.Entidades_Id select new DTOEntidadesCorreos { Entidades_Id = x.Entidades_Id, Email = z.Email }).ToList()

                                      }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.Trabajadores, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(trabajadores);
        }

        // GET: api/Departamentos/combo
        [HttpGet("Departamentos/combo/{idEmpresa}")]
        public async Task<IActionResult> ObtenerTodosDepartamentos([FromRoute] Guid idEmpresa)
        {
            string departamentos = await (from x in _context.Maestros
                                       where (x.Empresas_Id == idEmpresa
                                       || x.Empresas_Id == null)
                                       && x.TiposMaestros_Id.ToString() == "A8A2504D-5C69-4113-A4B2-EB0821A814E0"
                                          select x.Descripcion).SingleOrDefaultAsync();

            return Ok(departamentos);
        }

        // GET: api/Departamento
        [HttpGet("obtenerDepartamento/{idDepartamento}")]
        public async Task<IActionResult> ObtenerDepartamentoPorid([FromRoute] Guid idDepartamento)
        {
            string departamento = await (from x in _context.Maestros
                                         where x.Id == idDepartamento
                                         select x.Descripcion).SingleOrDefaultAsync();


            return Ok(departamento);
        }

        // PUT: api/Trabajadores
        [HttpPut]
        public async Task<IActionResult> PutTrabajadores([FromBody] DTOTrabajadores trabajadores)
        {

            var trabajadoresEdit = await _context.Trabajadores.FindAsync(trabajadores.Id);


            if (trabajadoresEdit != null)
            {

                trabajadoresEdit.Empresas_Id = trabajadores.Empresas_Id;
                trabajadoresEdit.Nombre = trabajadores.Nombre;
                trabajadoresEdit.Abreviatura = trabajadores.Abreviatura;
                trabajadoresEdit.Maestros_IdDepartamento = trabajadores.Maestros_IdDepartamento;
                trabajadoresEdit.Usuarios_Id = trabajadores.Usuarios_Id;
                trabajadoresEdit.Responsable = trabajadores.Responsable;
                trabajadoresEdit.FechaAlta = trabajadores.FechaAlta;
                trabajadoresEdit.FechaBaja = trabajadores.FechaBaja;
                trabajadoresEdit.Activo = trabajadores.Activo;
                trabajadoresEdit.FechaModificacion = DateTime.Now;
                _context.Entry(trabajadoresEdit).State = EntityState.Modified;
                await _context.SaveChangesAsync();

            }
            else
            {
                return Conflict("Este trabajadores ya no existe");
            }

            await _gestorRastro.AddRastro(User.Identity.Name, trabajadoresEdit.Empresas_Id, EnumTipoProcesoRastro.Trabajadores, EnumTipoAccionRastro.Modificar, null, null);

            return Ok();
      
        }

        // POST: api/Trabajadores
        [HttpPost]
        public async Task<IActionResult> PostTrabajadores([FromBody] DTOTrabajadores trabajadores)
        {

            //AQUÍ LA MODIFICACIÓN

            using var transaction = _context.Database.BeginTransaction();
            try
            {
                Entidades nuevoEntidad = new Entidades();

                if (trabajadores.Entidades_Id == null)
                {
                    string apellidoFisicoCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(trabajadores.Entidad.Apellido1Fisico))
                    {
                        apellidoFisicoCompleto = trabajadores.Entidad.Apellido1Fisico;
                        if (!string.IsNullOrEmpty(trabajadores.Entidad.Apellido2Fisico))
                        {
                            apellidoFisicoCompleto += "" + trabajadores.Entidad.Apellido2Fisico;
                        }
                    }

                    string apellidoConyugeCompleto = string.Empty;
                    if (!string.IsNullOrEmpty(trabajadores.Entidad.Apellido1Conyuge))
                    {
                        apellidoConyugeCompleto = trabajadores.Entidad.Apellido1Conyuge;
                        if (!string.IsNullOrEmpty(trabajadores.Entidad.Apellido2Conyuge))
                        {
                            apellidoConyugeCompleto += "" + trabajadores.Entidad.Apellido2Conyuge;
                        }
                    }
                    nuevoEntidad = new Entidades()
                    {
                        Codigo = trabajadores.Entidad.Codigo,
                        Tipo = trabajadores.Entidad.Tipo,
                        Nombre = trabajadores.Entidad.Tipo == "J" ? trabajadores.Entidad.Nombre :
                                (trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + "; " : "") + trabajadores.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + trabajadores.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + trabajadores.Entidad.Nombre : "") : "",
                        RazonSocial = trabajadores.Entidad.Tipo == "J" ? trabajadores.Entidad.RazonSocial :
                                (trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + "; " : "") + trabajadores.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + trabajadores.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + trabajadores.Entidad.Nombre : "") : "",
                        NombreFisico = trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.NombreFisico : null,
                        Apellido1Fisico = trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.Apellido1Fisico : null,
                        Apellido2Fisico = trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.Apellido2Fisico : null,
                        NombreConyuge = trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.NombreConyuge : null,
                        Apellido1Conyuge = trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.Apellido1Conyuge : null,
                        Apellido2Conyuge = trabajadores.Entidad.Tipo == "FC" ? trabajadores.Entidad.Apellido2Conyuge : null,
                        NIFCIF = trabajadores.Entidad.NIFCIF,
                        Descripcion = trabajadores.Entidad.Tipo == "J" ? trabajadores.Entidad.RazonSocial :
                                (trabajadores.Entidad.Tipo == "F" || trabajadores.Entidad.Tipo == "FC") ?
                                (!string.IsNullOrEmpty(apellidoFisicoCompleto) ? apellidoFisicoCompleto + ", " : "") + trabajadores.Entidad.NombreFisico +
                                (!string.IsNullOrEmpty(apellidoConyugeCompleto) && !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + apellidoConyugeCompleto + ", " + trabajadores.Entidad.NombreConyuge :
                                !string.IsNullOrEmpty(trabajadores.Entidad.NombreConyuge) ? " Y " + trabajadores.Entidad.NombreConyuge : "") : "",
                        Empresas_Id = trabajadores.Entidad.Empresas_Id,
                        DescCorta = trabajadores.Entidad.DescCorta,
                        CodigoPostal = trabajadores.Entidad.CodigoPostal,
                        Localidades_Id = trabajadores.Entidad.Localidades_Id,
                        Observaciones = trabajadores.Entidad.Observaciones,
                        Estado = trabajadores.Entidad.Activa,
                        Paises_Id = trabajadores.Entidad.Paises_Id,
                        Provincias_Id = trabajadores.Entidad.Provincias_Id,
                        Direccion = trabajadores.Entidad.Direccion,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };

                    await _context.Entidades.AddAsync(nuevoEntidad);
                    await _context.SaveChangesAsync();

                    // TELEFONOS
                    foreach (var telefono in trabajadores.Entidad.Telefonos)
                    {
                        var telefonoExistente = await _context.EntidadesTelefonos.
                            AnyAsync(t => t.Telefono == telefono.Telefono && t.Empresas_Id == nuevoEntidad.Empresas_Id);
                        if (!telefonoExistente)

                        {
                            EntidadesTelefonos nuevoTelefono = new EntidadesTelefonos
                            {
                                Entidades_Id = nuevoEntidad.Id,
                                Telefono = telefono.Telefono,
                                Empresas_Id = nuevoEntidad.Empresas_Id,
                                UsuarioCreacion = User.Identity.Name,
                                FechaCreacion = DateTime.Now,
                                UsuarioModificacion = User.Identity.Name,
                                FechaModificacion = DateTime.Now
                            };

                            await _context.EntidadesTelefonos.AddAsync(nuevoTelefono);
                        }
                    }
                    // CORREOS

                    foreach (var correo in trabajadores.Entidad.Correos)
                    {
                        var correoExistente = await _context.EntidadesCorreos.
                            AnyAsync(c => c.Email == correo.Email && c.Empresas_Id == nuevoEntidad.Empresas_Id);
                        if (!correoExistente)
                        {
                            EntidadesCorreos nuevoCorreo = new EntidadesCorreos
                            {
                                Entidades_Id = nuevoEntidad.Id,
                                Email = correo.Email,
                                Empresas_Id = nuevoEntidad.Empresas_Id,
                                UsuarioCreacion = User.Identity.Name,
                                FechaCreacion = DateTime.Now,
                                UsuarioModificacion = User.Identity.Name,
                                FechaModificacion = DateTime.Now
                            };
                            await _context.EntidadesCorreos.AddAsync(nuevoCorreo);
                        }
                    }
                    // ENTIDADES TIPOS   

                    EntidadesTipos nuevoEntidadTipo = new EntidadesTipos
                    {
                        Entidades_Id = nuevoEntidad.Id,
                        TiposEntidades_Id = new Guid("CB146CB5-1703-4A41-BB52-6FC292C7FAB4"),
                        Empresas_Id = nuevoEntidad.Empresas_Id,
                        UsuarioCreacion = User.Identity.Name,
                        FechaCreacion = DateTime.Now,
                        UsuarioModificacion = User.Identity.Name,
                        FechaModificacion = DateTime.Now
                    };
                    await _context.EntidadesTipos.AddAsync(nuevoEntidadTipo);
                    await _context.SaveChangesAsync();

                }

                //CREAR TRABAJADORES
                Trabajadores nuevoTrabajadores = new Trabajadores
                {
                    Entidades_Id = trabajadores.Entidades_Id != null ? trabajadores.Entidades_Id : nuevoEntidad.Id,
                    Empresas_Id = trabajadores.Empresas_Id,
                    Nombre = trabajadores.Nombre,
                    Abreviatura = trabajadores.Abreviatura,
                    Maestros_IdDepartamento = trabajadores.Maestros_IdDepartamento,
                    Responsable = trabajadores.Responsable,
                    FechaAlta = trabajadores.FechaAlta,
                    FechaBaja = trabajadores.FechaBaja,
                    Activo = trabajadores.Activo,
                    UsuarioCreacion = User.Identity.Name,
                    FechaCreacion = DateTime.Now,
                    UsuarioModificacion = User.Identity.Name,
                    FechaModificacion = DateTime.Now,
                    Usuarios_Id = trabajadores.Usuarios_Id,
                };

                await _context.Trabajadores.AddAsync(nuevoTrabajadores);
                await _context.SaveChangesAsync();


                //Rastro
                await _gestorRastro.AddRastro(User.Identity.Name, trabajadores.Empresas_Id, EnumTipoProcesoRastro.Trabajadores, EnumTipoAccionRastro.Agregar, trabajadores.Nombre, null);

                transaction.Commit();
                return Ok();
            }
            catch (Exception)
            {
                transaction.Rollback();
                return Conflict("Se produjo un error");
            }
        }

        // DELETE: api/Trabajadores/5
        [HttpDelete("{IdTrabajadores}")]
        public async Task<IActionResult> DeleteTrabajadores([FromRoute] Guid IdTrabajadores)
        {
            var trabajadores = await _context.Trabajadores.FindAsync(IdTrabajadores);
            if (trabajadores == null)
            {
                return NotFound();
            }

            _context.Trabajadores.Remove(trabajadores);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, trabajadores.Empresas_Id, EnumTipoProcesoRastro.Trabajadores, EnumTipoAccionRastro.Eliminar, trabajadores.Nombre, null);

            return Ok(trabajadores);
        }

    }
}

