﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class MaestrosController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public MaestrosController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Maestros
        //[AllowAnonymous]
        [HttpGet("combo/{idEmpresa}/{idTipoMaestros}")]
        public async Task<IActionResult> GetMaestrosComboByIdId([FromRoute] Guid idEmpresa, Guid idTipoMaestros)
        {
            ////OBTENGO LOS MAESTROS QUE SON DE LA EMPRESA EN CONCRETO Y LOS QUE SON PARA TODAS LAS EMPRESAS
            ////SI EN LA TABLA MAESTROS EL CAMPO EMPRESAS_Id ES NULL ES QUE ES PARA TODAS LAS EMPRESAS
            ////Y SI EN VEZ DE NULL TIENEN UN ID EN CONCRETO ES QUE ES SOLO PARA ESA EMPRESA
            var maestros = await (from x in _context.Maestros
                                  where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null) && x.TiposMaestros_Id == idTipoMaestros
                                  select new DTODataCombo
                                  {
                                      Value = x.Id,
                                      Label = x.Descripcion,
                                  }).ToListAsync();

            return Ok(maestros);

        }


        // GET: api/Maestros
        //[AllowAnonymous]
        [HttpGet("{idTipoMaestro}/{idEmpresa}")]
        public async Task<IActionResult> GetMaestros([FromRoute] Guid idTipoMaestro, Guid idEmpresa)
        {
            var maestros = await (from x in _context.Maestros
                                  where x.TiposMaestros_Id == idTipoMaestro && (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                  select new DTOMaestros
                                  {
                                      Id = x.Id,
                                      TiposMaestros_Id = x.TiposMaestros_Id,
                                      Descripcion = x.Descripcion,
                                      Empresas_Id = x.Empresas_Id
                                  }).ToListAsync();

            return Ok(maestros);
        }

        // POST: api/Maestros
        [HttpPost]
        public async Task<IActionResult> PostMaestros([FromBody] DTOMaestros maestro)
        {
            if (maestro.Descripcion != null && maestro.Descripcion.Trim() != "")
            {
                var maestroExiste = await _context.Maestros.AnyAsync(x => x.Descripcion == maestro.Descripcion && x.Empresas_Id == maestro.Empresas_Id && x.TiposMaestros_Id == maestro.TiposMaestros_Id);
                if (maestroExiste)
                {
                    return Conflict("Este maestro de este tipo de maestro ya esta registrado para esta empresa");
                }
            }

            if (maestro.Descripcion != null && maestro.Descripcion.Trim() != "")
            {
                var maestroExiste2 = await _context.Maestros.AnyAsync(x => x.Descripcion == maestro.Descripcion && x.Empresas_Id == null && x.TiposMaestros_Id == maestro.TiposMaestros_Id);
                if (maestroExiste2)
                {
                    return Conflict("Este maestro de este tipo de maestro ya esta registrado como genérico");
                }
            }


            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            Maestros nuevo = new Maestros
            {
                TiposMaestros_Id = (Guid)maestro.TiposMaestros_Id,
                Descripcion = maestro.Descripcion,
                Empresas_Id = maestro.Empresas_Id,
                FechaCreacion = DateTime.Now,
                UsuarioCreacion = User.Identity.Name,
                UsuarioModificacion = User.Identity.Name,
                FechaModificacion = DateTime.Now
            };

            await _context.Maestros.AddAsync(nuevo);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, maestro.Empresas_Id, EnumTipoProcesoRastro.Maestros, EnumTipoAccionRastro.Agregar, maestro.Descripcion, null);

            return Ok();
        }


        // PUT: api/Maestros
        [HttpPut]
        public async Task<IActionResult> PutMaestro([FromBody] DTOMaestros maestro)
        {
            if (maestro.Descripcion != null && maestro.Descripcion.Trim() != "")
            {
                var maestroExiste = await _context.Maestros.AnyAsync(x => x.Descripcion == maestro.Descripcion && x.Id != maestro.Id && x.Empresas_Id == maestro.Empresas_Id);
                if (maestroExiste)
                {
                    return Conflict("Este maestro de este tipo de maestro ya esta registrado para esta empresa ");
                }
            }

            if (maestro.Descripcion != null && maestro.Descripcion.Trim() != "")
            {
                var maestroExiste2 = await _context.Maestros.AnyAsync(x => x.Descripcion == maestro.Descripcion && x.Id != maestro.Id && x.Empresas_Id == null);
                if (maestroExiste2)
                {
                    return Conflict("Este maestro de este tipo de maestro ya esta registrado como genérico");
                }
            }

            var maestroEdit = await _context.Maestros.FindAsync(maestro.Id);

            if (maestroEdit != null)
            {
                maestroEdit.Descripcion = maestro.Descripcion;
                maestroEdit.Empresas_Id = maestro.Empresas_Id;
                maestroEdit.FechaModificacion = DateTime.Now;
                maestroEdit.UsuarioModificacion = User.Identity.Name;


                _context.Entry(maestroEdit).State = EntityState.Modified;

                await _context.SaveChangesAsync();
            }
            else
            {
                return Conflict("Este maestro ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, maestro.Empresas_Id, EnumTipoProcesoRastro.Maestros, EnumTipoAccionRastro.Modificar, maestro.Descripcion, null);

            return Ok();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMaestro([FromRoute] Guid id)
        {
            var maestro = await _context.Maestros.FindAsync(id);

            if (maestro == null)
            {
                return NotFound();
            }

            _context.Maestros.Remove(maestro);


            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, maestro.Empresas_Id, EnumTipoProcesoRastro.Maestros, EnumTipoAccionRastro.Eliminar, maestro.Descripcion, null);

            return Ok();
        }

    }
}