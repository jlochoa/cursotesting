﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIMaster.AppModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;
using System.Collections.Generic;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TiposEntidadesController : ControllerBase
    {
        private readonly ApineticsContext _context;
        private readonly IGestorRastro _gestorRastro;

        public TiposEntidadesController(ApineticsContext context, IGestorRastro gestorRastro)
        {
            _context = context;
            _gestorRastro = gestorRastro;
        }

        // GET: api/Persona
        [HttpGet("combo/{idEmpresa}")]
        public async Task<IActionResult> GetTrabajadoresCombo([FromRoute] Guid idEmpresa)
        {
            List<DTODataComboMC> tiposEntidades;

            
                tiposEntidades = await (from x in _context.TiposEntidades
                                  where (x.Empresas_Id == idEmpresa || x.Empresas_Id == null)
                                  orderby x.Descripcion
                                  select new DTODataComboMC
                                  {
                                      Value = x.Id,
                                      Label = x.Descripcion
                                  }).ToListAsync();
            

            return Ok(tiposEntidades);
        }

        // GET: api/TiposEntidades
        [HttpGet("{idEmpresa}")]
        public async Task<IActionResult> GetTiposEntidadesById([FromRoute] Guid idEmpresa)
        {
            var tiposEntidades = await (from x in _context.TiposEntidades
                                 where x.Empresas_Id == idEmpresa || x.Empresas_Id == null
                                 orderby x.Descripcion
                                 select new DTOTiposEntidades
                                 {
                                    Id = x.Id,
                                    Descripcion = x.Descripcion,
                                    //Swift = x.Swift,
                                    //Codigo = x.Codigo,
                                    DescCorta = x.DescCorta,
                                    Empresas_Id = x.Empresas_Id,
                                   

                                 }).ToListAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, idEmpresa, EnumTipoProcesoRastro.TiposEntidades, EnumTipoAccionRastro.Consultar, null, null);

            return Ok(tiposEntidades);
        }

        // PUT: api/TiposEntidades
        [HttpPut]
        public async Task<IActionResult> PutTiposEntidades([FromBody] DTOTiposEntidades tipoEntidad)
        {
            var tipoEntidadEdit = await _context.TiposEntidades.FindAsync(tipoEntidad.Id);

            if (tipoEntidadEdit != null)
            {
                tipoEntidadEdit.Descripcion = tipoEntidad.Descripcion;
                //bancoEdit.Swift = banco.Swift;
                //productoEdit.Codigo = producto.Codigo;
                tipoEntidadEdit.DescCorta = tipoEntidad.DescCorta;
                tipoEntidadEdit.Empresas_Id = tipoEntidad.Empresas_Id;
                tipoEntidadEdit.UsuarioModificacion = User.Identity.Name;

                _context.Entry(tipoEntidadEdit).State = EntityState.Modified;
            }
            else
            {
                return Conflict("Este tipo de entidad ya no existe");
            }

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, tipoEntidadEdit.Empresas_Id, EnumTipoProcesoRastro.TiposEntidades, EnumTipoAccionRastro.Modificar, tipoEntidadEdit.Descripcion, null);

            return Ok();
        }

        // POST: api/TiposEntidades
        [HttpPost]
        public async Task<IActionResult> PostTiposEntidades([FromBody] DTOTiposEntidades tipoEntidad)
        {
            TiposEntidades nuevoTipoEntidad = new TiposEntidades
            {
                Descripcion = tipoEntidad.Descripcion,
                //Swift = banco.Swift,
                //Codigo = producto.Codigo,
                Empresas_Id = tipoEntidad.Empresas_Id,
                DescCorta = tipoEntidad.DescCorta,
                UsuarioCreacion = User.Identity.Name,
                FechaCreacion = DateTime.Now,
                UsuarioModificacion = User.Identity.Name,
            };

            await _context.TiposEntidades.AddAsync(nuevoTipoEntidad);

            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, tipoEntidad.Empresas_Id, EnumTipoProcesoRastro.TiposEntidades, EnumTipoAccionRastro.Agregar, tipoEntidad.Descripcion, null);

            return Ok(nuevoTipoEntidad);
        }

        // DELETE: api/TiposEntidades/5
        [HttpDelete("{IdTipoEntidad}")]
        public async Task<IActionResult> DeleteTipoEntidad([FromRoute] Guid IdTipoEntidad)
        {
            var entidadesTipos = await _context.EntidadesTipos.AnyAsync(x => x.TiposEntidades_Id == IdTipoEntidad);
            if (entidadesTipos)
            {
                return Conflict("Este tipo de entidad esta asignado a alguna lista de entidades. No se puede eliminar");
            }

            var tiposEntidades = await _context.TiposEntidades.FindAsync(IdTipoEntidad);
            if (tiposEntidades == null)
            {
                return NotFound();
            }

            _context.TiposEntidades.Remove(tiposEntidades);
            await _context.SaveChangesAsync();

            await _gestorRastro.AddRastro(User.Identity.Name, tiposEntidades.Empresas_Id, EnumTipoProcesoRastro.TiposEntidades, EnumTipoAccionRastro.Eliminar, tiposEntidades.Descripcion, null);

            return Ok(tiposEntidades);
        }

    }
}

