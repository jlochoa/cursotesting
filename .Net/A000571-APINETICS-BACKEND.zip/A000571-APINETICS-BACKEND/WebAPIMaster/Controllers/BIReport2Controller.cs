﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Http;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json;
//using WebAPIMaster.AppModels;
//using WebAPIMaster.DataModels;
//using WebAPIMaster.ModelsDTO;
//using WebAPIMaster.Services.GestorRastro;
//using WebAPIMaster.Services.Passwords;

//namespace WebAPIMaster.Controllers
//{
//    [Authorize]
//    [Route("api/[controller]")]
//    [ApiController]
//    public class BIReport2Controller : ControllerBase
//    {
//        private static readonly string ApplicationSecret = "qh6IoQShrt3qzoOCKagsJmmD5f4bpRb6Q4u5Zqydcis=";
//        private static readonly string AuthorityUrl = "https://login.microsoftonline.com/common/";
//        private static readonly string ResourceUrl = "https://analysis.windows.net/powerbi/api";
//        // private static readonly string ApplicationId = "5ce96fd1-1543-492c-9d34-106cd2d79c22";
//        private static readonly string ApplicationId = "57302134-47bb-4f49-baad-96930c918712";
//        private static readonly string ApiUrl = "https://api.powerbi.com";
//        private static readonly string WorkspaceId = "1812f788-30ff-4ff3-a36c-c0c7f3806fb1";
//        // private static readonly string ReportId = "e5350ec5-78f1-471b-bd76-a926379c33d3";
//        private static readonly string TenantAzure = "75897b5c-0a4f-4121-ac96-f5131fb761b5";
//        // private static readonly string TenantAzure = "83e564f6-3c0b-42a6-996c-8db1b6972a33";

//        private readonly EvolucionaContext _contextEvoluciona;
//        private readonly ApineticsContext _context;
//        private readonly IGestorRastro _gestorRastro;
//        private readonly IPasswords _passwords;


//        public BIReport2Controller(EvolucionaContext contextEvoluciona, ApineticsContext context, IGestorRastro gestorRastro, IPasswords passwords)
//        {
//            _contextEvoluciona = contextEvoluciona;
//            _context = context;
//            _gestorRastro = gestorRastro;
//            _passwords = passwords;
//        }

//        // GET: api/BIReport
//        [HttpGet("{informe}/{Empresas_Id}")]
//        public async Task<ActionResult> GetAccessToken([FromRoute] string informe, Guid Empresas_Id)
//        {
//            var token = await EmbedReport(Empresas_Id);

//            if (token == "")
//            {
//                return Unauthorized();
//            }

//            await _gestorRastro.AddRastro(User.Identity.Name, null, EnumTipoProcesoRastro.Informe_BI, EnumTipoAccionRastro.Actualizar, informe, null);

//            return Ok(new { token = token });
//        }

//        // GET: api/obtenerDatosBI/{idEmpresa}
//        [HttpGet("obtenerDatosBI/{Empresas_Id}")]
//        public async Task<ActionResult> GetDatosInformes([FromRoute] Guid Empresas_Id)
//        {
//            var idInforme = 2268;

//            //if (idEmpresa == 9)
//            //{
//            //    idInforme = 2308;

//            //}
//            //else if (idEmpresa == 27)
//            //{
//            //    idInforme = 2309;

//            //}
//            //else if (idEmpresa == 23)
//            //{
//            //    idInforme = 2318;
//            //}
//            return Ok(GetDatosInforme(Empresas_Id, idInforme));

//            /*
//                        var UsuarioBI = (from x in _context.Parametros
//                                           where x.IdParametro == idEmpresa
//                                           select x.IdAccesoBi).FirstOrDefault();

//                        InformesAsociados informacion = new InformesAsociados();

//                        if (UsuarioBI == 1) { 
//                            informacion = (from x in _contextEvoluciona.InformesAsociados
//                                               where x.IdInforme == idInforme
//                                               select x).FirstOrDefault();
//                        } 
//                        else
//                        {

//                            informacion = (from x in _contextEvoluciona.InformesAsociadosAnteriores
//                                               where x.InformesAsociados_IdInforme == idInforme
//                                           select new InformesAsociados
//                                           {
//                                               IdInforme = x.IdInforme,
//                                               ReportId = x.ReportId,
//                                               Titulo = x.Titulo,
//                                               GroupId = x.GroupId,
//                                               Asociados_IdAsociado = x.Asociados_IdAsociado,
//                                               datasetId = x.datasetId,
//                                               Multi = x.Multi
//                                           } ).FirstOrDefault();

//                        }

//                        return Ok(informacion);
//            */
//        }

//        public async Task<string> EmbedReport(Guid Empresas_Id)
//        {
//            try
//            {
//                var error = GetWebConfigErrors(Empresas_Id);
//                if (error != null)
//                {
//                    return null;
//                }

//                var authenticationResult = await AuthenticateAsync(_contextEvoluciona, _passwords, Empresas_Id, _context);

//                if (authenticationResult == null)
//                {
//                    return null;
//                }

//                return authenticationResult.AccessToken;
//            }
//            catch (Exception exc)
//            {
//                return exc.ToString();
//            }
//        }

//        private InformesAsociados GetDatosInforme(Guid Empresas_Id, int id)
//        {
//            var UsuarioBI = (from x in _context.Parametros
//                             where x.Id == Empresas_Id
//                             select x.IdAccesoBi).FirstOrDefault();

//            InformesAsociados informacion = new InformesAsociados();

//            if (UsuarioBI == 1)
//            {
//                informacion = (from x in _contextEvoluciona.InformesAsociados
//                               where x.IdInforme == id
//                               select x).FirstOrDefault();
//            }
//            else
//            {

//                informacion = (from x in _contextEvoluciona.InformesAsociadosAnteriores
//                               where x.InformesAsociados_IdInforme == id
//                               select new InformesAsociados
//                               {
//                                   IdInforme = x.IdInforme,
//                                   ReportId = x.ReportId,
//                                   Titulo = x.Titulo,
//                                   GroupId = x.GroupId,
//                                   Asociados_IdAsociado = x.Asociados_IdAsociado,
//                                   datasetId = x.datasetId,
//                                   Multi = x.Multi
//                               }).FirstOrDefault();

//            }



//            return informacion;
//        }

//        private string GetWebConfigErrors(Guid Empresas_Id)
//        {

//            var UsuarioBI = (from x in _context.Parametros
//                             where x.Id == Empresas_Id
//                             select x.IdAccesoBi).FirstOrDefault();

//            var accesobi = (from x in _contextEvoluciona.AccesoBI
//                            where x.id == UsuarioBI
//                            select x).FirstOrDefault();

//            string Password = _passwords.Decrypt(accesobi.password, "tomate2020Cima");
//            string Username = accesobi.usuario;

//            // Application Id must have a value.
//            if (string.IsNullOrWhiteSpace(ApplicationId))
//            {
//                return "ApplicationId is empty. please register your application as Native app in https://dev.powerbi.com/apps and fill client Id in web.config.";
//            }

//            // Application Id must be a Guid object.
//            Guid result;
//            if (!Guid.TryParse(ApplicationId, out result))
//            {
//                return "ApplicationId must be a Guid object. please register your application as Native app in https://dev.powerbi.com/apps and fill application Id in web.config.";
//            }

//            // Workspace Id must have a value.
//            if (string.IsNullOrWhiteSpace(WorkspaceId))
//            {
//                return "WorkspaceId is empty. Please select a group you own and fill its Id in web.config";
//            }

//            // Workspace Id must be a Guid object.
//            if (!Guid.TryParse(WorkspaceId, out result))
//            {
//                return "WorkspaceId must be a Guid object. Please select a workspace you own and fill its Id in web.config";
//            }

//            // Username must have a value.
//            if (string.IsNullOrWhiteSpace(Username))
//            {
//                return "Username is empty. Please fill Power BI username in web.config";
//            }

//            // Password must have a value.
//            if (string.IsNullOrWhiteSpace(Password))
//            {
//                return "Password is empty. Please fill password of Power BI username in web.config";
//            }

//            return null;
//        }

//        private static async Task<OAuthResult> AuthenticateAsync(EvolucionaContext contextEvoluciona, IPasswords passwords, Guid Empresas_Id, ApineticsContext _context)
//        {
//            var UsuarioBI = (from x in _context.Parametros
//                             where x.Id == Empresas_Id
//                             select x.IdAccesoBi).FirstOrDefault();

//            var accesobi = (from x in contextEvoluciona.AccesoBI
//                            where x.id == UsuarioBI
//                            select x).FirstOrDefault();

//            //var accesobi = contextEvoluciona.AccesoBI.First();

//            string Password = passwords.Decrypt(accesobi.password, "tomate2020Cima");
//            string Username = accesobi.usuario;

//            var oauthEndpoint = new Uri("https://login.microsoftonline.com/" + TenantAzure + "/oauth2/token");
//            using (var client = new HttpClient())
//            {
//                FormUrlEncodedContent args = new FormUrlEncodedContent(new[]
//                {
//                    new KeyValuePair<string, string>("resource", ResourceUrl),
//                    new KeyValuePair<string, string>("client_id", ApplicationId),
//                    new KeyValuePair<string, string>("grant_type", "password"),
//                    new KeyValuePair<string, string>("username", Username),
//                    new KeyValuePair<string, string>("password", Password),
//                    new KeyValuePair<string, string>("scope", "openid"),
//                });
//                var result = await client.PostAsync(oauthEndpoint, new FormUrlEncodedContent(new[]
//                {
//                    new KeyValuePair<string, string>("resource", ResourceUrl),
//                    new KeyValuePair<string, string>("client_id", ApplicationId),
//                    new KeyValuePair<string, string>("grant_type", "password"),
//                    new KeyValuePair<string, string>("username", Username),
//                    new KeyValuePair<string, string>("password", Password),
//                    new KeyValuePair<string, string>("scope", "openid"),
//                }));

//                var content = await result.Content.ReadAsStringAsync();
//                return JsonConvert.DeserializeObject<OAuthResult>(content);
//            }
//        }

//        class OAuthResult
//        {
//            [JsonProperty("token_type")]
//            public string TokenType { get; set; }
//            [JsonProperty("scope")]
//            public string Scope { get; set; }
//            [JsonProperty("experies_in")]
//            public int ExpiresIn { get; set; }
//            [JsonProperty("ext_experies_in")]
//            public int ExtExpiresIn { get; set; }
//            [JsonProperty("experies_on")]
//            public int ExpiresOn { get; set; }
//            [JsonProperty("not_before")]
//            public int NotBefore { get; set; }
//            [JsonProperty("resource")]
//            public Uri Resource { get; set; }
//            [JsonProperty("access_token")]
//            public string AccessToken { get; set; }
//            [JsonProperty("refresh_token")]
//            public string RefreshToken { get; set; }
//        }
//    }
//}