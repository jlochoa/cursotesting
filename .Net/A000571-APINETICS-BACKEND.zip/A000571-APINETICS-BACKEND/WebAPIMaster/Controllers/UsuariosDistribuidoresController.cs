﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosDistribuidoresController : ControllerBase
    {
        private readonly ApineticsContext _context;

        public UsuariosDistribuidoresController(ApineticsContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmpresasDistribuidorasByEmailUsuario([FromQuery] string emailUsuario)
        {

            var Id = await (from x in _context.Usuarios
                                  where x.Email == emailUsuario
                                  select x.Id).SingleOrDefaultAsync();

            var empresas = await (from x in _context.UsuariosDistribuidores
                                        where x.Usuarios_Id == Id
                                        select new Empresas
                                        {
                                            Nombre = x.Empresas.Nombre,
                                            Id = x.Empresas_Id,
                                            Logo = x.Empresas.Logo
                                        }).ToListAsync();

            return Ok(empresas);
        }
    }
}