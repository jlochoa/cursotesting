﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.Services.GestorRastro;

namespace WebAPIMaster.Tests2.FakesServices
{
    public class FakeGestorRastro : IGestorRastro
    {
        public async Task<int> AddRastro(string? usuario, Guid? Empresas_Id, EnumTipoProcesoRastro proceso, EnumTipoAccionRastro operacion, string observaciones, string tipo)
        {
            return await Task.FromResult(1);
        }
    }
}
