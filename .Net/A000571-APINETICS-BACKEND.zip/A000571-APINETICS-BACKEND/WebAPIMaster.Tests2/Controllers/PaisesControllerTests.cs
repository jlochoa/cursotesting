﻿using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NuGet.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.Controllers;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;
using WebAPIMaster.Services.GestorRastro;
using WebAPIMaster.Tests2.FakesServices;
using WebAPIMaster.Tests2.Utils;

namespace WebAPIMaster.Tests2.Controllers
{
    [TestFixture]
    public class PaisesControllerTests : BaseTests
    {
        ApineticsContext context;
        IGestorRastro gestorRastro;
        PaisesController controller;
        [SetUp]
        public async Task SetUpAsync()
        {
            // Preparación
            var nombreDB = Guid.NewGuid().ToString();
            context = BuildContext(nombreDB);
            gestorRastro = new FakeGestorRastro();

            controller = new PaisesController(context, gestorRastro);
            await context.Paises.AddRangeAsync(
                new Paises { Id = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca"), Nombre = "Chad", Spain = true, Cee = true, CodPais = 1, CodAlfa3 = "Alfa 1", UsuarioCreacion = "Yo", UsuarioModificacion = "Yo", Empresas_Id = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db") },
                new Paises { Id = Guid.Parse("0d809e61-a864-491e-8291-683a4f439833"), Nombre = "Brunei", Spain = true, Cee = true, CodPais = 1, CodAlfa3 = "Alfa 1", UsuarioCreacion = "Yo", UsuarioModificacion = "Yo", Empresas_Id = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db") }
            );
            await context.SaveChangesAsync();
            // El usuario es por el User.Identity que utiliza el endpoint
            var usuario = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name,"testUser")
            }, "mock")); // ponemos mock arbitrariamente. No es jwt, bearer, cookie...

            var httpContext = new DefaultHttpContext
            {
                User = usuario
            };

            controller.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
        }

        [TearDown]
        public void TearDown()
        {
            context.Dispose();
        }

        [Test]
        public async Task GetPaisesCombo_ReturnsPaises()
        {
            // Prueba
            var idEmpresa = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db");
            var respuesta = await controller.GetPaisesCombo(idEmpresa) as OkObjectResult;
            
            // Verificación
            var paises = respuesta.Value as IEnumerable<DTODataComboMC>;
            Assert.IsNotNull(paises);
            Assert.That(paises.Count, Is.EqualTo(2));  // Esperamos dos países en la base de datos
            Assert.IsTrue(paises.Any(b => b.Label == "Chad"));
        }

        [Test]
        public async Task GetPaisesById_ReturnsPaises()
        {
            // Prueba
            var idEmpresa = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db");
            var respuesta = await controller.GetPaisesById(idEmpresa) as OkObjectResult;

            // Verificación
            var paises = respuesta.Value as IEnumerable<DTOPaises>;
            Assert.IsNotNull(paises);
            Assert.That(paises.Count, Is.EqualTo(2));  // Esperamos dos países en la base de datos
            Assert.IsTrue(paises.Any(b => b.Nombre == "Chad"));
        }

        [Test]
        public async Task PutPaises_UpdateOk()
        {
            // Prueba
            Guid idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca");
            Guid idEmpresa = new Guid();
            var updatePais = new DTOPaises
            {
                Id = idPais,
                Nombre = "Vanuatu",
                Spain = false,
                Cee = false,
                CodPais = 99,
                Empresas_Id = idEmpresa
            };

            var respuesta = await controller.PutPaises(updatePais) as OkObjectResult;

            // Verificación
            var respuestaConsulta = await controller.GetPaisesById(idEmpresa) as OkObjectResult;
            var paises = respuestaConsulta.Value as IEnumerable<DTOPaises>;
            var existe = paises.Any(x=>x.Nombre=="Vanuatu" && x.Id== idPais);
            Assert.That(existe, Is.True);
        }

        [Test]
        public async Task PostPaises_AddOk()
        {
            // Prueba
            Guid idPais = Guid.NewGuid();
            Guid idEmpresa = Guid.NewGuid();
            var nuevoPais = new DTOPaises
            {
                Id = idPais,
                Nombre = "Albania",
                Spain = false,
                Cee = false,
                CodPais = 99,
                Empresas_Id = idEmpresa
            };

            var respuesta = await controller.PostPaises(nuevoPais) as OkObjectResult;

            // Verificación
            var respuestaConsulta = await controller.GetPaisesById(idEmpresa) as OkObjectResult;
            var paises = respuestaConsulta.Value as IEnumerable<DTOPaises>;
            var existe = paises.Any(x => x.Nombre == "Albania" );
            Assert.That(existe, Is.True);
        }

        [Test]
        public async Task DeletePaises_DeleteOk()
        {
            // Prueba
            var idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca");
            var respuesta = await controller.DeletePaises(idPais) as OkObjectResult;

            // Verificación
            var idEmpresa = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db");
            var respuestaConsulta = await controller.GetPaisesById(idEmpresa) as OkObjectResult;
            var paises = respuestaConsulta.Value as IEnumerable<DTOPaises>;
            var existe = paises.Any(x => x.Nombre == "Chad");
            Assert.That(existe, Is.False);
        }

        [Test]
        public async Task DeletePaises_DeleteNotFound()
        {
            // Prueba
            var idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdcb");
            var respuesta = await controller.DeletePaises(idPais) as NotFoundResult;

            // Verificación
            Assert.That(respuesta.StatusCode, Is.EqualTo(404));
        }
    }


}
