﻿using Microsoft.EntityFrameworkCore;
using WebAPIMaster.DataModels;

namespace WebAPIMaster.Tests2.Utils
{
    public class BaseTests
    {
        protected ApineticsContext BuildContext(string dbName)
        {
            var opciones = new DbContextOptionsBuilder<ApineticsContext>().UseInMemoryDatabase(dbName).Options;
            var dbContext = new ApineticsContext(opciones);
            return dbContext;
        }
    }
}
