﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using WebAPIMaster.AppModels;
using WebAPIMaster.DataModels;
using WebAPIMaster.Services.GestorRastro;


namespace WebAPIMaster.Tests
{
    public class CustomWebApplicationFactory : WebApplicationFactory<Startup>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Testing"); // Agregamos una variable de entorno "Testing" que utilizará Program.cs para agregar un archivo de configuración más
            builder.ConfigureServices(services =>
            {
                // Eliminar DbContext existente
                var descriptors = services.Where(d => d.ServiceType == typeof(DbContextOptions<ApineticsContext>)).ToList();
                foreach (var descriptor in descriptors)
                {
                    services.Remove(descriptor);
                }

                // Mock de IGestorRastro para evitar errores en el test
                var gestorRastroMock = new Mock<IGestorRastro>();
                gestorRastroMock.Setup(x => x.AddRastro(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<EnumTipoProcesoRastro>(), It.IsAny<EnumTipoAccionRastro>(), It.IsAny<string>(), It.IsAny<string>()))
                    .ReturnsAsync(1);
                services.AddSingleton(gestorRastroMock.Object);

                // Registrar DbContext en memoria
                services.AddDbContext<ApineticsContext>(options =>
                    options.UseInMemoryDatabase("TestDb"));

                // Inicializar la base de datos con datos de prueba
                var sp = services.BuildServiceProvider();
                using (var scope = sp.CreateScope())
                {
                    var dbContext = scope.ServiceProvider.GetRequiredService<ApineticsContext>();
                    dbContext.Database.EnsureDeleted();
                    dbContext.Database.EnsureCreated();
                    dbContext.Paises.AddRange(
                        new Paises { Id = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca"), Nombre = "Chad", Spain = true, Cee = true, CodPais = 1, CodAlfa3 = "Alfa 1", UsuarioCreacion = "Yo", UsuarioModificacion = "Yo", Empresas_Id = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db") },
                        new Paises { Id = Guid.Parse("0d809e61-a864-491e-8291-683a4f439833"), Nombre = "Brunei", Spain = true, Cee = true, CodPais = 1, CodAlfa3 = "Alfa 1", UsuarioCreacion = "Yo", UsuarioModificacion = "Yo", Empresas_Id = Guid.Parse("eef9e169-b9c9-45ca-b5db-de0e933d23db") }
                    );
                    dbContext.SaveChanges();
                }
            });
        }
    }
}

