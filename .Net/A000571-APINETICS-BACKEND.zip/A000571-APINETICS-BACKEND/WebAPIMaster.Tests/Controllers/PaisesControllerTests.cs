﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebAPIMaster.DataModels;
using WebAPIMaster.ModelsDTO;

namespace WebAPIMaster.Tests.Controllers
{
    [TestFixture]
    public class PaisesControllerTests
    {
        private HttpClient _client;
        private CustomWebApplicationFactory _factory;

        [SetUp]
        public void SetUp()
        {
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Testing");
            _factory = new CustomWebApplicationFactory();
            _client = _factory.WithWebHostBuilder(builder =>
            {
                builder.ConfigureTestServices(services =>
                {
                    services.AddSingleton<IAuthorizationHandler, AllowAnonymousAuthorizationHandler>();
                });
            }).CreateClient();
        }

        [TearDown]
        public void TearDown()
        {
            _factory.Dispose();
            _client.Dispose();
        }

        [Test]
        public async Task GetPaisesCombo_ReturnsPaises()
        {
            string idEmpresa = "eef9e169-b9c9-45ca-b5db-de0e933d23db";
            // Acción: Hacer la solicitud GET para obtener paises
            var response = await _client.GetAsync($"/api/paises/combo/{idEmpresa}");

            // Asegurarse de que la solicitud fue exitosa
            response.EnsureSuccessStatusCode();

            // Leer y deserializar el contenido de la respuesta
            var content = await response.Content.ReadAsStringAsync();
            var paises = JsonSerializer.Deserialize<List<DTODataComboMC>>(content);

            // Comprobar los resultados
            Assert.IsNotNull(paises);
            Assert.AreEqual(2, paises.Count);  // Esperamos dos países en la base de datos
            Assert.IsTrue(paises.Any(b => b.Label == "Chad"));
        }

        [Test]
        public async Task GetPaisesById_ReturnsPaises()
        {
            string idEmpresa = "eef9e169-b9c9-45ca-b5db-de0e933d23db";
            // Acción: Hacer la solicitud GET para obtener paises
            var response = await _client.GetAsync($"/api/paises/{idEmpresa}");

            // Asegurarse de que la solicitud fue exitosa
            response.EnsureSuccessStatusCode();

            // Leer y deserializar el contenido de la respuesta
            var content = await response.Content.ReadAsStringAsync();
            var paises = JsonSerializer.Deserialize<List<DTOPaises>>(content);

            // Comprobar los resultados
            Assert.That(paises, Is.Not.Null);
            Assert.That(paises.Count, Is.GreaterThan(0));
            Assert.That(paises[0].Empresas_Id, Is.EqualTo(Guid.Parse(idEmpresa)));
        }

        [Test]
        public async Task PutPaises_UpdateOk()
        {
            Guid idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca");
            var updatePais = new DTOPaises
            {
                Id = idPais,
                Nombre = "Vanuatu",
                Spain = false,
                Cee = false,
                CodPais = 99,
                Empresas_Id = new Guid()
            };

            // Acción: Hacer la solicitud PUT para modificar el país
            var response = await _client.PutAsJsonAsync($"/api/paises",updatePais);
            response.EnsureSuccessStatusCode();

            // Leer y deserializar el contenido de la respuesta
            var content = await response.Content.ReadAsStringAsync();
            var pais = JsonSerializer.Deserialize<Paises>(content);

            // Comprobar los resultados
            Assert.That(pais.Nombre, Is.EqualTo("Vanuatu"));
        }

        [Test]
        public async Task PostPaises_AddOk()
        {
            Guid idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca");
            Guid idEmpresa = new Guid();
            var nuevoPais = new DTOPaises
            {
                Id = idPais,
                Nombre = "Albania",
                Spain = false,
                Cee = false,
                CodPais = 99,
                Empresas_Id = idEmpresa
            };

            // Acción: Hacer la solicitud POST para obtener paises
            var response = await _client.PostAsJsonAsync($"/api/paises", nuevoPais);
            response.EnsureSuccessStatusCode();

            // Comprobar la inserción
            var result = await _client.GetAsync($"/api/Paises/{idEmpresa}");
            result.EnsureSuccessStatusCode();
            var content = await result.Content.ReadAsStringAsync();

            // Comprobar los resultados
            Assert.That(content, Does.Contain("Albania"));
        }

        [Test]
        public async Task DeletePaises_DeleteOk()
        {
            var idPais = Guid.Parse("ee00f1fe-3edb-4229-8822-0eb773f8fdca");
            var idEmpresa = "eef9e169-b9c9-45ca-b5db-de0e933d23db";

            // Acción: Hacer la solicitud POST para obtener paises
            var response = await _client.DeleteAsync($"/api/paises/{idPais}");
            response.EnsureSuccessStatusCode();

            // Comprobar la eliminación
            //var result = await _client.GetAsync($"/api/Paises/{idPais}");
            //Assert.AreEqual(System.Net.HttpStatusCode.NotFound,result.StatusCode);

            var result = await _client.GetAsync($"/api/Paises/{idEmpresa}");
            result.EnsureSuccessStatusCode();
            var content = await result.Content.ReadAsStringAsync();
            var paises = JsonSerializer.Deserialize<List<DTOPaises>>(content);

            // Comprobar los resultados
            Assert.That(paises.Count, Is.EqualTo(1));
            Assert.That(paises.Any(x=>x.Id==idPais), Is.False);
        }
    }
}
