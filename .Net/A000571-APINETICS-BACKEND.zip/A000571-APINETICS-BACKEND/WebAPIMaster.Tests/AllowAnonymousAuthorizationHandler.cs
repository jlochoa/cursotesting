﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPIMaster.Tests
{
    public class AllowAnonymousAuthorizationHandler : IAuthorizationHandler
    {
        public Task HandleAsync(AuthorizationHandlerContext context)
        {
            foreach (var requrement in context.PendingRequirements.ToList())
            {
                context.Succeed(requrement);
            }
            return Task.CompletedTask;
        }
    }
}
